% This version: April 3, 2019

clearvars -except dropboxpath
clc
close all
warning off all

% cepath='/Applications/MATLAB_R2020b.app/toolbox/compecon/'; path([cepath 'cetools;' cepath 'cedemos'],path)
% dropboxpath='/Users/xianjiang/Dropbox/CODE/Replication/matlab/';
% addpath([dropboxpath 'myfunctions'])
% addpath([dropboxpath 'estimation'])

%% SETTINGS
% set parameters
pars.p_s = 1;
pars.beta  = 0.95;  
pars.theta = 0.734;   

% policy relevant parameters
pars.nu = 0.17;
pars.tau = 0.154;
pars.n_dep =10;
pars.r = 1/pars.beta - 1;
pars.pv = (1./pars.n_dep).*(1+pars.r)/pars.r.*(1-(1+pars.r).^(-pars.n_dep));
pars.delta_dep = (1-pars.beta).*pars.pv./(1-pars.beta.*pars.pv);
 
% shock processes
pars.rho_b = 0.009;  
pars.sig_b = 0.010/(1-pars.theta);
pars.rho_e = 0.860;   
pars.sig_e = 0.529/(1-pars.theta); 
pars.sig_u = sqrt(1-pars.rho_e^2)*pars.sig_e;  %standard deviation of shocks
pars.sig_w = 0.854;

% simulation 
pars.T  = 101*2;                     % number of periods
pars.Tn = 15;                        % not using initial 15 periods
pars.Nf = 10000;                     % number of firms

% setting algorithm parameter values
pars.tol = 10^-8; 
pars.maxiter = 5000; 
        
% approximation basis
pars.nb = 5;
pars.ne = 20;
pars.m = 3;   %std for Tauchen's discretization
pars.nk = 31;
pars.nxi = 20;
pars.na = pars.nb*pars.ne;

% approximation grids 
[b_grid,P_b] = tauchen(0,sqrt(1-pars.rho_b^2)*pars.sig_b,pars.rho_b,pars.m,pars.nb); b_grid = exp(b_grid);
[e_grid,P_e] = tauchen(0,sqrt(1-pars.rho_e^2)*pars.sig_e,pars.rho_e,pars.m,pars.ne); e_grid = exp(e_grid);
[a_grid,I]   = sort(kron(b_grid,e_grid),'ascend');
P_a = kron(P_b,P_e);
P_a = P_a(I,I);
 
pars.k_min=1;
pars.k_max=10000;

curv = .4;
k_grid = linspace(pars.k_min.^curv,pars.k_max.^curv,pars.nk).^(1/curv);
k_grid = k_grid';
    
glob.mm_data = [.10199465   .62473681   .71996196   .83386538   .89146234   .16613462   .19991728   .18586291  -.26637802   -.2200787   .04603122   .03824951    .4857366   .22259947   .13040413];
glob.V = eye(length(glob.mm_data));

 %% 1 SET PARAMETERS 
load Fixed_A_idtw_0829_ps x 

    % assign parameter values
    gamma       = x(1,1);
    xi_bar      = x(1,2);
    delta       = x(1,3);
    
    p_s         = pars.p_s;
    beta        = pars.beta;
    theta       = pars.theta;
    rho_e     = pars.rho_e;
    sig_u     = pars.sig_u;
    nu          = pars.nu;
    tau         = pars.tau;
    n_dep       = pars.n_dep;
    r           = pars.r;
    pv          = pars.pv;
    delta_dep   = pars.delta_dep;
    
    k_min       = pars.k_min;
    k_max       = pars.k_max;
    na          = pars.na;
    nxi         = pars.nxi;
    
    Tn          = pars.Tn;
	T           = pars.T; 
    Nf          = pars.Nf;
    
    tol         = pars.tol;
    maxiter     = pars.maxiter;
    
    
    fpars = [gamma;xi_bar;p_s];         % friction parameters
    apars = [beta;delta;theta;rho_e;sig_u];             % asigned parameters
    tpars = [nu;tau;n_dep;pv;delta_dep];    % policy parameters
    options = [tol,maxiter];

    %% SIMULATE MOMENTS
        
        %% Approximation basis   
        P = P_a;
        fspace = fundef({'spli', k_grid, 0, 3}, ...
                        {'spli', a_grid, 0, 1});
        s_grid = funnode(fspace);
        s = gridmake(s_grid);
        ns = length(s);
        nk = ns/na;

        %% Solve the model 
        %  BEFORE THE REFORM
        tpars_before=tpars;
            ce0 = funfitxy(fspace,s,s(:,2).^(1-theta).*s(:,1).^theta);            
            [ckprimeb_before,ckprimes_before,ce_before,cvb_before,cvs_before,ve_before] = sol_model_xi(s,ce0,fspace,P,k_max,k_min,ns,nk,options,fpars,apars,tpars_before);
                        
        % AFTER THE REFORM
        tpars_after = tpars;
        tpars_after(1) = 0.0;
            ce0 = funfitxy(fspace,s,ve_before);
            clear ve_before
            [ckprimeb_after,ckprimes_after,ce_after,cvb_after,cvs_after,~] = sol_model_xi(s,ce0,fspace,P,k_max,k_min,ns,nk,options,fpars,apars,tpars_after);
            
%% Simulate Moments
sim_firm_xi_2021_04_07
 
mm_sim = [mm1,dist5,dist10,dist20,dist30,mm4,mm6,mm11,b_ind,b_IK,mean(IRF_sim(1,1:3)),mean(IRF_sim(2,1:3)),mm10,mm7];
 
mm_idx  = [1 3 4 5 7 8 11 12];
mm_sim(mm_idx)
