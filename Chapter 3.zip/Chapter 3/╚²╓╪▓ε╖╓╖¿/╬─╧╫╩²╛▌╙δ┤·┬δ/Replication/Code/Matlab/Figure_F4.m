
clearvars -except dropboxpath
clc
close all
warning off all

% dropboxpath='/Users/xianjiang/Dropbox/Research/Fiscal Incentive and Investment/Replication/';
% cepath=[dropboxpath 'Code/Matlab/myfunctions/compecon/']; path([cepath 'cetools;' cepath 'cedemos'],path)
% 
% addpath([dropboxpath 'Code/Matlab/myfunctions'])
% addpath([dropboxpath 'Code/Matlab/estimation'])
% addpath([dropboxpath 'RawData'])

load([dropboxpath 'AnalysisData/Figure_F4.mat'])

%% Generate Graphs
serial_corr = moments(:,5);

fig = figure;
plot(GXI(:,1),serial_corr,'LineWidth',1.5)
set(gca,'FontSize',14)
xlabel('\gamma','FontSize',18)
ylabel('Serial Correlation (Unconditional)','FontSize',16)

%% Save Graphs
saveas(fig, strcat(dropboxpath,'Output/Figure_F4.png'))