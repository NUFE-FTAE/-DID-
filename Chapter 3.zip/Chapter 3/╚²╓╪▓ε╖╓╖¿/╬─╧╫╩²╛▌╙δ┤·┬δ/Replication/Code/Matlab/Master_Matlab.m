clear
clc
close all

% dropboxpath='/Users/xianjiang/Dropbox/Research/Fiscal Incentive and Investment/Replication/'; % revise this directory
dropboxpath = '/Users/xianjiang/Desktop/Replication/';

cepath=[dropboxpath 'Code/Matlab/myfunctions/compecon/']; path([cepath 'cetools;' cepath 'cedemos'],path)
addpath([dropboxpath 'Code/Matlab/myfunctions'])
addpath([dropboxpath 'Code/Matlab/estimation'])
addpath([dropboxpath 'Code/Matlab/standard_error'])
addpath([dropboxpath 'RawData'])
addpath([dropboxpath 'AnalysisData'])

%% Prepare 
%%% Estimation
run([dropboxpath 'Code/Matlab/estimation/estimation_fixed_A_idtw.m'])       % fixed cost: scalar, moments A
run([dropboxpath 'Code/Matlab/estimation/estimation_uniform_A_idtw.m'])     % fixed cost: uniform dist., moments A
run([dropboxpath 'Code/Matlab/estimation/estimation_uniform_AB_idtw.m'])    % fixed cost: uniform dist., moments AB

%%% Standard errors
run([dropboxpath 'Code/Matlab/standard_error/standard_errors_main.m'])
run([dropboxpath 'Code/Matlab/standard_error/analysis.m'])

%%% Policy simulation
policy_simulation
save([dropboxpath 'AnalysisData/polsim_uniform_AB_idtw.mat']);

%%% Loss function
Figure_F3_prepare
save([dropboxpath 'AnalysisData/Figure_F3.mat'])

%%% Correlation between serial correlation and convex adjustment cost
Figure_F4_prepare
save([dropboxpath 'AnalysisData/Figure_F4.mat'])

%% Main Figures and Tables
%%% Figures
Figure_2

Figure_3

Figure_4A
Figure_4B
Figure_4C
Figure_4D

Figure_7_F5_F6_and_Table_9

%%% Tables
% Table 7
Table_7_B_Part1     % Table 7, Panel B, Part 1 (productivity estimation)

pars_stata = readtable([dropboxpath 'Output/Table_7_B_Part2.xls'],'Range','C2:D5'); % decomposition from Stata
pars_stata = pars_stata{:,:};
load se_Uniform_AB
fileID = fopen([dropboxpath 'Output/Table_7.txt'],'w');
% pre-set fixed parameters
fprintf(fileID,'Discount factor                     = %7.3f  \n',.950);
fprintf(fileID,'VAT rate                            = %7.3f  \n',.170);
fprintf(fileID,'CIT rate                            = %7.3f  \n',.154);
fprintf(fileID,'PV depreciation schedule            = %7.3f  \n',.803);
fprintf(fileID,'\n');
% productivity estimation via system gmm
fprintf(fileID,'Profit curvature                    = %7.3f %7.3f \n',theta,se_theta);
fprintf(fileID,'Persistence firm transitory shocks  = %7.3f %7.3f \n',rho,se_rho);
fprintf(fileID,'SD firm transitory shocks           = %7.3f %7.3f \n',pars_stata(1,1),pars_stata(1,2));
fprintf(fileID,'SD firm permanent shocks            = %7.3f %7.3f \n',pars_stata(2,1),pars_stata(2,2));
fprintf(fileID,'Persistence aggregate shocks        = %7.3f %7.3f \n',pars_stata(3,1),pars_stata(3,2));
fprintf(fileID,'SD aggregate shocks                 = %7.3f %7.3f \n',pars_stata(4,1),pars_stata(4,2));
fprintf(fileID,'\n');
% investment costs estimated via msm
fprintf(fileID,'Convex cost                         = %7.3f %7.3f \n',est(1,1),se(1,1));
fprintf(fileID,'Upper bound of fixed costs          = %7.3f %7.3f \n',est(1,2),se(1,2));
fprintf(fileID,'Economic depreciation rate          = %7.3f %7.3f \n',est(1,3),se(1,3));
fclose(fileID);

% Table 8
Table_8

% Table 9 is generated along with Figure 7

%% Appendix Figures and Tables
%%% Figures
Figure_F3
Figure_F4
% Figure_F5 and Figure_F6 are generated along with Figure 7

%%% Tables
% Table_F16: Data are generated in Table_8
Table_F17
save([dropboxpath 'AnalysisData/Table_F17.mat'],'IRF20');

Table_F18
save([dropboxpath 'AnalysisData/Table_F18.mat'],'DPK','DI','DEXT','DTAX','DV');

Table_F19
save([dropboxpath 'AnalysisData/Table_F19.mat'],'DI','DEXT','DTAX','DV');

Table_F20
save([dropboxpath 'AnalysisData/Table_F20.mat'],'DTUCC','DI','DEXT','DTAX','DV');

Table_F21
save([dropboxpath 'AnalysisData/Table_F21.mat'],'DI','DEXT','DTAX','DV');

Table_F22
save([dropboxpath 'AnalysisData/Table_F22.mat'],'DTPARS','DTUCC','DI','DEXT','DTAX','DV');

Table_F23
save([dropboxpath 'AnalysisData/Table_F23.mat'],'DID_EXT','DID_INT');

Table_F24
save([dropboxpath 'AnalysisData/Table_F24.mat'],'ELS','DPK','DID_EXT','D_EXT_D','D_EXT_F','DID_INT','D_INT_D','D_INT_F');

%% Generate Appendix Tables
% Table F.16
load Sens_Matrix
fileID = fopen([dropboxpath 'Output/Table_F16.txt'],'w');
fprintf(fileID,'Avg. Investment Rate   = %7.4f %7.4f %7.4f \n',Sens_Matrix(1,:));  
fprintf(fileID,'Share<0.1              = %7.4f %7.4f %7.4f \n',Sens_Matrix(2,:));  
fprintf(fileID,'Share<0.2              = %7.4f %7.4f %7.4f \n',Sens_Matrix(3,:));  
fprintf(fileID,'Share<0.3              = %7.4f %7.4f %7.4f \n',Sens_Matrix(4,:));  
fprintf(fileID,'Serial Correlation     = %7.4f %7.4f %7.4f \n',Sens_Matrix(5,:));  
fprintf(fileID,'SD. Investment Rate    = %7.4f %7.4f %7.4f \n',Sens_Matrix(6,:));  
fprintf(fileID,'\n');
fprintf(fileID,'Extensive DID           = %7.4f %7.4f %7.4f \n',Sens_Matrix(7,:));  
fprintf(fileID,'Intensive DID           = %7.4f %7.4f %7.4f \n',Sens_Matrix(8,:));  
fclose(fileID);

% Table F.17
load([dropboxpath 'AnalysisData/Table_F17.mat'])
fileID = fopen([dropboxpath 'Output/Table_F17.txt'],'w');
fprintf(fileID,'Data   = %7.3f %7.3f \n',0.073,0.035);  
fprintf(fileID,'Model  = %7.3f %7.3f \n',mean(IRF20(1,1:3)),mean(IRF20(2,1:3))); 
fclose(fileID);

% Table F.18
load([dropboxpath 'AnalysisData/Table_F18.mat'])
fileID = fopen([dropboxpath 'Output/Table_F18.txt'],'w');
fprintf(fileID,'percentage change in capital price             = %7.3f %7.3f %7.3f %7.3f %7.3f \n',DPK);
fprintf(fileID,'\n');
fprintf(fileID,'percentage change in aggregate investment      = %7.3f %7.3f %7.3f %7.3f %7.3f \n',DI);
fprintf(fileID,'percentage change in frac. investment          = %7.3f %7.3f %7.3f %7.3f %7.3f \n',DEXT);
fprintf(fileID,'\n');
fprintf(fileID,'percentage change in aggregate tax revenue     = %7.3f %7.3f %7.3f %7.3f %7.3f \n',DTAX);
fprintf(fileID,'percentage change in average firm value        = %7.3f %7.3f %7.3f %7.3f %7.3f \n',DV);
fprintf(fileID,'\n');
fprintf(fileID,'ratio of investment to tax revenue             = %7.3f %7.3f %7.3f %7.3f %7.3f \n',-DI./DTAX);
fprintf(fileID,'ratio of firm value to tax reveneu             = %7.3f %7.3f %7.3f %7.3f %7.3f \n',-DV./DTAX);
fclose(fileID);

% Table F.19
load([dropboxpath 'AnalysisData/Table_F19.mat'])
fileID = fopen([dropboxpath 'Output/Table_F19.txt'],'w');
fprintf(fileID,'percentage change in aggregate investment      = %7.3f %7.3f %7.3f \n',DI);
fprintf(fileID,'percentage change in frac. investment          = %7.3f %7.3f %7.3f \n',DEXT);
fprintf(fileID,'\n');
fprintf(fileID,'percentage change in aggregate tax revenue     = %7.3f %7.3f %7.3f \n',DTAX);
fprintf(fileID,'percentage change in average firm value        = %7.3f %7.3f %7.3f \n',DV);
fprintf(fileID,'\n');
fprintf(fileID,'ratio of investment to tax revenue             = %7.3f %7.3f %7.3f \n',-DI./DTAX);
fprintf(fileID,'ratio of firm value to tax reveneu             = %7.3f %7.3f %7.3f \n',-DV./DTAX);
fclose(fileID);

% Table F.20
load([dropboxpath 'AnalysisData/Table_F20.mat'])
fileID = fopen([dropboxpath 'Output/Table_F20.txt'],'w');
fprintf(fileID,'percentage change in ucc                       = %7.3f %7.3f %7.3f %7.3f %7.3f \n',DTUCC);
fprintf(fileID,'\n');
fprintf(fileID,'percentage change in aggregate investment      = %7.3f %7.3f %7.3f %7.3f %7.3f \n',DI);
fprintf(fileID,'percentage change in frac. investment          = %7.3f %7.3f %7.3f %7.3f %7.3f \n',DEXT);
fprintf(fileID,'\n');
fprintf(fileID,'percentage change in aggregate tax revenue     = %7.3f %7.3f %7.3f %7.3f %7.3f \n',DTAX);
fprintf(fileID,'percentage change in average firm value        = %7.3f %7.3f %7.3f %7.3f %7.3f \n',DV);
fprintf(fileID,'\n');
fprintf(fileID,'ratio of investment to tax revenue             = %7.3f %7.3f %7.3f %7.3f %7.3f \n',-DI./DTAX);
fprintf(fileID,'ratio of firm value to tax reveneu             = %7.3f %7.3f %7.3f %7.3f %7.3f \n',-DV./DTAX);
fclose(fileID);

% Table F.21
load([dropboxpath 'AnalysisData/Table_F21.mat'])
fileID = fopen([dropboxpath 'Output/Table_F21.txt'],'w');
fprintf(fileID,'percentage change in aggregate investment      = %7.3f %7.3f %7.3f %7.3f \n',DI);
fprintf(fileID,'percentage change in frac. investment          = %7.3f %7.3f %7.3f %7.3f \n',DEXT);
fprintf(fileID,'\n');
fprintf(fileID,'percentage change in aggregate tax revenue     = %7.3f %7.3f %7.3f %7.3f \n',DTAX);
fprintf(fileID,'percentage change in average firm value        = %7.3f %7.3f %7.3f %7.3f \n',DV);
fprintf(fileID,'\n');
fprintf(fileID,'ratio of investment to tax revenue             = %7.3f %7.3f %7.3f %7.3f \n',-DI./DTAX);
fprintf(fileID,'ratio of firm value to tax reveneu             = %7.3f %7.3f %7.3f %7.3f \n',-DV./DTAX);
fclose(fileID);

% Table F.22
load([dropboxpath 'AnalysisData/Table_F22.mat'])
fileID = fopen([dropboxpath 'Output/Table_F22.txt'],'w');
fprintf(fileID,'percentage change in tax rate                  = %7.3f %7.3f %7.3f %7.3f \n',DTPARS);
fprintf(fileID,'percentage change in depreciation write-off    = %7.3f %7.3f %7.3f %7.3f \n',0,0,0,0.7*100);
fprintf(fileID,'percentage change in ucc                       = %7.3f %7.3f %7.3f %7.3f \n',DTUCC);
fprintf(fileID,'\n');
fprintf(fileID,'percentage change in aggregate investment      = %7.3f %7.3f %7.3f %7.3f \n',DI);
fprintf(fileID,'percentage change in frac. investment          = %7.3f %7.3f %7.3f %7.3f \n',DEXT);
fprintf(fileID,'percentage change in aggregate tax revenue     = %7.3f %7.3f %7.3f %7.3f \n',DTAX);
fprintf(fileID,'\n');
fprintf(fileID,'ratio of investment to tax revenue             = %7.3f %7.3f %7.3f %7.3f \n',-DI./DTAX);
fclose(fileID);

% Table F.23
load([dropboxpath 'AnalysisData/Table_F23.mat'])
fileID = fopen([dropboxpath 'Output/Table_F23.txt'],'w');
fprintf(fileID,'DID. Extensive    = %7.3f %7.3f \n',DID_EXT);
fprintf(fileID,'DID. Intensive    = %7.3f %7.3f \n',DID_INT);
fclose(fileID);

% Table F.24
load([dropboxpath 'AnalysisData/Table_F24.mat'])
fileID = fopen([dropboxpath 'Output/Table_F24.txt'],'w');
fprintf(fileID,'percentage change in capital price             = %7.3f %7.3f %7.3f %7.3f %7.3f \n',DPK);
fprintf(fileID,'\n');
fprintf(fileID,'diff-in-diff, extensive margin                 = %7.3f %7.3f %7.3f %7.3f %7.3f \n',DID_EXT);
fprintf(fileID,'diff, extensive margin, domestic firms         = %7.3f %7.3f %7.3f %7.3f %7.3f \n',D_EXT_D);
fprintf(fileID,'diff, extensive margin, foreign  firms         = %7.3f %7.3f %7.3f %7.3f %7.3f \n',D_EXT_F);
fprintf(fileID,'\n');
fprintf(fileID,'diff-in-diff, intensive margin                 = %7.3f %7.3f %7.3f %7.3f %7.3f \n',DID_INT);
fprintf(fileID,'diff, intensive margin, domestic firms         = %7.3f %7.3f %7.3f %7.3f %7.3f \n',D_INT_D);
fprintf(fileID,'diff, intensive margin, foreign  firms         = %7.3f %7.3f %7.3f %7.3f %7.3f \n',D_INT_F);
fclose(fileID);
