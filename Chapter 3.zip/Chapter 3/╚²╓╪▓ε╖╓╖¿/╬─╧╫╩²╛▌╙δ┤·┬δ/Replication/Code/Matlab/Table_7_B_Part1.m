clearvars -except dropboxpath
clc
close all
% tic

% dropboxpath='/Users/xianjiang/Dropbox/Research/Fiscal Incentive and Investment/Replication/';
% cepath=[dropboxpath 'Code/Matlab/myfunctions/compecon/']; path([cepath 'cetools;' cepath 'cedemos'],path)
% 
% addpath([dropboxpath 'Code/Matlab/myfunctions'])
% addpath([dropboxpath 'Code/Matlab/estimation'])

%% import data
filename = 'clean_BB.csv';
M = importdata(filename);
M = M.data;  
colNames = {'id','year','r','k'}; 

M = array2table(M,'VariableNames',colNames);

%% estimation

sigma = 0.7;
alpha = 1/2;

idx = [(M.year == 2007), ...
       (M.year == 2008), ...
       (M.year == 2009), ...
       (M.year == 2010), ...
       (M.year == 2011)];
colNames = {'yr07','yr08','yr09','yr10','yr11'};
idx = array2table(idx,'VariableNames',colNames);

x0 = [.5;.5];

options = optimoptions(@fminunc,'Display','off','Algorithm','quasi-newton','OptimalityTolerance',1e-12,'MaxIterations',600);
par = fminunc(@(par) BB10(par,M,idx),x0,options);     % SYSGMM, iv   : s_L >= 2, s_D >= 3

theta = par(1,1);
rho   = par(2,1);

eta = theta/(alpha*(1-sigma)+((1-alpha)*(1-sigma)+sigma)*theta);
mkup1 = 1/eta;                                          % including capital cost
mkup2 = 1/(eta*((1-alpha)*(1-sigma)+sigma));            % excluding capital cost, sales


fprintf('theta                          = %10.3f \n',theta);
fprintf('rho                            = %10.3f \n',rho);
fprintf('eta                            = %10.3f \n',eta);
fprintf('markup(including capital cost) = %10.3f \n',mkup1);
fprintf('markup(excluding capital cost) = %10.3f \n\n',mkup2);
%fprintf('fval   = %10.0f \n',fval);

%% efficient GMM estimator

    % construct residuals 
    Y_L = [M.r(idx.yr10) - rho.* M.r(idx.yr09) - theta.* M.k(idx.yr10) + rho*theta.* M.k(idx.yr09), ...
           M.r(idx.yr11) - rho.* M.r(idx.yr10) - theta.* M.k(idx.yr11) + rho*theta.* M.k(idx.yr10)];
    L_Y = [M.r(idx.yr09) - rho.* M.r(idx.yr08) - theta.* M.k(idx.yr09) + rho*theta.* M.k(idx.yr08), ...
           M.r(idx.yr10) - rho.* M.r(idx.yr09) - theta.* M.k(idx.yr10) + rho*theta.* M.k(idx.yr09)];     
    Y_D = Y_L - L_Y; 

    Y = [Y_D,Y_L];
    [N,T] = size(Y);
    Y = reshape(Y',[N*T 1]);
    idx_Y = isnan(Y);           % missing values in Y vector
    Y(idx_Y) = 0;
    
    X = eye(T);
    X = kron(ones(N,1),X);

    b = (X'*X)\(X'*Y);
    U = (Y - X*b).*(~idx_Y);

    % construct instruments    
    
    Z = [M.r(idx.yr07)  M.k(idx.yr07) zeros(N,10), ...
         zeros(N,2) M.r(idx.yr07) M.k(idx.yr07) M.r(idx.yr08)  M.k(idx.yr08) zeros(N,6), ...
         zeros(N,6) M.r(idx.yr08)-M.r(idx.yr07)  M.k(idx.yr08)-M.k(idx.yr07) zeros(N,4), ...
         zeros(N,8) M.r(idx.yr08)-M.r(idx.yr07)  M.k(idx.yr08)-M.k(idx.yr07) M.r(idx.yr09)-M.r(idx.yr08)  M.k(idx.yr09)-M.k(idx.yr08)];
     
    Z = reshape(Z',[2*(2+4),N*T])';
   
    idx_Z = any(isnan(Z),2);    % missing values in Z vector
    Z(idx_Z,:) = 0;

    % construct optimal weighting matrix 
    Gamma = zeros(12,12);

    for i = 1 : N

        j = (i-1)*4;             % column index
        V = Z(j+1:j+4,:)'*U(j+1:j+4,1)*U(j+1:j+4,1)'*Z(j+1:j+4,:);
        Gamma = Gamma + V;

    end

    Gamma = Gamma/N;

%% standard error

% derivative 
DU_L = [-M.k(idx.yr10)+rho.*M.k(idx.yr09) -M.r(idx.yr09)+theta.*M.k(idx.yr09), ...
        -M.k(idx.yr11)+rho.*M.k(idx.yr10) -M.r(idx.yr10)+theta.*M.k(idx.yr10)];
L_DU = [-M.k(idx.yr09)+rho.*M.k(idx.yr08) -M.r(idx.yr08)+theta.*M.k(idx.yr08), ...
        -M.k(idx.yr10)+rho.*M.k(idx.yr09) -M.r(idx.yr09)+theta.*M.k(idx.yr09)];
DU_D = DU_L - L_DU;

DU = [DU_D,DU_L];
DU = reshape(DU',[2,N*T])';

idx_DU = any(isnan(DU),2);    % missing values in DU vector
DU(idx_DU,:) = 0;
    
G = Z'*DU/N;

Avar = (G'/Gamma*G)^(-1)/N;

se_theta = sqrt(Avar(1,1));
se_rho   = sqrt(Avar(2,2));

fprintf('standard error of theta        = %10.3f \n',se_theta);
fprintf('standard error of rho          = %10.3f \n\n',se_rho);

