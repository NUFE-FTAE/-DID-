
clearvars -except dropboxpath
clc
close all

% dropboxpath='/Users/xianjiang/Dropbox/Research/Fiscal Incentive and Investment/Replication/'; % revise this directory
% cepath=[dropboxpath 'Code/Matlab/myfunctions/compecon/']; path([cepath 'cetools;' cepath 'cedemos'],path)
% 
% addpath([dropboxpath 'Code/Matlab/myfunctions'])
% addpath([dropboxpath 'Code/Matlab/estimation'])
% addpath([dropboxpath 'RawData'])

%% SETTINGS
% set parameters
pars.p_s = 1;
pars.beta  = 0.95;  
pars.theta = 0.734;   

% policy relevant parameters
pars.nu = 0.17;
pars.tau = 0.154;
pars.n_dep =10;
pars.r = 1/pars.beta - 1;
pars.pv = (1./pars.n_dep).*(1+pars.r)/pars.r.*(1-(1+pars.r).^(-pars.n_dep));
pars.delta_dep = (1-pars.beta).*pars.pv./(1-pars.beta.*pars.pv);
 
% shock processes
pars.rho_b = 0.009;  
pars.sig_b = 0.010/(1-pars.theta);
pars.rho_e = 0.860;   
pars.sig_e = 0.529/(1-pars.theta); 
pars.sig_u = sqrt(1-pars.rho_e^2)*pars.sig_e;  %standard deviation of shocks
pars.sig_w = 0.854;

% simulation 
pars.T  = 101*2;                     % number of periods
pars.Tn = 15;                        % not using initial 15 periods
pars.Nf = 10000;                     % number of firms

% setting algorithm parameter values
pars.tol = 10^-8; 
pars.maxiter = 5000; 
        
% approximation basis
pars.nb = 5;
pars.ne = 20;
pars.m = 3;   %std for Tauchen's discretization
pars.nk = 31;
pars.nxi = 20;
pars.na = pars.nb*pars.ne;

% approximation grids 
[b_grid,P_b] = tauchen(0,sqrt(1-pars.rho_b^2)*pars.sig_b,pars.rho_b,pars.m,pars.nb); b_grid = exp(b_grid);
[e_grid,P_e] = tauchen(0,sqrt(1-pars.rho_e^2)*pars.sig_e,pars.rho_e,pars.m,pars.ne); e_grid = exp(e_grid);
[a_grid,I]   = sort(kron(b_grid,e_grid),'ascend');
P_a = kron(P_b,P_e);
P_a = P_a(I,I);
 
pars.k_min=1;
pars.k_max=10000;

curv = .4;
k_grid = linspace(pars.k_min.^curv,pars.k_max.^curv,pars.nk).^(1/curv);
k_grid = k_grid';
    
%% Load data moments 
mm_data = readtable('data_mm_b.xls');   
glob.mm_data = [mm_data.AvgI,mm_data.ShareI_0_1,mm_data.ShareI_0_2,mm_data.ShareI_0_3, ...
                mm_data.Corr_i_i___1__,mm_data.SDI,mm_data.DID_Ext,mm_data.DID_Int];
glob.V = eye(length(glob.mm_data));
    
 %% 1 SET PARAMETERS 
load Uniform_AB_idtw x

x = [x(1) x(2) 1 1 x(3)];

    % assign parameter values
    gamma       = x(1,1);
    xi_bar      = x(1,2);
    a           = x(1,3); 
    b           = x(1,4); 
    delta       = x(1,5);
    
    p_s         = pars.p_s;
    beta        = pars.beta;
    theta       = pars.theta;
    rho_e       = pars.rho_e;
    sig_u       = pars.sig_u;
    nu          = pars.nu;
    tau         = pars.tau;
    n_dep       = pars.n_dep;
    r           = pars.r;
    pv          = pars.pv;
    delta_dep   = pars.delta_dep;
    
    k_min       = pars.k_min;
    k_max       = pars.k_max;
    na          = pars.na;
    nxi         = pars.nxi;
    
    Tn          = pars.Tn;
	T           = pars.T; 
    Nf          = pars.Nf;
    
    tol         = pars.tol;
    maxiter     = pars.maxiter;

    fpars = [gamma;xi_bar;p_s;a;b];         % friction parameters
    apars = [beta;delta;theta;rho_e;sig_u];             % asigned parameters
    tpars = [nu;tau;n_dep;pv;delta_dep];    % policy parameters
    options = [tol,maxiter];

%% 2 SOLVE THE MODEL
        %% Approximation basis
        %  For solving the model
        fspace = fundef({'spli', k_grid, 0, 3}, ...
                        {'spli', a_grid, 0, 1});
        s_grid = funnode(fspace);
        s = gridmake(s_grid);
        ns = length(s);
        nk = ns/na;
        
        %%  Before the reform
        tpars_before=tpars;
        ce0 = funfitxy(fspace,s,s(:,2).^(1-theta).*s(:,1).^theta);            
        [ckprimeb_before,ckprimes_before,ce_before,cvb_before,cvs_before,ve_before] = sol_model(s,ce0,fspace,P_a,k_max,k_min,ns,nk,options,apars,fpars,tpars_before);
        
        %%  After the reform
        tpars_after = tpars;
        tpars_after(1) = 0;
        ce0 = ce_before;
        
        [ckprimeb_after,ckprimes_after,ce_after,cvb_after,cvs_after,ve_after] = sol_model(s,ce0,fspace,P_a,k_max,k_min,ns,nk,options,apars,fpars,tpars_after);
            
%% Simulate Moments
%  sim_firm
sim_firm_2021_03_29

%% Conditional fixed cost
% conditional mean of fixed cost draws (conditional on investing)
mean_xi = 0;
for i = 1:20
   mean_xi = mean_xi + mean(X_sim(I_sim(:,T/2-i)>0,T/2-i)); 
end
mean_xi = mean_xi/20;

% conditional average fraction of capital paid as fixed cost (conditional on investing)
mean_xik = 0;
for i = 1:20
   kstar=exp(1/(1-theta)*log((1-tau)) - 1/(1-theta)*log((1-beta*(1-delta))*pk/(beta*theta))).*exp(rho_e*(1-theta)*log(A_sim(:,t))+0.5*(rho_e*(1-theta))^2*sig_u^2);
   mean_xik = mean_xik + mean(X_sim(I_sim(:,T/2-i)>0,T/2-i).*kstar(I_sim(:,T/2-i)>0,1)./K_sim(I_sim(:,T/2-i)>0,T/2-i)); 
end
mean_xik = mean_xik/20;

% fprintf('average fixed cost draw                    (conditional on investing)  = %7.3f \n',mean_xi);
% fprintf('average fixed cost as frac. capital stock  (conditional on investing)  = %7.3f \n',mean_xik);

