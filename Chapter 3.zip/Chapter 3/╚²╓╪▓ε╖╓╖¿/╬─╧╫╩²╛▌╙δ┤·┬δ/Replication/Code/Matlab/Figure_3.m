% Xian Jiang
% Updated by September 1, 2019

clearvars -except dropboxpath
clc
close all
warning off all

% dropboxpath='/Users/xianjiang/Dropbox/Research/Fiscal Incentive and Investment/Replication/';
% cepath=[dropboxpath 'Code/Matlab/myfunctions/compecon/']; path([cepath 'cetools;' cepath 'cedemos'],path)
% 
% addpath([dropboxpath 'Code/Matlab/myfunctions'])
% addpath([dropboxpath 'Code/Matlab/estimation'])

load Uniform_AB_idtw.mat
 
pars.theta=.8;
k0 = 1;
x = (1:.001:25);

%% Fixed cost
pk = (1+pars.nu)*(1-pars.tau*pars.pv);
% pk = (1-pars.tau*pars.pv);
yopt = (1-pars.tau)*(1-pars.theta)*((1-pars.tau)*pars.theta/pk)^(pars.theta/(1-pars.theta)).* x + pk.*k0.*ones(size(x));
kopt = ((1-pars.tau)*pars.theta/pk)^(1/(1-pars.theta)).* x;

y0 = (1-pars.tau).*k0^(pars.theta).* x.^(1-pars.theta);
a0 = (pk/((1-pars.tau)*pars.theta))^(1/(1-pars.theta))*k0;

F = 0.045;
y1 = ((1-pars.tau)*pars.theta/pk)^(pars.theta/(1-pars.theta))*((1-pars.tau)*(1-pars.theta) - F*(1-pars.tau)*pars.theta/pk).* x + pk.*k0.*ones(size(x));
fun1 = @(x) ((1-pars.tau)*pars.theta/pk)^(pars.theta/(1-pars.theta))*((1-pars.tau)*(1-pars.theta) - F*(1-pars.tau)*pars.theta/pk).* x + pk.*k0.*ones(size(x)) ...
          - (1-pars.tau).*k0^(pars.theta).* x.^(1-pars.theta);
a = fsolve(fun1,[4,12]);
y2 = y1;
y2(x>=a(1)&x<=a(2)) = y0(x>=a(1)&x<=a(2));
k2 = kopt;
k2(x>=a(1)&x<=a(2)) = y0(x>=a(1)&x<=a(2)).^0.*k0;

% close all
% fig_yopt = figure;
% h1 = plot(x,yopt,'black');
% hold on
% h2 = plot(x,y0,'black--');
% xline(a0,':','a_{0}','LabelOrientation','horizontal','LabelVerticalAlignment','bottom','FontSize',13);
% xlabel('Productivity','Fontsize',14)
% ylabel('After-tax Profit','Fontsize',14)
% legend([h1,h2],{'Frictionless Optimal Profit (\Pi^{*})','Profit with initial capital (\Pi^{0})'},'FontSize',13,'Location','Northwest','box','off')

fig_y = figure;
h1 = plot(x,yopt,'black','Linewidth',2);
hold on
h2 = plot(x,y0,'black--','Linewidth',2);
h3 = plot(x,y1,'black-.','Linewidth',2);
h4 = plot(x,y2,'r','Linewidth',5);
% xline(a0,':','a_{0}','LabelOrientation','horizontal','LabelVerticalAlignment','bottom','FontSize',18,'Linewidth',2);
xline(a(1),':','a_{lb}','LabelOrientation','horizontal','LabelVerticalAlignment','bottom','FontSize',18,'Linewidth',1.5);
xline(a(2),':','a_{ub}','LabelOrientation','horizontal','LabelVerticalAlignment','bottom','FontSize',18,'Linewidth',1.5);
xlabel('Productivity','Fontsize',16)
ylabel('After-tax Profit','Fontsize',16)
ax = gca;
ax.FontSize = 13;
legend([h1,h3,h2,h4],{'Frictionless Optimal Profit (\Pi^{*})','Frictionless Optimal Profit, Net-of-Fixed Cost (\Pi^{*}-\xi k^*)','Profit with k_{0} (\Pi^{0})','Optimal Profit with Fixed Cost (\Pi^{f})'},'FontSize',16,'Location','Northwest','box','off')

% fig_kopt = figure;
% plot(x,kopt,'black');
% yline(k0,':','k_{0}','LabelHorizontalAlignment','right');
% xline(a0,':','a_{0}','LabelOrientation','horizontal','LabelVerticalAlignment','bottom','FontSize',13);
% xlabel('Productivity','Fontsize',14)
% ylabel('Optimal Capital Level','Fontsize',14)

fig_k = figure;
h1 = plot(x,kopt,'black-.','LineWidth',2);
% text(x(end-850),kopt(end-850),'Frictionless k^*','VerticalAlignment','bottom','HorizontalAlignment','right','Fontsize',13);
hold on
yline(k0,'k--','Linewidth',2,'Label','k_0','LabelVerticalAlignment','top','LabelHorizontalAlignment','right','Fontsize',18);
h2 = plot(x,k2,'r','Linewidth',5);
% xline(a0,':','a_{0}','LabelOrientation','horizontal','LabelVerticalAlignment','bottom','FontSize',13);
xline(a(1),':','a_{lb}','LabelOrientation','horizontal','LabelVerticalAlignment','bottom','FontSize',18,'Linewidth',1.5);
xline(a(2),':','a_{ub}','LabelOrientation','horizontal','LabelVerticalAlignment','bottom','FontSize',18,'Linewidth',1.5);
xlabel('Productivity','Fontsize',16)
ylabel('Optimal Capital Level','Fontsize',16)
ax = gca;
ax.FontSize = 13;
legend([h1,h2],{'Frictionless k^*','Optimal Capital'},'FontSize',16,'Location','Northwest','box','off')

saveas(fig_k, strcat(dropboxpath,'Output/Figure_3B.png'))
saveas(fig_y, strcat(dropboxpath,'Output/Figure_3A.png'))
