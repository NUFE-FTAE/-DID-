
clearvars -except dropboxpath
clc
close all
warning off all

% dropboxpath='/Users/xianjiang/Dropbox/Research/Fiscal Incentive and Investment/Replication/';
% cepath=[dropboxpath 'Code/Matlab/myfunctions/compecon/']; path([cepath 'cetools;' cepath 'cedemos'],path)
% 
% addpath([dropboxpath 'Code/Matlab/myfunctions'])
% addpath([dropboxpath 'Code/Matlab/estimation'])
% addpath([dropboxpath 'RawData'])

load([dropboxpath 'AnalysisData/Figure_F3.mat'])

%% Generate Graphs
mm_data = glob.mm_data;
diff = repmat(mm_data,[size(moments,1),1]) - moments;
weight = eye(size(mm_data,2));
loss = NaN([size(moments,1),1]);
for j = 1 : size(moments,1)
    loss(j,1) = diff(j,:)/weight*diff(j,:)';
end

% Plot
gamma  = x(1,1);
xi_bar = x(1,2);
delta  = x(1,3);
Nparm  = 3;
loss = log(reshape(loss,[length(loss)/Nparm,Nparm]));
loss_min = min(min(loss));

N = length(loss);

% gamma
fig_gamma = figure;
step = 2;
plot(GXI(2:step:N,1),loss(2:step:end,1)-loss_min,'Linewidth',2);
xline(gamma);
set(gca,'FontSize',16)
xlabel('\gamma','FontSize', 18)
ylabel('Log Loss Function','FontSize', 18)

% xi_bar
fig_xi_bar = figure;
step = 2;
plot(GXI(N+2:step:2*N,2),loss(2:step:end,2)-loss_min,'Linewidth',2);
xline(xi_bar);
set(gca,'FontSize',16)
xlabel('\xi_{max}','FontSize', 18)
ylabel('Log Loss Function','FontSize', 18)

% delta
fig_delta = figure;
step = 2;
plot(GXI(2*N+2:step:3*N,5),loss(2:step:end,3)-loss_min,'Linewidth',2);
xline(delta);
set(gca,'FontSize',16)
xlabel('\delta','FontSize', 18)
ylabel('Log Loss Function','FontSize', 18)

%% Save Graphs
saveas(fig_gamma , strcat(dropboxpath,'Output/Figure_F3A.png'))
saveas(fig_xi_bar, strcat(dropboxpath,'Output/Figure_F3B.png'))
saveas(fig_delta , strcat(dropboxpath,'Output/Figure_F3C.png'))