%% This is the main code that solves our Baseline Model
% Updated by May 30, 2020

clearvars -except dropboxpath
clc
close all
warning off all

% dropboxpath='/Users/xianjiang/Dropbox/Research/Fiscal Incentive and Investment/Replication/';
% cepath=[dropboxpath 'Code/Matlab/myfunctions/compecon/']; path([cepath 'cetools;' cepath 'cedemos'],path)
% 
% addpath([dropboxpath 'Code/Matlab/myfunctions'])
% addpath([dropboxpath 'Code/Matlab/estimation'])

%% Model parameters
% model fundamentals
p_s = 1;        % resale price
beta  = 0.95;	% discounting rate
r = 1/beta -1;	% market interest rate
delta = 0.071;	% economic depreciation rate
theta = 0.734;	% curvature of payoff function

% tax policy parameters
nu = 0.17;      % VAT rate
tau = 0.154;	% CIT rate
n_dep =10;      % number of years for straight-line depreciation

% calculate the current value of culmulative depreciation
pv = (1./n_dep).*(1+r)/r.*(1-(1+r).^(-n_dep));
 
% shock processes
rho_b = 0.00000000;     % aggregate shock
sig_b = 0.00000001;     % shut-down for graph
rho_e = 0.860;          % idiosyncratic shock
sig_e = 0.529/(1-theta); 
sig_w = 0.854;

% simulation 
T  = 101*2;                     % number of periods
Tn = 15;                        % not using initial 15 periods
Nf = 10000;                     % number of firms

% setting algorithm parameter values
tol = 10^-8; 
maxiter = 5000; 

%% Set Grids
% approximation basis
nb = 5;
ne = 20;
m = 3;   %std for Tauchen's discretization
nk = 41;
nxi = 20;
na = nb*ne;

% approximation grids 
[b_grid,P_b] = tauchen(0,sqrt(1-rho_b^2)*sig_b,rho_b,m,nb); b_grid = exp(b_grid);
[e_grid,P_e] = tauchen(0,sqrt(1-rho_e^2)*sig_e,rho_e,m,ne); e_grid = exp(e_grid);
[a_grid,I]   = sort(kron(b_grid,e_grid),'ascend');
P_a = kron(P_b,P_e);
P_a = P_a(I,I);
 
k_min=1;
k_max=10000;

curv = .4;
k_grid = linspace(k_min.^curv,k_max.^curv,nk).^(1/curv);
k_grid = k_grid';
    
 %% Structural Parameters to Estimate
 x = [0.05  0.01  1  1];
%  load Uniform_AB_idtw_ps_0602 x
%  x = [x(1),x(2),1,1];
 
    % assign parameter values
    gamma       = x(1,1);
    xi_bar      = x(1,2);
    a           = x(1,3); 
    b           = x(1,4); 
      
    fpars = [gamma;xi_bar;p_s;a;b];         % friction parameters
    apars = [beta;delta;theta;rho_e;sig_e];             % asigned parameters
    tpars = [nu;tau;n_dep;pv];    % policy parameters
    options = [tol,maxiter];

%% SOLVE THE MODEL
        %% Approximation basis
        %  For solving the model
        fspace = fundef({'spli', k_grid, 0, 3}, ...
                        {'spli', a_grid, 0, 1});
        s_grid = funnode(fspace);
        s = gridmake(s_grid);
        ns = length(s);
        nk = ns/na;
        
        %%  Before the reform
        tpars_before=tpars;
        ce0 = funfitxy(fspace,s,s(:,2).^(1-theta).*s(:,1).^theta);            
        [ckprimeb_before,ckprimes_before,ce_before,cvb_before,cvs_before,ve_before] = sol_model(s,ce0,fspace,P_a,k_max,k_min,ns,nk,options,apars,fpars,tpars_before);
        
        %%  After the reform
       tpars_after = tpars;

tau_after = 0;
nu_after  = (1-tpars_before(2))/(1-tau_after)*(1+tpars_before(1))*(1-tau_after*tpars_before(4))/(1-tpars_before(2)*tpars_before(4))-1;
pv_after  = 1/tpars_before(2)-(1+nu_after)/(1+tpars_before(1))*(1-tpars_before(2)*tpars_before(4))/tpars_before(2);

% tpars_after(1) = nu_after;    %change the tax instrument post-reform here!
% tpars_after(2) = tau_after;
tpars_after(4) = pv_after;


        ce0 = ce_before;
        [ckprimeb_after,ckprimes_after,ce_after,cvb_after,cvs_after,ve_after] = sol_model(s,ce0,fspace,P_a,k_max,k_min,ns,nk,options,apars,fpars,tpars_after);
        
%         %% After a 17% VAT cut (uncomment this section for CIT and BD cut)
%         tpars_after2 = tpars;
%         tpars_after2(1) = 0; % change the tax instrument post-reform here!
%         
%         ce0 = ce_before;
%         [~,~,ce_after2,~,~,~] = sol_model(s,ce0,fspace,P_a,k_max,k_min,ns,nk,options,apars,fpars,tpars_after2);
        
       %% Summarize Policy Function for a specific xi
       
       ns = 10000; 
       xi = 0.005;
       rho_e = apars(4);
       sig_u = sqrt(1-rho_e^2)*sig_e;%sig_u = apars(5);
       a_sim = linspace(min(a_grid),max(a_grid),ns)';
       k_sim = repmat(k_grid(20),size(a_sim));
 
       %calculate optimal policies before
       [kprime_b1,vb1] = goldenx(@(x) val_b(x,a_sim,k_sim,ce_before,fspace,apars,fpars,tpars_before),(1-delta).*k_sim,k_max.*ones(ns,1));
       [kprime_s1,vs1] = goldenx(@(x) val_s(x,a_sim,k_sim,ce_before,fspace,apars,fpars,tpars_before),k_min.*ones(ns,1),(1-delta).*k_sim);   
       vi1 =  beta.*funeval(ce_before,fspace,[(1-delta).*k_sim,a_sim]);
       
       nu = tpars_before(1);
       tau= tpars_before(2);
       pv = tpars_before(4);
       pk = (1 - tau.*pv).*(1+nu); 
       kstar=exp(1/(1-theta)*log((1-tau)) - 1/(1-theta)*log((1-beta*(1-delta))*pk/(beta*theta))).*exp(rho_e*(1-theta)*log(a_sim)+0.5*(rho_e*(1-theta))^2*sig_u^2);
       
        
        idx1 = ++(vb1>vs1);
        idx2 = ++(max(vb1,vs1)-xi*kstar>vi1);
        
        kprime_sim1 = dprod(idx2,dprod(idx1,kprime_b1)+dprod((1-idx1),kprime_s1)) + dprod((1-idx2),(1-delta).*k_sim);
        
        %calculate optimal policies after
       [kprime_b2,vb2] = goldenx(@(x) val_b(x,a_sim,k_sim,ce_after,fspace,apars,fpars,tpars_after),(1-delta).*k_sim,k_max.*ones(ns,1));
       [kprime_s2, vs2] = goldenx(@(x) val_s(x,a_sim,k_sim,ce_after,fspace,apars,fpars,tpars_after),k_min.*ones(ns,1),(1-delta).*k_sim);   
       vi2 =  beta.*funeval(ce_after,fspace,[(1-delta).*k_sim,a_sim]);

       nu = tpars_after(1);       
       tau= tpars_after(2);
       pv = tpars_after(4);
       pk = (1 - tau.*pv).*(1+nu); 
       kstar=exp(1/(1-theta)*log((1-tau)) - 1/(1-theta)*log((1-beta*(1-delta))*pk/(beta*theta))).*exp(rho_e*(1-theta)*log(a_sim)+0.5*(rho_e*(1-theta))^2*sig_u^2);
       
        idx1 = ++(vb2>vs2);
        idx2 = ++(max(vb2,vs2)-xi*kstar>vi2);
        
        kprime_sim2 = dprod(idx2,dprod(idx1,kprime_b2)+dprod((1-idx1),kprime_s2)) + dprod((1-idx2),(1-delta).*k_sim);
        
%             %calculate optimal policies after a 17% vat cut (uncomment this section for CIT and BD cut)
%             [kprime_b3,vb3] = goldenx(@(x) val_b(x,a_sim,k_sim,ce_after2,fspace,apars,fpars,tpars_after2),(1-delta).*k_sim,k_max.*ones(ns,1));
%             [kprime_s3,vs3] = goldenx(@(x) val_s(x,a_sim,k_sim,ce_after2,fspace,apars,fpars,tpars_after2),k_min.*ones(ns,1),(1-delta).*k_sim);   
%             vi3 =  beta.*funeval(ce_after2,fspace,[(1-delta).*k_sim,a_sim]);
% 
%             nu = tpars_after2(1);       
%             tau= tpars_after2(2);
%             pv = tpars_after2(4);
%             pk = (1 - tau.*pv).*(1+nu); 
%             kstar=exp(1/(1-theta)*log((1-tau)) - 1/(1-theta)*log((1-beta*(1-delta))*pk/(beta*theta))).*exp(rho_e*(1-theta)*log(a_sim)+0.5*(rho_e*(1-theta))^2*sig_u^2);
% 
%             idx1 = ++(vb3>vs3);
%             idx2 = ++(max(vb3,vs3)-xi*kstar>vi3);
% 
%             kprime_sim3 = dprod(idx2,dprod(idx1,kprime_b3)+dprod((1-idx1),kprime_s3)) + dprod((1-idx2),(1-delta).*k_sim);
        
        %use analytical formula
%         nu = tpars_after(1);
        nu = 0;
        tau= tpars_before(2);
        pv = tpars_before(4);
        pk = (1 - tau.*pv).*(1+nu); 
        kprime_frictionless = exp(1/(1-theta)*log((1-tau)*P_a*a_grid.^(1-theta)) - 1/(1-theta)*log((1-beta*(1-delta))*pk/(beta*theta)));
        fspace_frictionless = fundef({'spli', a_grid, 0, 1});
        ck_frictionless = funfitxy(fspace_frictionless,a_grid,kprime_frictionless);
        kprime_frictionless = funeval(ck_frictionless,fspace_frictionless,a_sim);

        %% + Graphs
%         policy0 = figure;
%         h0 = plot(log(a_sim),log(kprime_frictionless),'linewidth',2,'LineStyle',':','Color','k');
%         hold on 
%         h1 = plot(log(a_sim),log(kprime_sim1),'--','linewidth',2.5,'Color','k');
%         line([min(log(a_sim)) max(log(a_sim))],[log(kprime_sim1(50,1)) log(kprime_sim1(50,1))],'LineStyle','-','Color','k')
%         xlim([-2 3.5])
%         ylim([6.2 8.4])
%         yticks([6.2 6.5 6.8 7.1 7.4 7.7 8 8.3 ])
%         legend([h0 h1],{'Frictionless','Pre-reform'},'Location','southeast','FontSize',16)
%         legend boxoff 
%         ax = gca;
%         ax.FontSize = 13;
%         xlabel('Log Productivity A','FontSize', 18)
%         ylabel('Log Capital Next Period Kprime ','FontSize', 18)
            
%             % VAT (with both 4% and 17% cut)
%             policy_vat = figure;
%             h0 = plot(log(a_sim),log(kprime_frictionless),'linewidth',2,'LineStyle',':','Color','k');
%             hold on 
%             h1 = plot(log(a_sim),log(kprime_sim1),'--','linewidth',2.5,'Color','k');
%             hold on
%             h2 = plot(log(a_sim),log(kprime_sim2),'-','linewidth',3,'Color','r');
%             h3 = plot(log(a_sim),log(kprime_sim3),'-.','linewidth',3,'Color','b');
%             line([min(log(a_sim)) max(log(a_sim))],[log(kprime_sim1(50,1)) log(kprime_sim1(50,1))],'LineStyle','-','Color','k')
%             xlim([-2 3.5])
%             ylim([6.2 8.4])
%             yticks([6.2 6.5 6.8 7.1 7.4 7.7 8 8.3 ])
% %             legend([h0 h1 h2],{'Frictionless','Pre-reform','Bonus Depreciation'},'Location','southeast','FontSize',16)
%             legend([h0 h1 h2 h3],{'Frictionless','Pre-reform','VAT Reform (4%)', 'VAT Reform (17%)'},'Location','southeast','FontSize',16)
% %             legend([h0 h1 h2],{'Frictionless','Pre-reform','CIT Reform'},'Location','southeast','FontSize',16)
%             legend boxoff 
%             ax = gca;
%             ax.FontSize = 13;
%             xlabel('Log Productivity A','FontSize', 18)
%             ylabel('Log Capital Next Period Kprime ','FontSize', 18)
            
            % CIT and BD
            policy = figure;
            h0 = plot(log(a_sim),log(kprime_frictionless),'linewidth',2,'LineStyle',':','Color','k');
            hold on 
            h1 = plot(log(a_sim),log(kprime_sim1),'--','linewidth',2.5,'Color','k');
            hold on
            h2 = plot(log(a_sim),log(kprime_sim2),'-','linewidth',3,'Color','r');
            line([min(log(a_sim)) max(log(a_sim))],[log(kprime_sim1(50,1)) log(kprime_sim1(50,1))],'LineStyle','-','Color','k')
            xlim([-2 3.5])
            ylim([6.2 8.4])
            yticks([6.2 6.5 6.8 7.1 7.4 7.7 8 8.3 ])
            legend([h0 h1 h2],{'Frictionless','Pre-reform','Bonus Depreciation'},'Location','southeast','FontSize',16)
%             legend([h0 h1 h2],{'Frictionless','Pre-reform','VAT Reform'},'Location','southeast','FontSize',16)
%             legend([h0 h1 h2],{'Frictionless','Pre-reform','CIT Reform'},'Location','southeast','FontSize',16)
            legend boxoff 
            ax = gca;
            ax.FontSize = 13;
            xlabel('Log Productivity A','FontSize', 18)
            ylabel('Log Capital Next Period Kprime ','FontSize', 18)
            
saveas(policy, strcat(dropboxpath,'Output/Figure_4D.png'))

       