% Updated by Jan 29, 2022

clearvars -except dropboxpath
clc
close all
warning off all

% % dropboxpath='/hpc/group/econ/xj18/VATreform/';
% % cepath=[dropboxpath 'compecon/'];
% % path([cepath 'CEtools;' cepath 'CEdemos'],path);
% % addpath([dropboxpath 'myfunctions'])
% 
% dropboxpath='/Users/xianjiang/Dropbox/Research/Fiscal Incentive and Investment/Replication/';
% cepath=[dropboxpath 'Code/Matlab/myfunctions/compecon/']; path([cepath 'cetools;' cepath 'cedemos'],path)
% 
% addpath([dropboxpath 'Code/Matlab/myfunctions'])
% addpath([dropboxpath 'Code/Matlab/estimation'])
% addpath([dropboxpath 'RawData'])

%% SETTINGS
% set parameters
pars.p_s = 1;
pars.beta  = 0.95;  
pars.theta = 0.734;   

% policy relevant parameters
pars.nu = 0.17;
pars.tau = 0.154;
pars.n_dep =10;
pars.r = 1/pars.beta - 1;
pars.pv = (1./pars.n_dep).*(1+pars.r)/pars.r.*(1-(1+pars.r).^(-pars.n_dep));
pars.delta_dep = (1-pars.beta).*pars.pv./(1-pars.beta.*pars.pv);
 
% shock processes
pars.rho_b = 0.009;  
pars.sig_b = 0.010/(1-pars.theta);
pars.rho_e = 0.860;   
pars.sig_e = 0.529/(1-pars.theta); 
pars.sig_u = sqrt(1-pars.rho_e^2)*pars.sig_e;  %standard deviation of shocks
pars.sig_w = 0.854;

% simulation 
pars.T  = 101*2;                     % number of periods
pars.Tn = 15;                        % not using initial 15 periods
pars.Nf = 10000;                     % number of firms

% setting algorithm parameter values
pars.tol = 10^-8; 
pars.maxiter = 5000; 
        
% approximation basis
pars.nb = 5;
pars.ne = 20;
pars.m = 3;   %std for Tauchen's discretization
pars.nk = 31;
pars.nxi = 20;
pars.na = pars.nb*pars.ne;

% approximation grids 
[b_grid,P_b] = tauchen(0,sqrt(1-pars.rho_b^2)*pars.sig_b,pars.rho_b,pars.m,pars.nb); b_grid = exp(b_grid);
[e_grid,P_e] = tauchen(0,sqrt(1-pars.rho_e^2)*pars.sig_e,pars.rho_e,pars.m,pars.ne); e_grid = exp(e_grid);
[a_grid,I]   = sort(kron(b_grid,e_grid),'ascend');
P_a = kron(P_b,P_e);
P_a = P_a(I,I);
 
pars.k_min=1;
pars.k_max=10000;

curv = .4;
k_grid = linspace(pars.k_min.^curv,pars.k_max.^curv,pars.nk).^(1/curv);
k_grid = k_grid';

pars.na = length(a_grid);
glob.k_grid = k_grid;
glob.e_grid = e_grid;
glob.b_grid = b_grid;
glob.a_grid = a_grid;
glob.P_a = P_a;
    
%% Load data moments 
mm_data = readtable('data_mm_b.xls');   
glob.mm_data = [mm_data.AvgI,mm_data.ShareI_0_1,mm_data.ShareI_0_2,mm_data.ShareI_0_3, ...
                mm_data.Corr_i_i___1__,mm_data.SDI,mm_data.DID_Ext,mm_data.DID_Int];
glob.V = eye(length(glob.mm_data));
clearvars -except dropboxpath pars glob

%% Main
load Uniform_AB_idtw x

gamma  = x(1,1);
xi_bar = x(1,2);
delta  = x(1,3);

tol = .3;
Np  = 51;

GAMMA_ALL  = linspace(gamma*(1-tol),gamma*(1+tol),Np)';
XI_BAR_ALL = linspace(xi_bar*(1-tol),xi_bar*(1+tol),Np)';
DELTA_ALL  = linspace(delta*(1-tol),delta*(1+tol),Np)';

GXI = [GAMMA_ALL,           repmat(xi_bar,Np,1), ones(Np,2),repmat(delta,Np,1);...
       repmat(gamma,Np,1),  XI_BAR_ALL,          ones(Np,2),repmat(delta,Np,1);...
       repmat(gamma,Np,1),  repmat(xi_bar,Np,1), ones(Np,2),DELTA_ALL];
 
% Calculate moments
moments = NaN(size(GXI,1),size(glob.mm_data,2));
parfor numero = 1:size(GXI,1)
    
    frictions = GXI(numero,:);
    moments(numero,:) = moments_2021_03_29(frictions,pars,glob);
    
end

