% Xian Jiang
% Updated by September 1, 2019

clearvars -except dropboxpath
clc
close all
warning off all

% dropboxpath='/Users/xianjiang/Dropbox/Research/Fiscal Incentive and Investment/Replication/';
% cepath=[dropboxpath 'Code/Matlab/myfunctions/compecon/']; path([cepath 'cetools;' cepath 'cedemos'],path)
% 
% addpath([dropboxpath 'Code/Matlab/myfunctions'])
% addpath([dropboxpath 'Code/Matlab/estimation'])

load Uniform_AB_idtw.mat
 
pars.theta=.8;
%%% Marginal product of capital
pb = (1+.17)*(1-.154*pars.pv);
ps = 1-.154*pars.pv*(1+.17);
k0 = 1;
f = @(x) (1-.154).*pars.theta.*x.^(1-pars.theta);
fun1 = @(x) (1-.154).*pars.theta.*x.^(1-pars.theta).*k0^(pars.theta-1) - pb;
fun2 = @(x) (1-.154).*pars.theta.*x.^(1-pars.theta).*k0^(pars.theta-1) - ps;
aub = fsolve(fun1,4);
alb = fsolve(fun2,6);

x = (1:.001:25);
y = f(x);
y2 = y;
y2(x<=alb) = ps;
y2(x>=aub) = pb;

fig_mpk = figure;
h1 = plot(x,y,'--','Linewidth',3,'Color','k');
yline(pb,'k-.','Linewidth',2,'Label','p_b','LabelVerticalAlignment','top','LabelHorizontalAlignment','left','Fontsize',16);
yline(ps,'k-.','Linewidth',2,'Label','p_s','LabelVerticalAlignment','top','LabelHorizontalAlignment','left','Fontsize',16);
xline(aub,':');
xline(alb,':');
hold on
h2 = plot(x,y2,'r','Linewidth',5);
xlabel('Productivity','Fontsize',16)
ylabel('Marginal Product of Capital','Fontsize',16)
ax = gca;
ax.FontSize = 13;
legend([h1 h2],{'MPK with k_0','Optimal MPK'},'FontSize',16,'Location','Northwest','box','off')

%%% Optimal captial
kfun1 = @(x) ((1-.154)*pars.theta/pb)^(1/(1-pars.theta)).*x;
kfun2 = @(x) ((1-.154)*pars.theta/ps)^(1/(1-pars.theta)).*x;

kb = kfun1(x);
ks = kfun2(x);
k2 = k0.*ones(size(kb));
k2(x<=alb) = ks(x<=alb);
k2(x>=aub) = kb(x>=aub);

fig_k = figure;
h1 = plot(x,kb,'k-.','Linewidth',2);
hold on
h2 = plot(x,ks,'k-.','Linewidth',2);
text(x(end-1300),kb(end-1300),'k_b^*','VerticalAlignment','top','Fontsize',18);
text(x(end-1300),ks(end-1300),'k_s^*','VerticalAlignment','top','Fontsize',18);
h3 = plot(x,k2,'r','Linewidth',5);
yline(k0,'k--','Linewidth',2,'Label','k_0','LabelVerticalAlignment','top','Fontsize',18);
xline(aub,':');
xline(alb,':');
xlabel('Productivity','Fontsize',16)
ylabel('Optimal Capital Level','Fontsize',16)
ax = gca;
ax.FontSize = 13;
legend(h3,{'Optimal Capital'},'FontSize',16,'Location','Northwest','box','off')

saveas(fig_k, strcat(dropboxpath,'Output/Figure_2B.png'))
saveas(fig_mpk, strcat(dropboxpath,'Output/Figure_2A.png'))

