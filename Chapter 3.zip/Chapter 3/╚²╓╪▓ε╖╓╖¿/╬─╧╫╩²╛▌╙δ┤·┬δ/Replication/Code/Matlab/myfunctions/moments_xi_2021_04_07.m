% Xian Jiang
% Updated by April 7, 2019

% This file simulate moments for given (gamma,xi) where gamma is convex
% adjustment cost, and xi is the value of fixed cost.

function mm_sim = moments_xi_2021_04_07(x,pars,glob)
    %% SET PARAMETERS
    gamma       = x(1,1);
    xi          = x(1,2);
    delta       = x(1,3);
    
    p_s         = pars.p_s;
    beta        = pars.beta;
    %delta       = pars.delta;
    theta       = pars.theta;
    rho_e     = pars.rho_e;
    sig_u     = pars.sig_u;
    nu          = pars.nu;
    tau         = pars.tau;
    n_dep       = pars.n_dep;
    r           = pars.r;
    pv          = pars.pv;
    delta_dep   = pars.delta_dep;
    
    k_min       = pars.k_min;
    k_max       = pars.k_max;
    na          = pars.na;
    nxi         = pars.nxi;
    
    Tn          = pars.Tn;
	T           = pars.T; 
    Nf          = pars.Nf;
    
    tol         = pars.tol;
    maxiter     = pars.maxiter;
    
    k_grid      = glob.k_grid;
    b_grid      = glob.b_grid;
    e_grid      = glob.e_grid;
    a_grid      = glob.a_grid;
    P_a         = glob.P_a;
    
    % define vectors
    fpars = [gamma;xi;p_s];
    apars = [beta;delta;theta;rho_e;sig_u];             % asigned parameters
    tpars = [nu;tau;n_dep;pv;delta_dep];
    options = [tol,maxiter];

        %% Approximation basis   
        P = P_a;
        fspace = fundef({'spli', k_grid, 0, 3}, ...
                        {'spli', a_grid, 0, 1});
        s_grid = funnode(fspace);
        s = gridmake(s_grid);
        ns = length(s);
        nk = ns/na;

        %% Solve the model 
        %  BEFORE THE REFORM
        tpars_before=tpars;
            ce0 = funfitxy(fspace,s,s(:,2).^(1-theta).*s(:,1).^theta);            
            [ckprimeb_before,ckprimes_before,ce_before,cvb_before,cvs_before,ve_before] = sol_model_xi(s,ce0,fspace,P,k_max,k_min,ns,nk,options,fpars,apars,tpars_before);
                        
        % AFTER THE REFORM
        tpars_after = tpars;
        tpars_after(1) = 0.0;
            ce0 = funfitxy(fspace,s,ve_before);
            clear ve_before
            [ckprimeb_after,ckprimes_after,ce_after,cvb_after,cvs_after,~] = sol_model_xi(s,ce0,fspace,P,k_max,k_min,ns,nk,options,fpars,apars,tpars_after);
            
%% Simulate Moments
 sim_firm_xi_2021_04_07
 
%  mm_sim = [mm1,dist5,dist10,dist20,dist30,mm4,mm6,mm11,b_ind,b_IK,mean(IRF_sim(1,1:3)),mean(IRF_sim(2,1:3)),mm10,mm7];
mm_sim = [mm1,dist10,dist20,dist30,mm6,mm11,mean(IRF_sim(1,1:3)),mean(IRF_sim(2,1:3))];
end