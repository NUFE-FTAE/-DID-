function b = FEreg(dependentvar,regressorvar)

    [s1,~] = size(dependentvar);
    Y = vec((dependentvar-repmat(mean(dependentvar,2),1,5))');
    X = repmat(((regressorvar-repmat(mean(regressorvar),1,5)))',s1,1);
    b = X'*X\(X'*Y);

end
