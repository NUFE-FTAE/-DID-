% This function evaluates loss function given frictions

function f = loss_xi_2021_04_07(x,idx,mm_data,V,pars,glob)
% x: frictions to estimate [gamma,xi_bar,p,q]
% idx: the index of moments to use
% mm_data: target data moments
% V: weighting matrix
% pars: auxiliary parameters
% glob: auxiliary matrices

    mm_sim = moments_xi_2021_04_07(x,pars,glob);
    mm = mm_sim(idx);
    
    f = (mm_data-mm)/V*(mm_data-mm)';

end