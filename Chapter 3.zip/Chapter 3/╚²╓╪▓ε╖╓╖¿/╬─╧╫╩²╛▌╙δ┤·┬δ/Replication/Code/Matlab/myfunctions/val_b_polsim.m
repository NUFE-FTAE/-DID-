% value function of positive investment

function f = val_b_polsim(x,aa,kk,ce,fspace,apars,fpars,tpars)

    beta  = apars(1);
    delta = apars(2);
    
    gamma = fpars(1);

    nu    = tpars(1);
    tau   = tpars(2);
    pv    = tpars(4);
    itc   = tpars(6);
    
    pb = (1 - tau*pv)*(1 + nu)-itc;
    
    f = - pb.*(x-(1-delta).*kk) - (gamma/2).*(x-(1-delta).*kk).^2./kk ...
        + beta.*funeval(ce,fspace,[x,aa]);

end