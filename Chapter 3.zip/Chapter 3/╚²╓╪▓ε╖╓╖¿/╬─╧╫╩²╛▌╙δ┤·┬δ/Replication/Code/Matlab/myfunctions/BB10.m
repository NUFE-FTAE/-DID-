function f = BB10(par,M,idx)

% Blundell and Bond: system GMM

    theta = par(1,1);
    rho   = par(2,1);

    %% construct residuals 
    Y_L = [M.r(idx.yr10) - rho.* M.r(idx.yr09) - theta.* M.k(idx.yr10) + rho*theta.* M.k(idx.yr09), ...
           M.r(idx.yr11) - rho.* M.r(idx.yr10) - theta.* M.k(idx.yr11) + rho*theta.* M.k(idx.yr10)];
    L_Y = [M.r(idx.yr09) - rho.* M.r(idx.yr08) - theta.* M.k(idx.yr09) + rho*theta.* M.k(idx.yr08), ...
           M.r(idx.yr10) - rho.* M.r(idx.yr09) - theta.* M.k(idx.yr10) + rho*theta.* M.k(idx.yr09)];     
    Y_D = Y_L - L_Y; 

    Y = [Y_D,Y_L];
    [N,T] = size(Y);
    Y = reshape(Y',[N*T 1]);
    idx_Y = isnan(Y);           % missing values in Y vector
    Y(idx_Y) = 0;
    
    X = eye(T);
    X = kron(ones(N,1),X);

    b = (X'*X)\(X'*Y);
    U = (Y - X*b).*(~idx_Y);

    %% construct instruments    
    Z = [M.r(idx.yr07)  M.k(idx.yr07) zeros(N,10), ...
         zeros(N,2) M.r(idx.yr07) M.k(idx.yr07) M.r(idx.yr08)  M.k(idx.yr08) zeros(N,6), ...
         zeros(N,6) M.r(idx.yr08)-M.r(idx.yr07)  M.k(idx.yr08)-M.k(idx.yr07) zeros(N,4), ...
         zeros(N,8) M.r(idx.yr08)-M.r(idx.yr07)  M.k(idx.yr08)-M.k(idx.yr07) M.r(idx.yr09)-M.r(idx.yr08)  M.k(idx.yr09)-M.k(idx.yr08)];
     
    Z = reshape(Z',[2*(2+4),N*T])';
    
    idx_Z = any(isnan(Z),2);    % missing values in Z vector
    Z(idx_Z,:) = 0;

    % construct estimator
    f = (Z'*U)'/(1/N*(Z')*Z)*(Z'*U);

end