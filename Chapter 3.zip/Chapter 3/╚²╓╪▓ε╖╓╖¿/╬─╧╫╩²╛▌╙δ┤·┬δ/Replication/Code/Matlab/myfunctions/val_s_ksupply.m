% value function of positive investment

function f = val_s_ksupply(x,aa,kk,ce,fspace,apars,fpars,tpars)

    beta  = apars(1);
    delta = apars(2);
    
    gamma = fpars(1);

    nu    = tpars(1);
    tau   = tpars(2);
    pv    = tpars(4);
    dpk   = tpars(6);
    
    ps = (1+dpk)*(1 - tau*pv*(1 + nu));
%     ps = (1 - tau*pv*(1 + nu)*(1+dpk));

    f = - ps.*(x-(1-delta).*kk)  - (gamma/2).*((x-(1-delta).*kk)./kk).^(2).*kk  ...
        + beta.*funeval(ce,fspace,[x,aa]);

end