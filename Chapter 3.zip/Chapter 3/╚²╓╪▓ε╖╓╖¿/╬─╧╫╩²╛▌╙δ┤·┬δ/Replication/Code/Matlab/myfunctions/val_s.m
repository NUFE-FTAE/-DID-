% value function of positive investment

function f = val_s(x,aa,kk,ce,fspace,apars,fpars,tpars)

    beta  = apars(1);
    delta = apars(2);
    %theta = apars(3);
    
    gamma = fpars(1);
    p_s   = fpars(3);

    nu    = tpars(1);
    tau   = tpars(2);
    pv    = tpars(4);
    
%     ps = (1 - tau*pv*(1 + nu));
    ps = p_s - tau*pv*(1 + nu);

    f = - ps.*(x-(1-delta).*kk)  - (gamma/2).*((x-(1-delta).*kk)./kk).^(2).*kk  ...
        + beta.*funeval(ce,fspace,[x,aa]);

end