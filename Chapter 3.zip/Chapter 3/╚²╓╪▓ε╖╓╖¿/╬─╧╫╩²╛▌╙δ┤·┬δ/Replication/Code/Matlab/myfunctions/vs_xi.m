% value function of negative investment

function f = vs_xi(x,aa,kk,ce,fspace,fpars,apars,tpars,kstar)


gamma = fpars(1);
xi    = fpars(2);
p_s   = fpars(3);

beta  = apars(1);
delta = apars(2);
theta = apars(3);

nu    = tpars(1);
tau   = tpars(2);
pv    = tpars(4);


	f = (1-tau).*aa.^(1-theta).*kk.^theta - (p_s - tau*pv*(1 + nu)).*(x-(1-delta).*kk) - xi.*kstar - (gamma/2).*(x-(1-delta).*kk).^2./kk ...
      + beta.*funeval(ce,fspace,[x,aa]);
end