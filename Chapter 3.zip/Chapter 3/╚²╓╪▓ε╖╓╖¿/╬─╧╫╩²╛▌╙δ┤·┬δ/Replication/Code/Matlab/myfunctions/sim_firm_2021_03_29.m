
%March, 2021

% Simulate firm-specific shocks
T = 200;
Nf = 10000;

%%Option 1: Directly Simulating Shocks
%initial draw from stationary dist.
E_sim=zeros(Nf,T);
rng('default'); rng(333);
E_sim(:,1) = normrnd(0, pars.sig_e, Nf,1);
for t=2:1:T
    E_sim(:,t) = pars.rho_e*E_sim(:,t-1) + normrnd(0, sqrt(1 - pars.rho_e^2)*pars.sig_e, Nf, 1);
    %truncate idiosyncratic shocks grids
    E_sim(:,t) = min(max(min(log(e_grid)),E_sim(:,t)),max(log(e_grid)));
end
%check autcorrelation and std of simulated shocks
% disp('check')
% [corr(vec(E_sim(:,1:T-1)), vec(E_sim(:,2:T))), mean(std(E_sim))]

B_sim=zeros(1,T);
rng('default'); rng(666)
B_sim(1)=normrnd(0, pars.sig_b/(sqrt(1-pars.rho_b^2)));
for t=2:1:T
    B_sim(t) = pars.rho_b*B_sim(t-1) + normrnd(0, pars.sig_b);
 end
A_sim = exp(E_sim + repmat(B_sim,Nf,1));

%%Option 2: Simulate Shocks on the grids
% [B_sim,E_sim] = shocks(Nf,T,b_grid,P_b,e_grid,P_e);
% disp('check')
% [pars.rho_e  pars.sig_e]
% [corr(vec(log(E_sim(:,1:T-1))), vec(log(E_sim(:,2:T)))), mean(std(log(E_sim(:,end-10:end))))]
% A_sim = E_sim.*B_sim;

%%Idiosyncratic fixed cost
rng('default'); rng(999)
X_sim = x(2)*betarnd(x(3),x(4),Nf,T);

%%% Simulate investment 
%initial capital stock based on frictionless model
K_sim = zeros(Nf,T);
%K_sim(:,1)= (pars.theta*pars.beta/(1-pars.beta*(1-pars.delta)))^(1/(1-pars.theta));   %Steady State
K_sim(:,1) = 500;
% V_sim = zeros(Nf,T);

%Start to simulate for pre-period
for t = 1 : T/2-1
  
  
    pk = (1 - tau.*pv).*(1+nu); 
  
    %option 0, baseline
    %kstar = K_sim(:,t); 
    %option 1, common across firms
    %kstar=exp(1/(1-theta)*log((1-tau)) - 1/(1-theta)*log((1-beta*(1-delta))*pk/(beta*theta)));
    %option 2, use firm-specific aa
    kstar=exp(1/(1-theta)*log((1-tau)) - 1/(1-theta)*log((1-beta*(1-delta))*pk/(beta*theta))).*exp(rho_e*(1-theta)*log(A_sim(:,t))+0.5*(rho_e*(1-theta))^2*sig_u^2);
  
  %     tic
  vb = funeval(cvb_before,fspace,[K_sim(:,t),A_sim(:,t)]);
  vs = funeval(cvs_before, fspace,[K_sim(:,t),A_sim(:,t)]);
  vi = beta*funeval(ce_before,fspace,[(1-delta).*K_sim(:,t),A_sim(:,t)]);
  
  kprimeb = funeval(ckprimeb_before,fspace,[K_sim(:,t),A_sim(:,t)]);
  kprimes = funeval(ckprimes_before,fspace,[K_sim(:,t),A_sim(:,t)]);
  
  %  find the inaction, buy, or sell
  idx1 = ++(vb>vs);   
  idx2 = ++(max(vb,vs)-X_sim(:,t).*kstar>vi);
  
  %  update capital
  kprime = dprod(idx2,dprod(idx1,kprimeb)+dprod((1-idx1),kprimes)) + dprod((1-idx2),(1-delta).*K_sim(:,t));
  K_sim(:,t+1) = kprime;
  
  

%     toc
end
% Simulate for the post-period
for t = T/2 : T-1
  pk = 1 - tau.*pv; 
  
    %option 0, baseline
    %kstar = K_sim(:,t); 
    %option 1, common across firms
    %kstar=exp(1/(1-theta)*log((1-tau)) - 1/(1-theta)*log((1-beta*(1-delta))*pk/(beta*theta)));
    %option 2, use firm-specific aa
    kstar=exp(1/(1-theta)*log((1-tau)) - 1/(1-theta)*log((1-beta*(1-delta))*pk/(beta*theta))).*exp(rho_e*(1-theta)*log(A_sim(:,t))+0.5*(rho_e*(1-theta))^2*sig_u^2);
  
%     tic
  vb = funeval(cvb_after,fspace,[K_sim(:,t),A_sim(:,t)]);
  vs = funeval(cvs_after, fspace,[K_sim(:,t),A_sim(:,t)]);
  vi = beta*funeval(ce_after,fspace,[(1-delta).*K_sim(:,t),A_sim(:,t)]);
  
  kprimeb = funeval(ckprimeb_after,fspace,[K_sim(:,t),A_sim(:,t)]);
  kprimes = funeval(ckprimes_after,fspace,[K_sim(:,t),A_sim(:,t)]);
  
  %  find the inaction, buy, or sell
  idx1 = ++(vb>vs);   
  idx2 = ++(max(vb,vs)-X_sim(:,t).*kstar>vi);
  
  %  update capital
  kprime = dprod(idx2,dprod(idx1,kprimeb)+dprod((1-idx1),kprimes)) + dprod((1-idx2),(1-delta).*K_sim(:,t));
  K_sim(:,t+1) = kprime;

%     toc
end

I_sim = (K_sim(:,2:end) - (1-delta).*K_sim(:,1:end-1));

% Simulate for the post-period counterfactual 
K_sim_cf = zeros(Nf,T);
K_sim_cf(:,1:T/2) = K_sim(:,1:T/2);
% V_sim_cf = zeros(Nf,T);
% V_sim_cf(:,1:T/2) = V_sim(:,1:T/2);

for t = T/2 : T-1
  
  
    pk = (1 - tau.*pv).*(1+nu); 
  
    %option 0, baseline
    %kstar = K_sim(:,t); 
    %option 1, common across firms
    %kstar=exp(1/(1-theta)*log((1-tau)) - 1/(1-theta)*log((1-beta*(1-delta))*pk/(beta*theta)));
    %option 2, use firm-specific aa
    kstar=exp(1/(1-theta)*log((1-tau)) - 1/(1-theta)*log((1-beta*(1-delta))*pk/(beta*theta))).*exp(rho_e*(1-theta)*log(A_sim(:,t))+0.5*(rho_e*(1-theta))^2*sig_u^2);
  
  %     tic
  vb_cf = funeval(cvb_before,fspace,[K_sim_cf(:,t),A_sim(:,t)]);
  vs_cf = funeval(cvs_before, fspace,[K_sim_cf(:,t),A_sim(:,t)]);
  vi_cf = beta*funeval(ce_before,fspace,[(1-delta).*K_sim_cf(:,t),A_sim(:,t)]);
  
  kprimeb_cf = funeval(ckprimeb_before,fspace,[K_sim_cf(:,t),A_sim(:,t)]);
  kprimes_cf = funeval(ckprimes_before,fspace,[K_sim_cf(:,t),A_sim(:,t)]);
  
  %  find the inaction, buy, or sell
  idx1 = ++(vb_cf>vs_cf);   
  idx2 = ++(max(vb_cf,vs_cf)-X_sim(:,t).*kstar>vi_cf);
  
  %  update capital
  kprime_cf = dprod(idx2,dprod(idx1,kprimeb_cf)+dprod((1-idx1),kprimes_cf)) + dprod((1-idx2),(1-delta).*K_sim_cf(:,t));
  K_sim_cf(:,t+1) = kprime_cf;
  
%   V_sim_cf(:,t) = dprod(idx2,dprod(idx1,vb_cf)+dprod((1-idx1),vs_cf)) + dprod((1-idx2),vi_cf);

%     toc
end


I_sim_cf = (K_sim_cf(:,2:end) - (1-delta).*K_sim_cf(:,1:end-1));

% Regression Sample
reg_ik = I_sim(:,T/2-2:T/2+2)./K_sim(:,T/2-2:T/2+2);
ucc = (ones(1,2)+[.17 0]).*(ones(1,2)-tau.*pv)./(ones(1,2)-tau).*(r+delta);
reg_ucc = [ucc(1),ucc(1),ucc(2),ucc(2),ucc(2)];
b_IK    = FEreg(reg_ik ,log(reg_ucc));
b_ind  = FEreg(++(reg_ik>0),log(reg_ucc));

% Moments from pre-period

    ik_s = 0.2;  % threshold of spike rate
    ik_i = 0.01;  % threshold of inaction rate
    
    k = K_sim(:,T/2-20:T/2-1)';
    i = I_sim(:,T/2-20:T/2-1)';
    shocks = A_sim(:,T/2-20:T/2-1)';
    ik = i./k;
    
    Ns = size(ik,2);
    Ts = size(ik,1);
    
    mm1 = mean(mean(ik));                                    % average investment rate (non-weighted)
    mm2 = mean(sum(ik.*(k./repmat(sum(k,2),1,Ns)),2));        % weighted average investment rate (aggregate investment rate)
    mm3 = sum(sum(abs(ik)<=ik_i))./(Ns*Ts);                     % inaction rate
    mm4 = sum(sum(ik>=ik_s))./(Ns*Ts);                         % positive spike rate      
    mm5 = sum(sum(ik<=(-ik_s)))./(Ns*Ts);                      % negative spike rate
    mm6 = corr(vec(ik(2:end,:)), vec(ik(1:end-1,:)));        % serial correlation of investment rate
    mm7 = corr(vec(ik),vec(log(shocks)));                    % correlation of investment rate and productivity
    %mm7 = 0;
    logi = log(i.*(i>0));
    mm8 = mean(mean(logi(isfinite(logi))));                  % average log investment
    mm9 = mean(mean(log(1+sqrt(1+i.^2))));                   % average ihs investment
    mm10 = sum(sum(ik>0))./(Ns*Ts);                            % fraction of firms investing
    mm11 = mean(std(ik));                                    % standard deviation of investment rate
    mm11_2 = std(ik(:));
    mm11_3 = std(ik(ik>0));
    mm12 = corr(vec(ik(2:end,:)),vec(log(shocks(2:end,:))-log(shocks(1:end-1,:))));
    
    mm = [mm1,mm2,mm3,mm4,mm5,mm6,mm7,mm8,mm9,mm10,mm11,mm12, b_ind, b_IK];
    
    %calculate distribution
    %focus on positive investment only
    ikp=vec(ik'); ikp=ikp(ikp>=0);
    dist5 = sum((ikp<0.05))/size(ikp,1);
    dist10 = sum((ikp<0.1))/size(ikp,1);
    dist20 = sum((ikp<0.2))/size(ikp,1);
    dist30 = sum((ikp<0.3))/size(ikp,1);

%%% Diff-in-diff estimates 
    np = 10;
    t = T/2;
    ik_sim = I_sim./K_sim(:,1:end-1);
    ik_sim_cf = I_sim_cf./K_sim_cf(:,1:end-1);
    % simulated responses
	IRF_sim = NaN(2,np);
    IRF_sim(1,:) = sum(ik_sim(:,t:t+np-1)>0,1)./Nf - sum(ik_sim_cf(:,t:t+np-1)>0,1)./Nf;    % fraction of firms investing
    IRF_sim(2,:) = mean(ik_sim(:,t:t+np-1)-ik_sim_cf(:,t:t+np-1));          % average investment rate    
%         % aggregate investment rate
%         IRF_sim(1,:) = sum(I_sim(:,t:t+np-1),1)./sum(K_sim(:,t:t+np-1),1)...
%                       -sum(I_sim_cf(:,t:t+np-1),1)./sum(K_sim_cf(:,t:t+np-1),1);

    
% %%%%% list of moments
% disp(x)
% disp('                                              Model     Data')
% fprintf('\n');
% fprintf('average investment rate (non-weighted)         = %7.3f %7.3f \n',mm1   ,glob.mm_data(1));  
% % fprintf('positive spike rate                            = %7.3f %7.3f \n',mm4   ,glob.mm_data(6));
% fprintf('serial correlation of investment rate          = %7.3f %7.3f \n',mm6	,glob.mm_data(7));
% % fprintf('standard deviation of investment rate          = %7.3f %7.3f \n',mm11  ,glob.mm_data(8));
% % fprintf('standard deviation of investment rate 2        = %7.3f %7.3f \n',mm11_2,glob.mm_data(8));
% % fprintf('standard deviation of investment rate, cond    = %7.3f %7.3f \n',mm11_3,glob.mm_data(8));
% % fprintf('fraction of firms investing                    = %7.3f %7.3f \n',mm10  ,glob.mm_data(13));
% fprintf('\n');
% % fprintf('elas. of investment frac to vat cut            = %7.3f %7.3f \n',b_ind ,glob.mm_data(9)); 
% % fprintf('elas. of investment rate to vat cut            = %7.3f %7.3f \n',b_IK  ,glob.mm_data(10)); 
% fprintf('diff-in-diff of investment frac                = %7.3f %7.3f \n',mean(IRF_sim(1,1:3)),0.046); 
% fprintf('diff-in-diff of investment rate                = %7.3f %7.3f \n',mean(IRF_sim(2,1:3)),0.038); 
% fprintf('\n');
% % fprintf('culmulative share 0.05          = %7.3f %7.3f \n',dist5	,0.625); 
% fprintf('culmulative share 0.1           = %7.3f %7.3f \n',dist10	,0.720); 
% fprintf('culmulative share 0.2           = %7.3f %7.3f \n',dist20	,0.834); 
% fprintf('culmulative share 0.3           = %7.3f %7.3f \n',dist30	,0.891); 

%%% spikes 
i_sim = I_sim;
k_sim = K_sim(:,1:end-1);
i_sim_cf = I_sim_cf;
k_sim_cf = K_sim_cf(:,1:end-1);

%%% share_spike = var(ik_w20)/var(ik_w)
share_spike1 = NaN(1,size(ik_sim,2));
share_spike2 = NaN(1,size(ik_sim,2));
for t = 1:size(ik_sim,2)
    kw = k_sim(:,t)./sum(k_sim(:,t),1);
    ik_w = kw.*ik_sim(:,t);
    ik_w20 = kw.*ik_sim(:,t).*(ik_sim(:,t)>=ik_s);
    
    share_spike1(1,t) = var(ik_w20)/var(ik_w);
    
    covariance = cov(ik_w20,ik_w);
    share_spike2(1,t) = covariance(1,2)/var(ik_w);
end

%%% other measures
ik20 = NaN(1,size(ik_sim,2));
i20  = NaN(1,size(ik_sim,2));
for t = 1:size(ik_sim,2)
    kw = k_sim(:,t)./sum(k_sim(:,t),1);
    
    ik20(1,t) = sum(kw.*ik_sim(:,t).*(ik_sim(:,t)>=ik_s),1);                %IK20=I20/K (aggregate spike rate)
    i20(1,t)  = sum(i_sim(:,t).*(ik_sim(:,t)>=ik_s),1)/sum(i_sim(:,t),1);   %I20/I (investment accounted by spike investment)
    
end

ik1_sim1 = ik_sim.*(ik_sim<=.01);
ik1_sim2 = ik_sim.*(ik_sim>=0 &ik_sim<=.01);
ik2_sim  = ik_sim.*(ik_sim>.01&ik_sim<=.10);
ik3_sim  = ik_sim.*(ik_sim>.10&ik_sim<=.20);
ik4_sim  = ik_sim.*(ik_sim>.20&ik_sim<=.30);
ik5_sim  = ik_sim.*(ik_sim>.30);

ik1_sim1_cf = ik_sim_cf.*(ik_sim_cf<=.01);
ik1_sim2_cf = ik_sim_cf.*(ik_sim_cf>=0 &ik_sim_cf<=.01);
ik2_sim_cf  = ik_sim_cf.*(ik_sim_cf>.01&ik_sim_cf<=.10);
ik3_sim_cf  = ik_sim_cf.*(ik_sim_cf>.10&ik_sim_cf<=.20);
ik4_sim_cf  = ik_sim_cf.*(ik_sim_cf>.20&ik_sim_cf<=.30);
ik5_sim_cf  = ik_sim_cf.*(ik_sim_cf>.30);

ik20_sim = ik_sim.*(ik_sim>=ik_s);
ik20_sim_cf = ik_sim_cf.*(ik_sim_cf>=ik_s);
ik20_no_sim    = ik_sim.*(ik_sim<ik_s);
ik20_no_sim_cf = ik_sim_cf.*(ik_sim_cf<ik_s);

t = T/2;
np = 10;

IRF1(1,:)   = mean(ik1_sim1(:,t:t+np-1)-ik1_sim1_cf(:,t:t+np-1)); 
IRF1_2(1,:) = mean(ik1_sim2(:,t:t+np-1)-ik1_sim2_cf(:,t:t+np-1)); 
IRF2(1,:)   = mean(ik2_sim(:,t:t+np-1)-ik2_sim_cf(:,t:t+np-1)); 
IRF3(1,:)   = mean(ik3_sim(:,t:t+np-1)-ik3_sim_cf(:,t:t+np-1)); 
IRF4(1,:)   = mean(ik4_sim(:,t:t+np-1)-ik4_sim_cf(:,t:t+np-1)); 
IRF5(1,:)   = mean(ik5_sim(:,t:t+np-1)-ik5_sim_cf(:,t:t+np-1)); 

IRF20(1,:) = sum(ik_sim(:,t:t+np-1)>0.2,1)./Nf - sum(ik_sim_cf(:,t:t+np-1)>0.2,1)./Nf;
IRF20(2,:) = mean(ik20_sim(:,t:t+np-1)-ik20_sim_cf(:,t:t+np-1)); 
IRF20(3,:) = mean(ik20_no_sim(:,t:t+np-1)-ik20_no_sim_cf(:,t:t+np-1)); 

% % clc
% disp('                                            Spike      All')
% fprintf('\n');
% fprintf('diff-in-diff of frac. investment = %7.3f %7.3f \n',mean(IRF20(1,1:3)),mean(IRF_sim(1,1:3)));  
% fprintf('diff-in-diff of investment rate  = %7.3f %7.3f \n',mean(IRF20(2,1:3)),mean(IRF_sim(2,1:3))); 
