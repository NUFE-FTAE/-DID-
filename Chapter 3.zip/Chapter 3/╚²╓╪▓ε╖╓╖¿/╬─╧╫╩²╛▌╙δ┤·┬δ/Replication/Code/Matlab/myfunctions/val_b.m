% value function of positive investment

function f = val_b(x,aa,kk,ce,fspace,apars,fpars,tpars)

    beta  = apars(1);
    delta = apars(2);
    %theta=apars(3);
    
    gamma = fpars(1);

    nu    = tpars(1);
    tau   = tpars(2);
    pv    = tpars(4);
    
    %size-dependent wedges in purchase price
    
    %0. baseline 
    wedge = 1;
    %1. depends on capital
    %wedge = exp(0.1*log(kk/min(kk))); % wedge = (kk/min(kk)).^(.1)
    
    pb = (1 - tau*pv)*(1 + nu)*wedge;
    f = - pb.*(x-(1-delta).*kk) - (gamma/2).*((x-(1-delta).*kk)./kk ).^(2).*kk...
        + beta.*funeval(ce,fspace,[x,aa]);

end