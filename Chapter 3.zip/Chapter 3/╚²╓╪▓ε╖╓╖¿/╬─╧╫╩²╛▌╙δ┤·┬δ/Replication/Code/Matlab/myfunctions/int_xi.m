% integral of fixed cost over (0,the cutoff)

function f = int_xi(beta_shape1,beta_shape2,a,b,N,xi_bar)

    fun = @(x) xi_bar.*x .* x.^(beta_shape1-1).*(1-x).^(beta_shape2-1)./beta(beta_shape1,beta_shape2);
    
    % nodes and weights for Legendre-Gauss quadrature
    x = repmat(a,[1,N+1])+repmat(b-a,[1,N+1]).*repmat(0:N,[size(a,1),1])/N;
    dx = (b-a)/(N+1);
    w = repmat(dx,[1,N+1]);
    w(:,[1;N+1]) = 0.5.*w(:,[1;N+1]);
    
    f = diag(w*fun(x)');                  % int_{a}^{b} \xi dG(\xi)
end