% This function solves the model

function [ckprimeb,ckprimes,ce,cvb,cvs,ve0] = sol_model_polsim(s,ce0,fspace,P,k_max,k_min,ns,nk,options,apars,fpars,tpars)
 % s: approximation grids 
 % ce0: initial value for approxiamtion coefficients
 % fspace: approximation basis for solving the model
 % P: transition matrix of productivity
 % k_max: maximum of k (grids)
 % k_min: minimum of k (grids)
 % ns: number of total approximation grids
 % nk: number of k grids
 % options: optimization options
 % apars: assigned parameters 
 % fpars: friction parameters
 % tpars: policy parameters
 % fspace_sim: approximation basis for projecting on (k,a,xi)
 % nxi: number of xi grids (i.i.d fixed cost)
 
    kk = s(:,1);  
    aa = s(:,2);
        
    tol = options(1,1);
    maxiter = options(1,2);
    
    xi_bar = fpars(2);
    a = fpars(4);
    b = fpars(5);
    
    beta  = apars(1);
    delta = apars(2);
    theta = apars(3);
    rho_e = apars(4);
    sig_u = apars(5);
    
    nu    = tpars(1);
    tau   = tpars(2);
    pv    = tpars(4);
    itc   = tpars(6);

    %calculate frictionless target capital
    pk = (1 - tau.*pv).*(1+nu) - itc; 
    %%%%%%below we define the desired capital level 
    %option 0, baseline
    %kstar = kk; 
    %option 1, common across firms
    %kstar=exp(1/(1-theta)*log((1-tau)) - 1/(1-theta)*log((1-beta*(1-delta))*pk/(beta*theta)));
    %option 2, use firm-specific aa
    kstar=exp(1/(1-theta)*log((1-tau)) - 1/(1-theta)*log((1-beta*(1-delta))*pk/(beta*theta))).*exp(rho_e*(1-theta)*log(aa)+0.5*(rho_e*(1-theta))^2*sig_u^2);
    
    % VALUE FUNCTION ITERATION TO GET REASONABLE INITIAL COEFFICIENTS
    iter = 0;
    diff = 1;
     while diff > tol && iter < 5
%     while diff > tol && iter < maxiter 
%     tic 
    
        [kprimeb,vb] = goldenx(@(x) val_b_polsim(x,aa,kk,ce0,fspace,apars,fpars,tpars),(1-delta).*kk,k_max.*ones(ns,1));
        [kprimes,vs] = goldenx(@(x) val_s(x,aa,kk,ce0,fspace,apars,fpars,tpars),k_min.*ones(ns,1),(1-delta).*kk);   
           vi =  beta.*funeval(ce0,fspace,[(1-delta).*kk,aa]);
        
        idx1 = ++(vb>vs);
        idx2 = ++(max(vb,vs)>vi);
               
        % cutoff of fixed cost
        
        xi_b = min(max(zeros(ns,1),(vb - vi)./kstar),xi_bar.*ones(ns,1));
        xi_s = min(max(zeros(ns,1),(vs - vi)./kstar),xi_bar.*ones(ns,1));

        vb0 = betacdf(xi_b./xi_bar,a,b).*vb - kstar.* int_xi(a,b,zeros(ns,1),xi_b./xi_bar,1001,xi_bar) + (1-betacdf(xi_b./xi_bar,a,b)).*vi;
        vs0 = betacdf(xi_s./xi_bar,a,b).*vs - kstar.* int_xi(a,b,zeros(ns,1),xi_s./xi_bar,1001,xi_bar) + (1-betacdf(xi_s./xi_bar,a,b)).*vi;
            
        v0 = (1-tau).*aa.^(1-theta).*kk.^theta + ...
             dprod(idx2,dprod(idx1,vb0)+dprod((1-idx1),vs0)) + dprod((1-idx2),vi);
        ve0 = kron(P,eye(nk))*v0;

        ce1 = funfitxy(fspace,s,ve0);
        diff = max(norm(ce1 - ce0));
%         disp(diff)

        ce0  = ce1;
        iter = iter + 1;
%     toc
    end

% NEWTON-RAPSON METHOD TO SPEED UP
    while diff > tol && iter < maxiter 
%     tic 
        [kprimeb,vb] = goldenx(@(x) val_b_polsim(x,aa,kk,ce0,fspace,apars,fpars,tpars),(1-delta).*kk,k_max.*ones(ns,1));
        [kprimes,vs] = goldenx(@(x) val_s(x,aa,kk,ce0,fspace,apars,fpars,tpars),k_min.*ones(ns,1),(1-delta).*kk);   
                 vi =  beta.*funeval(ce0,fspace,[(1-delta).*kk,aa]);  

        idx1 = ++(vb>vs);
        idx2 = ++(max(vb,vs)>vi);

        % cutoff of fixed cost
        xi_b = min(max(zeros(ns,1),(vb - vi)./kstar),xi_bar.*ones(ns,1));
        xi_s = min(max(zeros(ns,1),(vs - vi)./kstar),xi_bar.*ones(ns,1));

        vb0 = betacdf(xi_b./xi_bar,a,b).*vb - kstar.* int_xi(a,b,zeros(ns,1),xi_b./xi_bar,1001,xi_bar) + (1-betacdf(xi_b./xi_bar,a,b)).*vi;
        vs0 = betacdf(xi_s./xi_bar,a,b).*vs - kstar.* int_xi(a,b,zeros(ns,1),xi_s./xi_bar,1001,xi_bar) + (1-betacdf(xi_s./xi_bar,a,b)).*vi;
            
        v0 = (1-tau).*aa.^(1-theta).*kk.^theta + ...
             dprod(idx2,dprod(idx1,vb0)+dprod((1-idx1),vs0)) + dprod((1-idx2),vi);
        ve0 = kron(P,eye(nk))*v0;
   
        beljac_vb0 = beta.*(repmat(           betacdf(xi_b./xi_bar,a,b),[1,ns]) .*funbas(fspace,[kprimeb,aa]) ...
                          + repmat(ones(ns,1)-betacdf(xi_b./xi_bar,a,b),[1,ns]) .*funbas(fspace,[(1-delta).*kk,aa]));
        beljac_vs0 = beta.*(repmat(           betacdf(xi_s./xi_bar,a,b),[1,ns]) .*funbas(fspace,[kprimes,aa]) ...
                          + repmat(ones(ns,1)-betacdf(xi_s./xi_bar,a,b),[1,ns]) .*funbas(fspace,[(1-delta).*kk,aa]));
        beljac_vi0 = beta.*funbas(fspace,[(1-delta).*kk,aa]);

        bel    = funeval(ce0,fspace,s) - ve0;
        beljac = funbas(fspace,s) - kron(P,eye(nk)) ...
                * (dprod(idx2,dprod(idx1,beljac_vb0)+dprod((1-idx1),beljac_vs0)) ...
                +  dprod((1-idx2),beljac_vi0));
        ce1 = ce0 - beljac\bel;
    
        diff = max(norm(ce1 - ce0));
        ce0 = ce1;
        iter = iter + 1;

%         disp(iter)
%         disp(diff)
%     toc
    end 
    
% xi_cutoff = dprod(idx2,dprod(idx1,xi_b)+dprod((1-idx1),xi_s)) + dprod((1-idx2),zeros(ns,1));

% PROJECT OVER STATE SPACE (k,a,xi)
% ce = ce1;
% s_sim = gridmake(funnode(fspace_sim));
% ns_sim = length(s_sim);
% 
% [kprimeb2,vb2] = goldenx(@(x) val_b2(x,s_sim(:,2),s_sim(:,1),s_sim(:,3),ce,fspace,apars,fpars,tpars),(1-delta).*s_sim(:,1),k_max.*ones(ns_sim,1));
% [kprimes2,vs2] = goldenx(@(x) val_s2(x,s_sim(:,2),s_sim(:,1),s_sim(:,3),ce,fspace,apars,fpars,tpars),k_min.*ones(ns_sim,1),(1-delta).*s_sim(:,1));
%           vi2 = (1-tau).*s_sim(:,2).^(1-theta).*s_sim(:,1).^theta + beta.*funeval(ce,fspace,[(1-delta).*s_sim(:,1),s_sim(:,2)]);
% idx1 = ++(vb2>vs2);
% idx2 = ++(max(vb2,vs2)>vi2);
% 
% kprime  = dprod(idx2,dprod(idx1,kprimeb2)+dprod((1-idx1),kprimes2)) + dprod((1-idx2),(1-delta).*s_sim(:,1));
% v       = dprod(idx2,dprod(idx1,vb2)+dprod((1-idx1),vs2)) + dprod((1-idx2),vi2);

% GET COEFFICIENTS
ce = ce1;
%ckprime    = funfitxy(fspace_sim,s_sim,kprime);
% cv         = funfitxy(fspace_sim,s_sim,v);
% cxi_cutoff = funfitxy(fspace_sim,s_sim,repmat(xi_cutoff,nxi,1));

ckprimeb = funfitxy(fspace,s,kprimeb);
ckprimes = funfitxy(fspace,s, kprimes);
cvb = funfitxy(fspace,s,vb);
cvs = funfitxy(fspace,s,vs);

clc;
end