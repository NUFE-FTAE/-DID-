% Xian Jiang
% Updated by September 6, 2018
% This function file solves the model by only solving the expected value 
% function, given VAT rate.

function [ckprimeb,ckprimes,ce,cvb,cvs,ve] = sol_model_xi(s,ce0,fspace,P,k_max,k_min,ns,nk,options,fpars,apars,tpars)
    %global beta delta theta
   
    kk = s(:,1);
    aa = s(:,2);
    tol = options(1,1);
    maxiter = options(1,2);
    
    beta  = apars(1);
    delta = apars(2);
    theta = apars(3);
    rho_e = apars(4);
    sig_u = apars(5);
    
    nu    = tpars(1);
    tau   = tpars(2);
    pv    = tpars(4);
    
    %calculate frictionless target capital
    pk = (1 - tau.*pv).*(1+nu); 
    %%%%%%below we define the desired capital level 
    %option 0, baseline
    %kstar = kk; 
    %option 1, common across firms
    %kstar=exp(1/(1-theta)*log((1-tau)) - 1/(1-theta)*log((1-beta*(1-delta))*pk/(beta*theta)));
    %option 2, use firm-specific aa
    kstar=exp(1/(1-theta)*log((1-tau)) - 1/(1-theta)*log((1-beta*(1-delta))*pk/(beta*theta))).*exp(rho_e*(1-theta)*log(aa)+0.5*(rho_e*(1-theta))^2*sig_u^2);
    
    % VALUE FUNCTION ITERATION TO GET REASONABLE INITIAL COEFFICIENTS
    iter = 0;
    diff = 1;
    while diff > tol && iter < 5
%     tic 
        [~,vb] = goldenx(@(x) vb_xi(x,aa,kk,ce0,fspace,fpars,apars,tpars,kstar),(1-delta).*kk,k_max.*ones(ns,1));
        [~,vs] = goldenx(@(x) vs_xi(x,aa,kk,ce0,fspace,fpars,apars,tpars,kstar),k_min.*ones(ns,1),(1-delta).*kk);
%     toc   
        vi = (1-tau).*aa.^(1-theta).*kk.^theta + beta.*funeval(ce0,fspace,[(1-delta).*kk,aa]);

        idx1 = ++(vb>vs);
        idx2 = ++(max(vb,vs)>vi);

        v = dprod(idx2,dprod(idx1,vb)+dprod((1-idx1),vs)) + dprod((1-idx2),vi);
        ve = kron(P,eye(nk))*v;
        ce1 = funfitxy(fspace,s,ve);
        diff = max(norm(ce1 - ce0));
%         disp(diff)

        ce0  = ce1;
        iter = iter + 1;
    end

    % NEWTON-RAPSON METHOD TO SPEED UP
    while diff > tol && iter < maxiter  
%     tic 
        [kprime_b,vb] = goldenx(@(x) vb_xi(x,aa,kk,ce0,fspace,fpars,apars,tpars,kstar),(1-delta).*kk,k_max.*ones(ns,1));
        [kprime_s,vs] = goldenx(@(x) vs_xi(x,aa,kk,ce0,fspace,fpars,apars,tpars,kstar),k_min.*ones(ns,1),(1-delta).*kk);
%     toc   
        vi = (1-tau).*aa.^(1-theta).*kk.^theta + beta.*funeval(ce0,fspace,[(1-delta).*kk,aa]);

        idx1 = ++(vb>vs);
        idx2 = ++(max(vb,vs)>vi);

        v = dprod(idx2,dprod(idx1,vb)+dprod((1-idx1),vs)) + dprod((1-idx2),vi);
        ve = kron(P,eye(nk))*v;
%     tic    
        bel    = funeval(ce0,fspace,s) - ve;
        beljac = funbas(fspace,s) - beta.*kron(P,eye(nk)) ...
                * (dprod(idx2,dprod(idx1,funbas(fspace,[kprime_b,aa]))+dprod((1-idx1),funbas(fspace,[kprime_s,aa]))) ...
                + dprod((1-idx2),funbas(fspace,[(1-delta).*kk,aa])));
        ce1 = ce0 - beljac\bel;
%     toc    
        diff = max(norm(ce1 - ce0));
%         disp(diff)

        ce0 = ce1;
        iter = iter + 1;
    end 

    ce = ce1;
    [kprime_b,vb] = goldenx(@(x) vb_xi(x,aa,kk,ce,fspace,fpars,apars,tpars,kstar),(1-delta).*kk,k_max.*ones(ns,1));
    [kprime_s,vs] = goldenx(@(x) vs_xi(x,aa,kk,ce,fspace,fpars,apars,tpars,kstar),k_min.*ones(ns,1),(1-delta).*kk);
%     vi = (1-tau).*aa.^(1-theta).*kk.^theta + beta.*funeval(ce,fspace,[(1-delta).*kk,aa]);
%     v1 = max(max(vb,vs),vi);
%     ve = kron(P,eye(nk))*v1;
%     kprime = dprod(idx2,dprod(idx1,kprime_b)+dprod((1-idx1),kprime_s)) + dprod((1-idx2),(1-delta).*kk);

    % GET COEFFICIENTS
%     cv   = funfitxy(fspace,s,v1);
%     ckprime   = funfitxy(fspace,s,kprime);
    cvb = funfitxy(fspace,s,vb);
    cvs = funfitxy(fspace,s,vs);
    ckprimeb = funfitxy(fspace,s,kprime_b);
    ckprimes = funfitxy(fspace,s,kprime_s);

clc;
end