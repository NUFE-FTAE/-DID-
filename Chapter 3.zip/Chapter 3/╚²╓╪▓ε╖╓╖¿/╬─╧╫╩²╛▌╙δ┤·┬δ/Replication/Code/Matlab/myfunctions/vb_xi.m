% value function of positive investment

function f = vb_xi(x,aa,kk,ce,fspace,fpars,apars,tpars,kstar)


gamma = fpars(1);
xi    = fpars(2);


beta  = apars(1);
delta = apars(2);
theta = apars(3);

nu    = tpars(1);
tau   = tpars(2);
pv    = tpars(4);


	f = (1-tau).*aa.^(1-theta).*kk.^theta - (1 - tau*pv)*(1 + nu)*(x-(1-delta).*kk) - xi.*kstar - (gamma/2).*(x-(1-delta).*kk).^2./kk ...
      + beta.*funeval(ce,fspace,[x,aa]);
end