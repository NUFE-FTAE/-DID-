% This function discretizes random process by tauchen method

function [Xt,Pt] = tauchen(mu,sigma,rho,m,n)
    % mu:    unconditional mean
    % sigma: std. dev. of error term
    % m:     std.dev. from the mean mu
    % n:     number of grid 

    % generate grids       
    xl = mu-m*sigma/sqrt(1-rho^2);        
    xu = mu+m*sigma/sqrt(1-rho^2);
    Xt = linspace(xl,xu,n)';
    
    w = (xu-xl)/(n-1);                 % width
    
    % transition matrix
    Pt = zeros(n,n);
    
    for i = 1:n
        
    Pt(i,1)       = normcdf((Xt(1)+(w/2-(1-rho)*mu)-rho*Xt(i))/sigma);
    Pt(i,2:(n-1)) = normcdf((Xt(2:n-1)+( w/2-(1-rho)*mu)*ones(n-2,1)-rho*Xt(i)*ones(n-2,1))/sigma)...
                  - normcdf((Xt(2:n-1)+(-w/2-(1-rho)*mu)*ones(n-2,1)-rho*Xt(i)*ones(n-2,1))/sigma);
    Pt(i,n)       = 1-normcdf((Xt(n)-w/2-(1-rho)*mu-rho*Xt(i))/sigma);
    end
end