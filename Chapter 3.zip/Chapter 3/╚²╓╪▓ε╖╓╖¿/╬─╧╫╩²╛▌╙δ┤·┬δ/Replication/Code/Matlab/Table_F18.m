% Robustness: upload sloping capital supply, varying elasticities 

clearvars -except dropboxpath
clc
close all
warning off all

% cepath='/Applications/MATLAB_R2020b.app/toolbox/compecon/'; path([cepath 'cetools;' cepath 'cedemos'],path)
% dropboxpath='/Users/xianjiang/Dropbox/Research/Fiscal Incentive and Investment/Replication/';
% addpath([dropboxpath 'AnalysisData'])
% addpath([dropboxpath 'Code/Matlab/myfunctions'])
% addpath([dropboxpath 'Code/Matlab/estimation'])

%% SETTINGS
% set parameters
pars.p_s = 1;
pars.beta  = 0.95;  
pars.theta = 0.734;   

% policy relevant parameters
pars.nu = 0.17;
pars.tau = 0.154;
pars.n_dep =10;
pars.r = 1/pars.beta - 1;
pars.pv = (1./pars.n_dep).*(1+pars.r)/pars.r.*(1-(1+pars.r).^(-pars.n_dep));
pars.delta_dep = (1-pars.beta).*pars.pv./(1-pars.beta.*pars.pv);
 
% shock processes
pars.rho_b = 0.009;  
pars.sig_b = 0.010/(1-pars.theta);
pars.rho_e = 0.860;   
pars.sig_e = 0.529/(1-pars.theta); 
pars.sig_u = sqrt(1-pars.rho_e^2)*pars.sig_e;  %standard deviation of shocks
pars.sig_w = 0.854;

% simulation 
pars.T  = 101*2;                     % number of periods
pars.Tn = 15;                        % not using initial 15 periods
pars.Nf = 10000;                     % number of firms

% setting algorithm parameter values
pars.tol = 10^-8; 
pars.maxiter = 5000; 
        
% approximation basis
pars.nb = 5;
pars.ne = 20;
pars.m = 3;   %std for Tauchen's discretization
pars.nk = 31;
pars.nxi = 20;
pars.na = pars.nb*pars.ne;

% approximation grids 
[b_grid,P_b] = tauchen(0,sqrt(1-pars.rho_b^2)*pars.sig_b,pars.rho_b,pars.m,pars.nb); b_grid = exp(b_grid);
[e_grid,P_e] = tauchen(0,sqrt(1-pars.rho_e^2)*pars.sig_e,pars.rho_e,pars.m,pars.ne); e_grid = exp(e_grid);
[a_grid,I]   = sort(kron(b_grid,e_grid),'ascend');
P_a = kron(P_b,P_e);
P_a = P_a(I,I);
 
pars.k_min=1;
pars.k_max=10000;

curv = .4;
k_grid = linspace(pars.k_min.^curv,pars.k_max.^curv,pars.nk).^(1/curv);
k_grid = k_grid';
    
%% Load data moments 
mm_data = readtable('data_mm_b.xls');   
glob.mm_data = [mm_data.AvgI,mm_data.ShareI_0_1,mm_data.ShareI_0_2,mm_data.ShareI_0_3, ...
                mm_data.Corr_i_i___1__,mm_data.SDI,mm_data.DID_Ext,mm_data.DID_Int];
glob.V = eye(length(glob.mm_data));
    
 %% 1 SET PARAMETERS 
load Uniform_AB_idtw x
x = [x(1) x(2) 1 1 x(3)];

    % assign parameter values
    gamma       = x(1,1);
    xi_bar      = x(1,2);
    a           = x(1,3); 
    b           = x(1,4); 
    delta       = x(1,5);
    
    p_s         = pars.p_s;
    beta        = pars.beta;
    theta       = pars.theta;
    rho_e       = pars.rho_e;
    sig_u       = pars.sig_u;
    nu          = pars.nu;
    tau         = pars.tau;
    n_dep       = pars.n_dep;
    r           = pars.r;
    pv          = pars.pv;
    delta_dep   = pars.delta_dep;
    
    k_min       = pars.k_min;
    k_max       = pars.k_max;
    na          = pars.na;
    nxi         = pars.nxi;
    
    Tn          = pars.Tn;
% 	T           = pars.T; 
%	Nf          = pars.Nf;
    
    tol         = pars.tol;
    maxiter     = pars.maxiter;

    fpars = [gamma;xi_bar;p_s;a;b];         % friction parameters
    apars = [beta;delta;theta;rho_e;sig_u];             % asigned parameters
    tpars = [nu;tau;n_dep;pv;delta_dep];    % policy parameters
    options = [tol,maxiter];

%% 2 SOLVE THE MODEL
%% Approximation basis
%  For solving the model
fspace = fundef({'spli', k_grid, 0, 3}, ...
                {'spli', a_grid, 0, 1});
s_grid = funnode(fspace);
s = gridmake(s_grid);
ns = length(s);
nk = ns/na;
        
%%  Before the reform
dpk_before = 0;
tpars_before = [tpars;dpk_before];
pk = (1+tpars_before(6))*(1 - tpars_before(2)*tpars_before(4))*(1+tpars_before(1));
ucc(1,1) = pk/(1-tpars_before(2))*(r+delta);

ce0 = funfitxy(fspace,s,s(:,2).^(1-theta).*s(:,1).^theta);            
[ckprimeb_before,ckprimes_before,ce_before,cvb_before,cvs_before,ve_before] = sol_model_ksupply(s,ce0,fspace,P_a,k_max,k_min,ns,nk,options,apars,fpars,tpars_before);
        
%%  After the reform

ELS  = [Inf, 2.54,6,10,14];
% ELS = 2.54;
DUCC = NaN(size(ELS));
DPK  = NaN(size(ELS));
DI   = NaN(size(ELS));
DEXT = NaN(size(ELS));
DTAX = NaN(size(ELS));
DV   = NaN(size(ELS));

for idx_els = 1:length(ELS)
    %   Elasticity of capital supply
if idx_els==1
    dpk = 0;
else
    e_ksupply = ELS(1,idx_els);
    dpk = fsolve(@(x) (0.36-x)./(1+x)./x - e_ksupply,[.001,1]);
    dpk = dpk(1);
end
    disp(dpk)
    
    nu_after = 0;
    tpars_after = [nu_after;tpars(2:end);dpk];
    pk = (1+tpars_after(6))*(1 - tpars_after(2)*tpars_after(4))*(1+tpars_after(1));
    ucc(1,2) = pk/(1-tpars_after(2))*(r+delta);
    ducc = ucc(2)/ucc(1)-1; %  Percentage change in user cost of capital
        
    apars_after = apars;
    
    ce0 = ce_before;
    [ckprimeb_after,ckprimes_after,ce_after,cvb_after,cvs_after,ve_after] = sol_model_ksupply(s,ce0,fspace,P_a,k_max,k_min,ns,nk,options,apars_after,fpars,tpars_after);
         
    %% 3 SIMULATE INVESTMENT 
    T  = 200;
    Nf = 10000;

    %%% Initial draw from stationary dist
    E_sim=zeros(Nf,T);
    rng('default'); rng(333);
    E_sim(:,1) = normrnd(0, pars.sig_e, Nf,1);
    for t=2:1:T
        E_sim(:,t) = pars.rho_e*E_sim(:,t-1) + normrnd(0, sqrt(1 - pars.rho_e^2)*pars.sig_e, Nf, 1);
        % Truncate idiosyncratic shocks grids
        E_sim(:,t) = min(max(min(log(e_grid)),E_sim(:,t)),max(log(e_grid)));
    end

    B_sim=zeros(1,T);
    rng('default'); rng(666)
    B_sim(1)=normrnd(0, pars.sig_b/(sqrt(1-pars.rho_b^2)));
    for t=2:1:T
        B_sim(t) = pars.rho_b*B_sim(t-1) + normrnd(0, pars.sig_b);
     end
    A_sim = exp(E_sim + repmat(B_sim,Nf,1));

    %%% Simulate idiosyncratic fixed cost
    rng('default'); rng(999)
    X_sim = x(2)*betarnd(x(3),x(4),Nf,T);

    %%% Simulate investment and firm values
    % Initial capital stock based on frictionless model
    K_sim = zeros(Nf,T);
    K_sim(:,1) = 500;
    V_sim = zeros(Nf,T);

    %%% 0 Start to simulate for pre-period
    for t = 1 : T/2-1
        pk = (1+tpars_before(6))*(1 - tpars_before(2)*tpars_before(4))*(1+tpars_before(1));
        kstar=exp(1/(1-theta)*log((1-tpars_before(2))) - 1/(1-theta)*log((1-beta*(1-delta))*pk/(beta*theta))).*exp(rho_e*(1-theta)*log(A_sim(:,t))+0.5*(rho_e*(1-theta))^2*sig_u^2);
        
        vb = funeval(cvb_before,fspace,[K_sim(:,t),A_sim(:,t)]);
        vs = funeval(cvs_before, fspace,[K_sim(:,t),A_sim(:,t)]);
        vi = beta*funeval(ce_before,fspace,[(1-delta).*K_sim(:,t),A_sim(:,t)]);

        kprimeb = funeval(ckprimeb_before,fspace,[K_sim(:,t),A_sim(:,t)]);
        kprimes = funeval(ckprimes_before,fspace,[K_sim(:,t),A_sim(:,t)]);

        % Find the inaction, buy, or sell
        idx1 = ++(vb>vs);   
        idx2 = ++(max(vb,vs)-X_sim(:,t).*kstar>vi);

        %  update capital
        kprime = dprod(idx2,dprod(idx1,kprimeb)+dprod((1-idx1),kprimes)) + dprod((1-idx2),(1-delta).*K_sim(:,t));
        K_sim(:,t+1) = kprime;
        
        V_sim(:,t) = dprod(idx2,dprod(idx1,vb)+dprod((1-idx1),vs)) + dprod((1-idx2),vi);
    end

    %%% 1 Simulate for the post-period
    for t = T/2 : T-1
            % Desired capital stock: kstar
            pk = (1+tpars_after(6))*(1 - tpars_after(2)*tpars_after(4))*(1+tpars_after(1));
            kstar=exp(1/(1-theta)*log((1-tpars_after(2))) - 1/(1-theta)*log((1-apars_after(1)*(1-delta))*pk/(apars_after(1)*theta))).*exp(rho_e*(1-theta)*log(A_sim(:,t))+0.5*(rho_e*(1-theta))^2*sig_u^2);

            vb = funeval(cvb_after,fspace,[K_sim(:,t),A_sim(:,t)]);
            vs = funeval(cvs_after, fspace,[K_sim(:,t),A_sim(:,t)]);
            vi = apars_after(1)*funeval(ce_after,fspace,[(1-delta).*K_sim(:,t),A_sim(:,t)]);

            kprimeb = funeval(ckprimeb_after,fspace,[K_sim(:,t),A_sim(:,t)]);
            kprimes = funeval(ckprimes_after,fspace,[K_sim(:,t),A_sim(:,t)]);

            %  find the inaction, buy, or sell
            idx1 = ++(vb>vs);   
            idx2 = ++(max(vb,vs)-X_sim(:,t).*kstar>vi);

            %  update capital
            kprime = dprod(idx2,dprod(idx1,kprimeb)+dprod((1-idx1),kprimes)) + dprod((1-idx2),(1-delta).*K_sim(:,t));
            K_sim(:,t+1) = kprime;

            V_sim(:,t) = dprod(idx2,dprod(idx1,vb)+dprod((1-idx1),vs)) + dprod((1-idx2),vi);
    end
    

    I_sim = (K_sim(:,2:end) - (1-delta).*K_sim(:,1:end-1));

    %%% 2 Simulate for the post-period counterfactual 
    K_sim_cf = zeros(Nf,T);
    K_sim_cf(:,1:T/2) = K_sim(:,1:T/2);
    V_sim_cf = zeros(Nf,T);
    V_sim_cf(:,1:T/2) = V_sim(:,1:T/2);

    for t = T/2 : T-1

            pk = (1+tpars_before(6))*(1 - tpars_before(2)*tpars_before(4))*(1+tpars_before(1));
            kstar=exp(1/(1-theta)*log((1-tpars_before(2))) - 1/(1-theta)*log((1-beta*(1-delta))*pk/(beta*theta))).*exp(rho_e*(1-theta)*log(A_sim(:,t))+0.5*(rho_e*(1-theta))^2*sig_u^2);

            vb_cf = funeval(cvb_before,fspace,[K_sim_cf(:,t),A_sim(:,t)]);
            vs_cf = funeval(cvs_before, fspace,[K_sim_cf(:,t),A_sim(:,t)]);
            vi_cf = beta*funeval(ce_before,fspace,[(1-delta).*K_sim_cf(:,t),A_sim(:,t)]);

            kprimeb_cf = funeval(ckprimeb_before,fspace,[K_sim_cf(:,t),A_sim(:,t)]);
            kprimes_cf = funeval(ckprimes_before,fspace,[K_sim_cf(:,t),A_sim(:,t)]);

            % find the inaction, buy, or sell
            idx1 = ++(vb_cf>vs_cf);   
            idx2 = ++(max(vb_cf,vs_cf)-X_sim(:,t).*kstar>vi_cf);

            % update capital
            kprime_cf = dprod(idx2,dprod(idx1,kprimeb_cf)+dprod((1-idx1),kprimes_cf)) + dprod((1-idx2),(1-delta).*K_sim_cf(:,t));
            K_sim_cf(:,t+1) = kprime_cf;

            V_sim_cf(:,t) = dprod(idx2,dprod(idx1,vb_cf)+dprod((1-idx1),vs_cf)) + dprod((1-idx2),vi_cf);
    end
    I_sim_cf = (K_sim_cf(:,2:end) - (1-delta).*K_sim_cf(:,1:end-1));

    %% CALCULATE FIRM VALUE AND TAX REVENUES
    nu_after    = tpars_after(1);
    tau_after   = tpars_after(2);
    n_dep_after = tpars_after(3);
    pv_after    = tpars_after(4);
    delta_dep_after = tpars_after(5);

    k_sim = K_sim(:,1:end-1);
    i_sim = I_sim;
    k_sim_cf = K_sim_cf(:,1:end-1);
    i_sim_cf = I_sim_cf;
    
    shocks = A_sim(:,1:end-1);
    ik_sim = i_sim./k_sim;
    ik_sim_cf = i_sim_cf./k_sim_cf;
    
    v_sim = V_sim(:,1:end-1);
    v_sim_cf = V_sim_cf(:,1:end-1);
    
    % depreciation allowance
    d_sim = NaN(Nf,T-1);d_sim_cf = NaN(Nf,T-1);
    
    % tax revenue
    pi_sim = NaN(Nf,T-1);pi_sim_cf = NaN(Nf,T-1);
    vat = NaN(Nf,T-1);vat_cf = NaN(Nf,T-1);
    cit = NaN(Nf,T-1);cit_cf = NaN(Nf,T-1);

        for t = 1:T-1
            if t == 1
                pi_sim(:,t) = A_sim(:,t).^(1-theta).*k_sim(:,t).^theta; pi_sim_cf(:,t) = pi_sim(:,t);
                d_sim(:,t)  = k_sim(:,t); d_sim_cf(:,t) = d_sim(:,t);
                vat(:,t) = nu.*i_sim(:,t); vat_cf(:,t) = vat(:,t);
                cit(:,t) = tau.*(pi_sim(:,t) - delta_dep.*(1+nu).*i_sim(:,t) - delta_dep.*d_sim(:,t)); cit_cf(:,t) = cit(:,t);
                                
            elseif t>=2 && t<=T/2-1
                pi_sim(:,t) = A_sim(:,t).^(1-theta).*k_sim(:,t).^theta; pi_sim_cf(:,t) = pi_sim(:,t);
                d_sim(:,t)  = (1-delta_dep).*(d_sim(:,t-1) + (1+nu).*i_sim(:,t-1)); d_sim_cf(:,t) = d_sim(:,t);
                vat(:,t) = nu.*i_sim(:,t); vat_cf(:,t) = vat(:,t);
                cit(:,t) = tau.*(pi_sim(:,t) - delta_dep.*(1+nu).*i_sim(:,t) - delta_dep.*d_sim(:,t)); cit_cf(:,t) = cit(:,t);                            
                
            elseif t == T/2
                pi_sim(:,t) = A_sim(:,t).^(1-theta).*k_sim(:,t).^theta; pi_sim_cf(:,t) = A_sim(:,t).^(1-theta).*k_sim_cf(:,t).^theta;
                d_sim(:,t) = (1-delta_dep).*(d_sim(:,t-1) + (1+nu).*i_sim(:,t-1)); d_sim_cf(:,t) = (1-delta_dep).*(d_sim_cf(:,t-1) + (1+nu).*i_sim_cf(:,t-1)); dtemp=d_sim(:,t);%dtemp is the accumulated depreciation before the reform
                vat(:,t) = nu_after.*i_sim(:,t); vat_cf(:,t) = nu.*i_sim_cf(:,t);
                cit(:,t) = tau_after.*(pi_sim(:,t) - delta_dep.*dtemp - delta_dep_after.*(d_sim(:,t)-dtemp) - delta_dep_after*(1+nu_after).*i_sim(:,t));
                cit_cf(:,t) = tau.*(pi_sim_cf(:,t) - delta_dep.*d_sim_cf(:,t) - delta_dep*(1+nu).*i_sim_cf(:,t));         
                                
            else
                pi_sim(:,t) = A_sim(:,t).^(1-theta).*k_sim(:,t).^theta; pi_sim_cf(:,t) = A_sim(:,t).^(1-theta).*k_sim_cf(:,t).^theta;
                d_sim(:,t) = (1-delta_dep).*dtemp + ...
                             (1-delta_dep_after).*(d_sim(:,t-1) - dtemp) + ...
                             (1-delta_dep_after).*(1+nu_after).*i_sim(:,t-1);
                dtemp = (1-delta_dep).*dtemp;
                d_sim_cf(:,t) = (1-delta_dep).*(d_sim_cf(:,t-1) + (1+nu).*i_sim_cf(:,t-1));
                vat(:,t) = nu_after.*i_sim(:,t); vat_cf(:,t) = nu.*i_sim_cf(:,t);
                cit(:,t) = tau_after.*(pi_sim(:,t)  - delta_dep.*dtemp - delta_dep_after.*(d_sim(:,t)-dtemp) - delta_dep_after*(1+nu_after).*i_sim(:,t));
                cit_cf(:,t) = tau.*(pi_sim_cf(:,t) - delta_dep.*(1+nu).*i_sim_cf(:,t) - delta_dep.*d_sim_cf(:,t));


            end
        end

    % firm value (v = \tilde{v} + \tau pv d)
    v_sim    = v_sim + [tau*pv.*d_sim(:,1:T/2-1), tau_after*pv_after.*d_sim(:,T/2:end)];
    v_sim_cf = v_sim_cf + tau.*pv.*d_sim_cf;

    %% CALCULATE RESPONSE IN INVESTMENT, FIRM VALUE, AND TAX REVENUES
    np = 10;

    %%% Firm value 
    dv = mean(mean(v_sim(:,100:100+np-1) ,1)./mean(v_sim_cf(:,100:100+np-1) ,1)-1,2);

    %%% Tax revenues
    temp  = cumsum(sum(vat(:,100:100+np-1)+cit(:,100:100+np-1),1)./(1/apars_after(1)).^(0:np-1),2)./cumsum(sum(vat_cf(:,100:100+np-1)+cit_cf(:,100:100+np-1),1)./(1+pars.r).^(0:np-1),2) - 1;
    dtaxagg = temp(:,end);

    temp  = cumsum(sum(vat(:,100:100+np-1),1)./(1/apars_after(1)).^(0:np-1),2)./cumsum(sum(vat_cf(:,100:100+np-1),1)./(1+pars.r).^(0:np-1),2) - 1;
    dvatagg = temp(:,end);

    temp  = cumsum(sum(cit(:,100:100+np-1),1)./(1/apars_after(1)).^(0:np-1),2)./cumsum(sum(cit_cf(:,100:100+np-1),1)./(1+pars.r).^(0:np-1),2) - 1;
    dcitagg = temp(:,end);


    %%% Aggregate investment 
    I    = cumsum(sum(I_sim(:,100:100+np-1),1)   ./(1+pars.r).^(0:np-1),2); I = I(end);
    I_cf = cumsum(sum(I_sim_cf(:,100:100+np-1),1)./(1+pars.r).^(0:np-1),2); I_cf = I_cf(end);
    dI = I/I_cf - 1;

    dext     = (mean(sum(ik_sim(:,100:100+np-1)~=0,1),2)-mean(sum(ik_sim_cf(:,100:100+np-1)~=0,1),2))./mean(sum(ik_sim_cf(:,100:100+np-1)~=0,1),2);   

%% STORE RESULTS
DUCC(1,idx_els) = ducc;
DPK(1,idx_els)  = dpk;
DI(1,idx_els)   = dI;
DEXT(1,idx_els) = dext;
DTAX(1,idx_els) = dtaxagg;
DV(1,idx_els)   = dv;
end

