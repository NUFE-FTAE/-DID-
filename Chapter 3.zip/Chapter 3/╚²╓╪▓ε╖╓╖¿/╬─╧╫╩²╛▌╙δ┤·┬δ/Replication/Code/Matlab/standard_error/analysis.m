% Updated by Jan 29, 2022

clearvars -except dropboxpath
clc
close all
warning off all

cd([dropboxpath 'Code/Matlab/standard_error'])

%% Load Data
glob.mm_data = readtable([dropboxpath 'RawData/data_mm_b.xls'],'Range','B2:I2');
glob.mm_data = glob.mm_data{:,:};
glob.V = readtable([dropboxpath 'RawData/data_mm_V.xls'],'Range','B2:I9');
glob.V = glob.V{:,:};

%% Fixed, A
load SE_Fixed_A_idtw x GXI Result 
        
mm_data = glob.mm_data(1,1:6);  % macro moments
V       = glob.V(1:6,1:6);
Result  = Result(:,1:6);
    
Np = 15;
Nparm = 3;

Nmom  = length(mm_data);
G     = zeros(Nmom,Nparm);

est  = x(1:Nparm);

for i = 1:Nparm
   x = GXI(((i-1)*Np+1):(i*Np),i); 
   
   % Second order polynomial approx.
   xmat = [ones(length(x),1) x x.^2];

   for j = 1:Nmom
       y = Result(((i-1)*Np+1):(i*Np),j);
       coef=(xmat'*xmat)\(xmat'*y);
       % Update Jacobian 
       G(j,i)=coef(2)+coef(3)*2*est(1,i);
   end
   
end

% Weight
weight = eye(length(V));
Lambda=(G'*weight*G)\(G'*weight);

% Standard errors
NS = 15; 
cov = V; 
se = (diag(Lambda*(1+1/NS)*cov*Lambda').^0.5)';

fprintf('Fixed (A) \n')
fprintf('point estimate = %10.3f %10.3f %10.3f \n',est(1),est(2),est(3));
fprintf('standard error = %10.3f %10.3f %10.3f \n',se(1), se(2),se(3));
fprintf('\n')

save se_Fixed_A est se

%% Uniform, A
load SE_Uniform_A_idtw x GXI Result 

mm_data = glob.mm_data(1,1:6);  % macro moments
V       = glob.V(1:6,1:6);
Result = Result(:,1:6);
GXI = GXI(:,[1 2 5]);
    
Np = 15;
Nparm = 3;

Nmom  = length(mm_data);
G     = zeros(Nmom,Nparm);

est  = x(1:Nparm);

for i = 1:Nparm
   x = GXI(((i-1)*Np+1):(i*Np),i); 
   
   % Second order polynomial approx.
   xmat = [ones(length(x),1) x x.^2];

   for j = 1:Nmom
       y = Result(((i-1)*Np+1):(i*Np),j);
       coef=(xmat'*xmat)\(xmat'*y);
       % Update Jacobian 
       G(j,i)=coef(2)+coef(3)*2*est(1,i);
   end
   
end

% Weight
weight = eye(length(V));
Lambda=(G'*weight*G)\(G'*weight);

% Standard errors
NS = 15; 
cov = V; 
se = (diag(Lambda*(1+1/NS)*cov*Lambda').^0.5)';

fprintf('Uniform (A) \n')
fprintf('point estimate = %10.3f %10.3f %10.3f \n',est(1),est(2),est(3));
fprintf('standard error = %10.3f %10.3f %10.3f \n',se(1), se(2),se(3));
fprintf('\n')

save se_Uniform_A est se

%% Uniform, AB
load SE_Uniform_AB_idtw x GXI Result 

mm_data = glob.mm_data;         % macro + micro moments
V = glob.V;
GXI = GXI(:,[1 2 5]);
    
Np = 15;
Nparm = 3;

Nmom  = length(mm_data);
G     = zeros(Nmom,Nparm);

est  = x(1:Nparm);

for i = 1:Nparm
   x = GXI(((i-1)*Np+1):(i*Np),i); 
   
   % Second order polynomial approx.
   xmat = [ones(length(x),1) x x.^2];

   for j = 1:Nmom
       y = Result(((i-1)*Np+1):(i*Np),j);
       coef=(xmat'*xmat)\(xmat'*y);
       % Update Jacobian 
       G(j,i)=coef(2)+coef(3)*2*est(1,i);
   end
   
end

% Weight
weight = eye(length(V));
Lambda=(G'*weight*G)\(G'*weight);

% Standard errors
NS = 15; 
cov = V; 
se = (diag(Lambda*(1+1/NS)*cov*Lambda').^0.5)';

% Create Sensitivity Analysis 
% ten percentage change of each moments
Sens_Matrix=zeros(Nmom,Nparm);

for i=1:1:Nmom
     temp=zeros(Nmom,1); temp(i)=mm_data(i)*0.1;
%     temp=zeros(Nmom,1); temp(i)=mm_data(i)*sqrt(V(i,i));
    Sens_Matrix(i,:)=(Lambda*temp)';
end

fprintf('Uniform (AB) \n')
fprintf('point estimate = %10.3f %10.3f %10.3f \n',est(1),est(2),est(3));
fprintf('standard error = %10.3f %10.3f %10.3f \n',se(1), se(2),se(3));
fprintf('\n')
% disp('sensitivity measures')
% disp(Sens_Matrix)

save se_Uniform_AB est se
save Sens_Matrix Sens_Matrix