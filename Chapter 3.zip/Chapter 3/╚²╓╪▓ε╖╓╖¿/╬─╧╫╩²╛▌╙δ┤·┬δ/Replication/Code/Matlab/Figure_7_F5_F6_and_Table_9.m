% Updated by Jan 29, 2022
% This file collects simulation results and generate graphs

clearvars -except dropboxpath
clc
close all

% dropboxpath='/Users/xianjiang/Dropbox/Research/Fiscal Incentive and Investment/Replication/';
% cepath=[dropboxpath 'Code/Matlab/myfunctions/compecon/']; path([cepath 'cetools;' cepath 'cedemos'],path)
% 
% addpath([dropboxpath 'Code/Matlab/myfunctions'])
% addpath([dropboxpath 'Code/Matlab/estimation'])
% addpath([dropboxpath 'RawData'])
% addpath([dropboxpath 'AnalysisData'])

load polsim_uniform_AB_idtw pars P UCC IK VAT CIT V K I IK0 VAT0 CIT0 V0 K0 I0

np = 10;	% np year's window

idx_vat = (P(:,1)>0);
idx_cit = (P(:,2)>0);
idx_bd  = (P(:,3)>0);
idx_itc = (P(:,4)>0);
pol_vat = 0.170 - [0;P(idx_vat,1)];
pol_cit = 0.154 -    P(idx_cit,2); 
pol_bd  = [0;P(idx_bd,3)]; 
pol_itc = [0;P(idx_itc,4)];

%% Calculate percentage changes 
dUCC = NaN(length(P),1);
dIK = NaN(length(P),1);
dIKagg = NaN(length(P),1);
dEXT = NaN(length(P),1);

dTAX = NaN(length(P),1);    % average tax payments
dTAXagg = NaN(length(P),1); % aggregate tax payments
dVATagg = NaN(length(P),1);
dCITagg = NaN(length(P),1);
dITCagg = NaN(length(P),1);
dVATCITagg = NaN(length(P),1);

dV = NaN(length(P),1);

dIKagg_01 = NaN(length(P),1);
dIKagg_11 = NaN(length(P),1);

IKagg_01_sh = NaN(length(P),1);
IKagg_11_sh = NaN(length(P),1);

dIKagg_01_sh = NaN(length(P),1); % aggregate investment rate from those firms switching from inaction to investing
dIKagg_11_sh = NaN(length(P),1); % aggregate investment rate from those firms with positive invesmtent in the previous period 

dTAXagg_01 = NaN(length(P),1);  % aggregate tax payments from (0-1) firms 
dTAXagg_11 = NaN(length(P),1);  % aggregate tax payments from (1-1) firms

dI = NaN(length(P),1);
dI_ext = NaN(length(P),1);
dI_int = NaN(length(P),1);

ik_inaction = 0;

for i = 1:length(P)

    dUCC(i,1)   = UCC(1,2,i)./UCC(1,1,i) - 1;
    dIK(i,1)    = mean(mean(IK(:,100:100+np-1,i),1)./mean(IK0(:,100:100+np-1,i),1)-1,2);
    dIKagg(i,1) = mean((sum(IK(:,100:100+np-1,i).*K(:,100:100+np-1,i),1)./sum(K(:,100:100+np-1,i),1))./(sum(IK0(:,100:100+np-1,i).*K0(:,100:100+np-1,i),1)./sum(K0(:,100:100+np-1,i),1))-1,2);
    
    dV(i,1) = mean(mean(V(:,100:100+np-1,i) ,1)./mean(V0(:,100:100+np-1,i) ,1)-1,2);
    dEXT(i,1) = (mean(sum(IK(:,100:100+np-1,i)>ik_inaction,1),2)-mean(sum(IK0(:,100:100+np-1,i)>ik_inaction,1),2))./mean(sum(IK0(:,100:100+np-1,i)>ik_inaction,1),2);

    if (i <= length(pol_vat) + length(pol_cit) + length(pol_bd)-1||i==length(P))
        temp  = cumsum(mean(VAT(:,100:100+np-1,i)  + CIT(:,100:100+np-1,i),1) ./(1+pars.r).^(0:np-1),2)./cumsum(mean(VAT0(:,100:100+np-1,i) + CIT0(:,100:100+np-1,i),1)./(1+pars.r).^(0:np-1),2) - 1;
        dTAX(i,1)    = temp(:,end);
        temp  = cumsum(sum(VAT(:,100:100+np-1,i)+CIT(:,100:100+np-1,i),1)./(1+pars.r).^(0:np-1),2)./cumsum(sum(VAT0(:,100:100+np-1,i)+CIT0(:,100:100+np-1,i),1)./(1+pars.r).^(0:np-1),2) - 1;
        dTAXagg(i,1) = temp(:,end);
        
        
        temp = (cumsum(sum(VAT(:,100:100+np-1,i),1)./(1+pars.r).^(0:np-1),2)-cumsum(sum(VAT0(:,100:100+np-1,i),1)./(1+pars.r).^(0:np-1),2)) ./ ...	% changes in aggregate vat revenue
                cumsum(sum(VAT0(:,100:100+np-1,i)+CIT0(:,100:100+np-1,i),1)./(1+pars.r).^(0:np-1),2); % total tax revenue before the reform
        dVATagg(i,1) = temp(:,end);
        temp = (cumsum(sum(CIT(:,100:100+np-1,i),1)./(1+pars.r).^(0:np-1),2)-cumsum(sum(CIT0(:,100:100+np-1,i),1)./(1+pars.r).^(0:np-1),2)) ./ ...	% changes in aggregate cit revenue
                cumsum(sum(VAT0(:,100:100+np-1,i)+CIT0(:,100:100+np-1,i),1)./(1+pars.r).^(0:np-1),2); % total tax revenue before the reform        
        dCITagg(i,1) = temp(:,end);
    else
        temp  = cumsum(mean(VAT(:,100:100+np-1,i)  + CIT(:,100:100+np-1,i)-P(i,4).*I(:,100:100+np-1,i),1) ./(1+pars.r).^(0:np-1),2)./cumsum(mean(VAT0(:,100:100+np-1,i) + CIT0(:,100:100+np-1,i),1)./(1+pars.r).^(0:np-1),2) - 1;
        dTAX(i,1)    = temp(:,end);
        temp  = cumsum(sum(VAT(:,100:100+np-1,i)+CIT(:,100:100+np-1,i)-P(i,4).*I(:,100:100+np-1,i),1)./(1+pars.r).^(0:np-1),2)./cumsum(sum(VAT0(:,100:100+np-1,i)+CIT0(:,100:100+np-1,i),1)./(1+pars.r).^(0:np-1),2) - 1;
        dTAXagg(i,1) = temp(:,end);
        
        temp = (cumsum(sum(VAT(:,100:100+np-1,i),1)./(1+pars.r).^(0:np-1),2)-cumsum(sum(VAT0(:,100:100+np-1,i),1)./(1+pars.r).^(0:np-1),2)) ./ ...	% changes in aggregate vat revenue
                cumsum(sum(VAT0(:,100:100+np-1,i)+CIT0(:,100:100+np-1,i),1)./(1+pars.r).^(0:np-1),2); % total tax revenue before the reform
        dVATagg(i,1) = temp(:,end);
        temp = (cumsum(sum(CIT(:,100:100+np-1,i),1)./(1+pars.r).^(0:np-1),2)-cumsum(sum(CIT0(:,100:100+np-1,i),1)./(1+pars.r).^(0:np-1),2)) ./ ...	% changes in aggregate cit revenue
                cumsum(sum(VAT0(:,100:100+np-1,i)+CIT0(:,100:100+np-1,i),1)./(1+pars.r).^(0:np-1),2); % total tax revenue before the reform        
        dCITagg(i,1) = temp(:,end);
        
        temp =  -cumsum(P(i,4).*sum(I(:,100:100+np-1,i),1)./(1+pars.r).^(0:np-1),2)./ ...	% Investment Tax Credit Rate expenses
                cumsum(sum(VAT0(:,100:100+np-1,i)+CIT0(:,100:100+np-1,i),1)./(1+pars.r).^(0:np-1),2); % total tax revenue before the reform 
        dITCagg(i,1) = temp(:,end);
        
        temp = (cumsum(sum(VAT(:,100:100+np-1,i) + CIT(:,100:100+np-1,i),1)./(1+pars.r).^(0:np-1),2)-cumsum(sum(VAT0(:,100:100+np-1,i)+CIT0(:,100:100+np-1,i),1)./(1+pars.r).^(0:np-1),2)) ./ ...	% changes in aggregate vat and cit revenue
                cumsum(sum(VAT0(:,100:100+np-1,i)+CIT0(:,100:100+np-1,i),1)./(1+pars.r).^(0:np-1),2); % total tax revenue before the reform
        dVATCITagg(i,1) = temp(:,end);
    end
    
    %% Decompose investment into extensive margin change and intensive margin change
    
    idx_01 = (IK(:,100-1:100+np-2,i)==ik_inaction & IK(:,100:100+np-1,i)>ik_inaction);  % indicator of firms that switch form inaction to investing 
    idx_11 = (IK(:,100-1:100+np-2,i)>ik_inaction & IK(:,100:100+np-1,i)>ik_inaction);	% indicator of firms that invest in both of the previous and current period
    
    IKagg    = sum(IK(:,100:100+np-1,i).*K(:,100:100+np-1,i)./sum(K(:,100:100+np-1,i),1));             % aggregate investment rate
    IKagg_01 = sum(idx_01.*(IK(:,100:100+np-1,i).*K(:,100:100+np-1,i)./sum(K(:,100:100+np-1,i),1)),1); % aggregate investment rate by idx_01
    IKagg_11 = sum(idx_11.*(IK(:,100:100+np-1,i).*K(:,100:100+np-1,i)./sum(K(:,100:100+np-1,i),1)),1); % aggregate investment rate by idx_11
    IKagg_01_sh(i,1) = mean(IKagg_01./IKagg,2);         % average fraction of investment rate by idx_01
    IKagg_11_sh(i,1) = mean(IKagg_11./IKagg,2);         % average fraction of investment rate by idx_11
    
        % counter-factual 
        idx_01_cf = (IK0(:,100-1:100+np-2,i)==ik_inaction & IK0(:,100:100+np-1,i)>ik_inaction);  % indicator of firms that switch form inaction to investing 
        idx_11_cf = (IK0(:,100-1:100+np-2,i)>ik_inaction & IK0(:,100:100+np-1,i)>ik_inaction);	% indicator of firms that invest in both of the previous and current period

        IKagg_cf    = sum(IK0(:,100:100+np-1,i).*K0(:,100:100+np-1,i)./sum(K0(:,100:100+np-1,i),1));                   % aggregate investment rate 
        IKagg_01_cf = sum(idx_01_cf.*(IK0(:,100:100+np-1,i).*K0(:,100:100+np-1,i)./sum(K0(:,100:100+np-1,i),1)),1); % aggregate investment rate by idx_01
        IKagg_11_cf = sum(idx_11_cf.*(IK0(:,100:100+np-1,i).*K0(:,100:100+np-1,i)./sum(K0(:,100:100+np-1,i),1)),1); % aggregate investment rate by idx_11
        IKagg_01_sh_cf = mean(IKagg_01_cf./IKagg_cf,2);
        IKagg_11_sh_cf = mean(IKagg_11_cf./IKagg_cf,2);
        
    dIKagg_01(i,1) = mean(IKagg_01./IKagg_cf-1,2);       % percentage change in the aggregate investment rate from (0-1) firms
    dIKagg_11(i,1) = mean(IKagg_11./IKagg_cf-1,2);       % percentage change in the aggregate investment rate from (1-1) firms
    dIKagg_01_sh(i,1) = IKagg_01_sh(i,1)./IKagg_01_sh_cf-1; % percentage change in the share of aggregate investment rate from (0-1) firms
    
    %% Decompose tax payment into extensive margin change and intensive margin change
    
    % tax payment by (0-1) firms
    % tax payment by (1-1) firms
    
    if (i <= length(pol_vat) + length(pol_cit) + length(pol_bd)-1||i==length(P))
        temp  = cumsum(sum(idx_01.*(VAT(:,100:100+np-1,i)+CIT(:,100:100+np-1,i)),1)./(1+pars.r).^(0:np-1),2)./cumsum(sum(idx_01_cf.*(VAT0(:,100:100+np-1,i)+CIT0(:,100:100+np-1,i)),1)./(1+pars.r).^(0:np-1),2) - 1;
        dTAXagg_01(i,1) = temp(:,end);
        
        temp  = cumsum(sum(idx_11.*(VAT(:,100:100+np-1,i)+CIT(:,100:100+np-1,i)),1)./(1+pars.r).^(0:np-1),2)./cumsum(sum(idx_11_cf.*(VAT0(:,100:100+np-1,i)+CIT0(:,100:100+np-1,i)),1)./(1+pars.r).^(0:np-1),2) - 1;
        dTAXagg_11(i,1) = temp(:,end);
    else
        temp  = cumsum(sum(idx_01.*(VAT(:,100:100+np-1,i)+CIT(:,100:100+np-1,i)-P(i,4).*I(:,100:100+np-1,i)),1)./(1+pars.r).^(0:np-1),2)./cumsum(sum(idx_01_cf.*(VAT0(:,100:100+np-1,i)+CIT0(:,100:100+np-1,i)),1)./(1+pars.r).^(0:np-1),2) - 1;
        dTAXagg_01(i,1) = temp(:,end);
        temp  = cumsum(sum(idx_11.*(VAT(:,100:100+np-1,i)+CIT(:,100:100+np-1,i)-P(i,4).*I(:,100:100+np-1,i)),1)./(1+pars.r).^(0:np-1),2)./cumsum(sum(idx_11_cf.*(VAT0(:,100:100+np-1,i)+CIT0(:,100:100+np-1,i)),1)./(1+pars.r).^(0:np-1),2) - 1;
        dTAXagg_11(i,1) = temp(:,end);
    end
    
    %% Decompose aggregate investment into extensive margin change and intensive margin change
    temp = cumsum(sum(I(:,100:100+np-1,i),1)./(1+pars.r).^(0:np-1),2)./cumsum(sum(I0(:,100:100+np-1,i),1)./(1+pars.r).^(0:np-1),2) - 1;
    dI(i,1) = temp(end);
    
end


%% Graphs, comparing different policies 

%% Percentage change in investment rate to Percentage Change in tax revenue (the slope is the elasticity of investment rate w.r.t tax revenue)
close all

x1 = [0;-dTAXagg(idx_vat)];
y1 = [0; dI(idx_vat) ];
x2 = -dTAXagg(idx_cit);
y2 = dI(idx_cit);
x3 = [0;-dTAXagg(idx_itc)];
y3 = [0; dI(idx_itc) ];
x4 = [0;-dTAXagg(idx_bd)];
y4 = [0; dI(idx_bd) ];
    
xlim1 = -5;
xlim2 = 60;
ylim1 = -5;
ylim2 = 60;

idx1 = (1:2:length(x1))';
idx2 = (1:1:15)';
idx3 = (1:2:length(x3))';
idx4 = (1:2:length(x4))';


%  VAT 
    
    label1 = pol_vat;
    x1_plot = x1(idx1).*100;
    y1_plot = y1(idx1).*100;
    label1_plot = label1(idx1).*100;

    fig_i_taxagg_vat = figure;
    h1 = plot(x1_plot,y1_plot,'r--x','Linewidth',2,'MarkerSize',6,'MarkerEdgeColor','r','MarkerFaceColor','r');
    for i = 1:length(x1_plot)
        text(x1_plot(i),y1_plot(i),strcat({'  '},num2str(label1_plot(i)),{'  '}),'Color','r','Fontsize',13,'Units','data','HorizontalAlignment','right')
    end
    %title('Aggregate Investment Rate','FontSize', 13)
    xlabel('Percentage Change in Tax Revenue (%)','FontSize', 18)
    ylabel('Percentage Change in Investment (%)','FontSize', 18)
    
    xlim([xlim1 xlim2]); ylim([ylim1 ylim2])
    hold on
    plot([0,0],[ylim1,ylim2], '--','Color',[0,0,0]+0.6)
    plot([xlim1,xlim2],[0,0], '--','Color',[0,0,0]+0.6)
    plot([xlim1,min(xlim2,ylim2)],[xlim1,min(xlim2,ylim2)],'--','Color',[0,0,0]+0.6)
    hold off
    legend(h1,{'VAT Rate (pp.)'},'FontSize',13,'Location','Southeast','box','off')    
    
%  VAT + CIT

    label1 = pol_vat;
    x1_plot = x1(idx1).*100;
    y1_plot = y1(idx1).*100;
    label1_plot = label1(idx1).*100;
    
    
    label2 = pol_cit;
    x2_plot = x2(idx2).*100;
    y2_plot = y2(idx2).*100;
    label2_plot = label2(idx2).*100;

    fig_i_taxagg_vat_cit = figure;
    h1 = plot(x1_plot,y1_plot,'r--x','Linewidth',2,'MarkerSize',6,'MarkerEdgeColor','r');
    hold on
    h2 = plot(x2_plot,y2_plot,'b:^','Linewidth',2,'MarkerSize',6,'MarkerEdgeColor','b');
    for i = 1:length(x1_plot)
        text(x1_plot(i),y1_plot(i),strcat({'  '},num2str(label1_plot(i)),{'  '}),'Color','r','Fontsize',13,'Units','data','HorizontalAlignment','right')
    end
    for i = 1:length(x2_plot)
        text(x2_plot(i),y2_plot(i),strcat({'  '},num2str(label2_plot(i)),{'  '}),'Color','b','Fontsize',13,'Units','data','HorizontalAlignment','left')
    end
    %title('Aggregate Investment Rate','FontSize', 13)
    xlabel('Percentage Change in Tax Revenue (%)','FontSize', 18)
    ylabel('Percentage Change in Investment (%)','FontSize', 18)
    xlim([xlim1 xlim2]); ylim([ylim1 ylim2])
    plot([0,0],[ylim1,ylim2], '--','Color',[0,0,0]+0.6)
    plot([xlim1,xlim2],[0,0], '--','Color',[0,0,0]+0.6)
    plot([xlim1,min(xlim2,ylim2)],[xlim1,min(xlim2,ylim2)],'--','Color',[0,0,0]+0.6)
    hold off
    legend([h1 h2],{'VAT Rate (pp.)','Corporate Income Tax Rate (pp.)'},'FontSize',13,'Location','Southeast','box','off')

%  VAT + ITC
    label1 = pol_vat;
    x1_plot = x1(idx1).*100;
    y1_plot = y1(idx1).*100;
    label1_plot = label1(idx1).*100;
    
    label3 = pol_itc;
    x3_plot = x3(idx3).*100;
    y3_plot = y3(idx3).*100;
    label3_plot = label3(idx3).*100;

    fig_i_taxagg_vat_itc = figure;
    h1 = plot(x1_plot,y1_plot,'r--x','Linewidth',2,'MarkerSize',6,'MarkerEdgeColor','r');
    hold on
%     h2 = plot(x2_plot,y2_plot,'b:^','Linewidth',2,'MarkerSize',6,'MarkerEdgeColor','b');
    h3 = plot(x3_plot,y3_plot,'k--o','Linewidth',2,'MarkerSize',6,'MarkerEdgeColor','k');
    for i = 1:length(x1_plot)
        text(x1_plot(i),y1_plot(i),strcat({'  '},num2str(label1_plot(i)),{'  '}),'Color','r','Fontsize',13,'Units','data','HorizontalAlignment','right')
    end
%     for i = 1:length(x2_plot)
%         text(x2_plot(i),y2_plot(i),strcat({'  '},num2str(label2_plot(i)),{'  '}),'Color','b','Fontsize',13,'Units','data','HorizontalAlignment','left')
%     end
    for i = 1:length(x3_plot)
        text(x3_plot(i),y3_plot(i),strcat({'  '},num2str(label3_plot(i)),{'  '}),'Color','k','Fontsize',13,'Units','data','HorizontalAlignment','left')
    end
    %title('Aggregate Investment Rate','FontSize', 13)
    xlabel('Percentage Change in Tax Revenue (%)','FontSize', 18)
    ylabel('Percentage Change in Investment (%)','FontSize', 18)
    xlim([xlim1 xlim2]); ylim([ylim1 ylim2])
    plot([0,0],[ylim1,ylim2], '--','Color',[0,0,0]+0.6)
    plot([xlim1,xlim2],[0,0], '--','Color',[0,0,0]+0.6)
    plot([xlim1,min(xlim2,ylim2)],[xlim1,min(xlim2,ylim2)],'--','Color',[0,0,0]+0.6)
    hold off
%     legend([h1 h2 h3],{'VAT Rate (pp.)','Corporate Income Tax Rate (pp.)','Investment Tax Credit Rate (pp.)'},'FontSize',13,'Location','Southeast','box','off')
    legend([h1 h3],{'VAT Rate (pp.)','Investment Tax Credit Rate Rate (pp.)'},'FontSize',13,'Location','Southeast','box','off')
    
%  VAT + CIT + ITC
    label1 = pol_vat;
    x1_plot = x1(idx1).*100;
    y1_plot = y1(idx1).*100;
    label1_plot = label1(idx1).*100;
    
    label2 = pol_cit;
    x2_plot = x2(idx2).*100;
    y2_plot = y2(idx2).*100;
    label2_plot = label2(idx2).*100;
    
    label3 = pol_itc;
    x3_plot = x3(idx3).*100;
    y3_plot = y3(idx3).*100;
    label3_plot = label3(idx3).*100;

    fig_i_taxagg_vat_cit_itc = figure;
    h1 = plot(x1_plot,y1_plot,'r--x','Linewidth',2,'MarkerSize',6,'MarkerEdgeColor','r');
    hold on
    h2 = plot(x2_plot,y2_plot,'b:^','Linewidth',2,'MarkerSize',6,'MarkerEdgeColor','b');
    h3 = plot(x3_plot,y3_plot,'k--o','Linewidth',2,'MarkerSize',6,'MarkerEdgeColor','k');
    for i = 1:length(x1_plot)
        text(x1_plot(i),y1_plot(i),strcat({'  '},num2str(label1_plot(i)),{'  '}),'Color','r','Fontsize',13,'Units','data','HorizontalAlignment','right')
    end
    for i = 1:length(x2_plot)
        text(x2_plot(i),y2_plot(i),strcat({'  '},num2str(label2_plot(i)),{'  '}),'Color','b','Fontsize',13,'Units','data','HorizontalAlignment','left')
    end
    for i = 1:length(x3_plot)
        text(x3_plot(i),y3_plot(i),strcat({'  '},num2str(label3_plot(i)),{'  '}),'Color','k','Fontsize',13,'Units','data','HorizontalAlignment','left')
    end
    %title('Aggregate Investment Rate','FontSize', 13)
    xlabel('Percentage Change in Tax Revenue (%)','FontSize', 18)
    ylabel('Percentage Change in Investment (%)','FontSize', 18)
    xlim([xlim1 xlim2]); ylim([ylim1 ylim2])
    plot([0,0],[ylim1,ylim2], '--','Color',[0,0,0]+0.6)
    plot([xlim1,xlim2],[0,0], '--','Color',[0,0,0]+0.6)
    plot([xlim1,min(xlim2,ylim2)],[xlim1,min(xlim2,ylim2)],'--','Color',[0,0,0]+0.6)
    hold off
    legend([h1 h2 h3],{'VAT Rate (pp.)','Corporate Income Tax Rate (pp.)','Investment Tax Credit Rate Rate (pp.)'},'FontSize',13,'Location','Southeast','box','off')

    
saveas(fig_i_taxagg_vat_cit,[dropboxpath 'Output/Figure_7A.png'])
saveas(fig_i_taxagg_vat_itc,[dropboxpath 'Output/Figure_7B.png'])

%%  DECOMPOSITION OF THE CHANGE IN TAX REVENUES
%%% Change in aggregate investment to Change in direct tax losses
close all

x1 = [0;-dVATagg(idx_vat)]; % absolute values of percentage VAT revenue losses for VAT reforms
y1 = [0; dI(idx_vat) ];     % percentage increase in aggregate investment
x2 = -dCITagg(idx_cit);     % absolute values of percentage CIT revenue losses for CIT reforms (the last one is TCJA)
y2 = dI(idx_cit);           % percentage increase in aggregate investment
x3 = [0;-dITCagg(idx_itc)]; % absolute values of percentage ITC expenses for ITC policies
y3 = [0; dI(idx_itc) ];     % percentage increase in aggregate investment
    

xlim1 = -5;
xlim2 = 70;
ylim1 = -5;
ylim2 = 70;

idx1 = (1:2:length(x1))';
idx2 = (1:1:15)';
idx3 = (1:2:length(x3))';


%  VAT + CIT
    label1 = pol_vat;
    x1_plot = x1(idx1).*100;
    y1_plot = y1(idx1).*100;
    label1_plot = label1(idx1).*100;
    
    
    label2 = pol_cit;
    x2_plot = x2(idx2).*100;
    y2_plot = y2(idx2).*100;
    label2_plot = label2(idx2).*100;

    fig_i_directtaxagg_vat_cit = figure;
    h1 = plot(x1_plot,y1_plot,'r--x','Linewidth',2,'MarkerSize',6,'MarkerEdgeColor','r');
    hold on
    h2 = plot(x2_plot,y2_plot,'b:^','Linewidth',2,'MarkerSize',6,'MarkerEdgeColor','b');
    for i = 1:length(x1_plot)
        text(x1_plot(i),y1_plot(i),strcat({'  '},num2str(label1_plot(i)),{'  '}),'Color','r','Fontsize',13,'Units','data','HorizontalAlignment','right')
    end
    for i = 1:length(x2_plot)
        text(x2_plot(i),y2_plot(i),strcat({'  '},num2str(label2_plot(i)),{'  '}),'Color','b','Fontsize',13,'Units','data','HorizontalAlignment','left')
    end
    xlabel('Percentage Change of Direct Tax Losses (%)','FontSize', 17)
    ylabel('Percentage Change in Investment (%)','FontSize', 18)
    xlim([xlim1 xlim2]); ylim([ylim1 ylim2])
    plot([0,0],[ylim1,ylim2], '--','Color',[0,0,0]+0.6)
    plot([xlim1,xlim2],[0,0], '--','Color',[0,0,0]+0.6)
    plot([xlim1,min(xlim2,ylim2)],[xlim1,min(xlim2,ylim2)],'--','Color',[0,0,0]+0.6)
    hold off
    legend([h1 h2],{'VAT Rate (pp.)','Corporate Income Tax Rate (pp.)'},'FontSize',13,'Location','Southeast','box','off')
    
%  VAT + ITC
    label1 = pol_vat;
    x1_plot = x1(idx1).*100;
    y1_plot = y1(idx1).*100;
    label1_plot = label1(idx1).*100;
    
    label3 = pol_itc;
    x3_plot = x3(idx3).*100;
    y3_plot = y3(idx3).*100;
    label3_plot = label3(idx3).*100;

    fig_i_directtaxagg_vat_itc = figure;
    h1 = plot(x1_plot,y1_plot,'r--x','Linewidth',2,'MarkerSize',6,'MarkerEdgeColor','r');
    hold on
    h3 = plot(x3_plot,y3_plot,'k--o','Linewidth',2,'MarkerSize',6,'MarkerEdgeColor','k');
    for i = 1:length(x1_plot)
        text(x1_plot(i),y1_plot(i),strcat({'  '},num2str(label1_plot(i)),{'  '}),'Color','r','Fontsize',13,'Units','data','HorizontalAlignment','right')
    end
    for i = 1:length(x3_plot)
        text(x3_plot(i),y3_plot(i),strcat({'  '},num2str(label3_plot(i)),{'  '}),'Color','k','Fontsize',13,'Units','data','HorizontalAlignment','left')
    end
    xlabel('Percentage Change of Direct Tax Losses (%)','FontSize', 17)
    ylabel('Percentage Change in Investment (%)','FontSize', 18)
    xlim([xlim1 xlim2]); ylim([ylim1 ylim2])
    plot([0,0],[ylim1,ylim2], '--','Color',[0,0,0]+0.6)
    plot([xlim1,xlim2],[0,0], '--','Color',[0,0,0]+0.6)
    plot([xlim1,min(xlim2,ylim2)],[xlim1,min(xlim2,ylim2)],'--','Color',[0,0,0]+0.6)
    hold off
    legend([h1 h3],{'VAT Rate (pp.)','Investment Tax Credit Rate (pp.)'},'FontSize',13,'Location','Southeast','box','off')
    
saveas(fig_i_directtaxagg_vat_cit,[dropboxpath 'Output/Figure_F5_A1.png'])
saveas(fig_i_directtaxagg_vat_itc,[dropboxpath 'Output/Figure_F5_B1.png'])

%% Change in aggregate investment to Change in tax revenue from behavioral responses
% the slope for CIT is the inverse share of VAT to total tax revenues 
close all

x1 = [0;dCITagg(idx_vat)];  % absolute values of percentage VAT revenue losses for VAT reforms
y1 = [0; dI(idx_vat) ];     % percentage increase in aggregate investment
x2 = dVATagg(idx_cit);      % absolute values of percentage CIT revenue losses for CIT reforms (the last one is TCJA)
y2 = dI(idx_cit);           % percentage increase in aggregate investment
x3 = [0;dVATCITagg(idx_itc)]; % absolute values of percentage ITC expenses for ITC policies
y3 = [0; dI(idx_itc) ];     % percentage increase in aggregate investment
    

xlim1 = -5;
xlim2 = 70;
ylim1 = -5;
ylim2 = 70;

idx1 = (1:2:length(x1))';
idx2 = (1:1:15)';
idx3 = (1:2:length(x3))';
idx4 = (1:2:length(x4))';


%  VAT + CIT

    label1 = pol_vat;
    x1_plot = x1(idx1).*100;
    y1_plot = y1(idx1).*100;
    label1_plot = label1(idx1).*100;
    
    
    label2 = pol_cit;
    x2_plot = x2(idx2).*100;
    y2_plot = y2(idx2).*100;
    label2_plot = label2(idx2).*100;

    fig_i_behavioraltaxagg_vat_cit = figure;
    h1 = plot(x1_plot,y1_plot,'r--x','Linewidth',2,'MarkerSize',6,'MarkerEdgeColor','r');
    hold on
    h2 = plot(x2_plot,y2_plot,'b:^','Linewidth',2,'MarkerSize',6,'MarkerEdgeColor','b');
    for i = 1:length(x1_plot)
        text(x1_plot(i),y1_plot(i),strcat({'  '},num2str(label1_plot(i)),{'  '}),'Color','r','Fontsize',13,'Units','data','HorizontalAlignment','right')
    end
    for i = 1:length(x2_plot)
        text(x2_plot(i),y2_plot(i),strcat({'  '},num2str(label2_plot(i)),{'  '}),'Color','b','Fontsize',13,'Units','data','HorizontalAlignment','left')
    end
    xlabel('Percentage Change of Tax Revenues from Bahavioral Responses (%)','FontSize', 17)
    ylabel('Percentage Change in Investment (%)','FontSize', 18)
    xlim([xlim1 xlim2]); ylim([ylim1 ylim2])
    plot([0,0],[ylim1,ylim2], '--','Color',[0,0,0]+0.6)
    plot([xlim1,xlim2],[0,0], '--','Color',[0,0,0]+0.6)
    plot([xlim1,min(xlim2,ylim2)],[xlim1,min(xlim2,ylim2)],'--','Color',[0,0,0]+0.6)
    hold off
    legend([h1 h2],{'VAT Rate (pp.)','Corporate Income Tax Rate (pp.)'},'FontSize',13,'Location','Southeast','box','off')
    
%  VAT + ITC
    label1 = pol_vat;
    x1_plot = x1(idx1).*100;
    y1_plot = y1(idx1).*100;
    label1_plot = label1(idx1).*100;
    
    label3 = pol_itc;
    x3_plot = x3(idx3).*100;
    y3_plot = y3(idx3).*100;
    label3_plot = label3(idx3).*100;

    fig_i_behavioraltaxagg_vat_itc = figure;
    h1 = plot(x1_plot,y1_plot,'r--x','Linewidth',2,'MarkerSize',6,'MarkerEdgeColor','r');
    hold on
    h3 = plot(x3_plot,y3_plot,'k--o','Linewidth',2,'MarkerSize',6,'MarkerEdgeColor','k');
    for i = 1:length(x1_plot)
        text(x1_plot(i),y1_plot(i),strcat({'  '},num2str(label1_plot(i)),{'  '}),'Color','r','Fontsize',13,'Units','data','HorizontalAlignment','right')
    end
    for i = 1:length(x3_plot)
        text(x3_plot(i),y3_plot(i),strcat({'  '},num2str(label3_plot(i)),{'  '}),'Color','k','Fontsize',13,'Units','data','HorizontalAlignment','left')
    end
    xlabel('Percentage Change of Tax Revenues from Bahavioral Responses (%)','FontSize', 17)
    ylabel('Percentage Change in Investment (%)','FontSize', 18)
    xlim([xlim1 xlim2]); ylim([ylim1 ylim2])
    plot([0,0],[ylim1,ylim2], '--','Color',[0,0,0]+0.6)
    plot([xlim1,xlim2],[0,0], '--','Color',[0,0,0]+0.6)
    plot([xlim1,min(xlim2,ylim2)],[xlim1,min(xlim2,ylim2)],'--','Color',[0,0,0]+0.6)
    hold off
    legend([h1 h3],{'VAT Rate (pp.)','Investment Tax Credit Rate (pp.)'},'FontSize',13,'Location','Southeast','box','off')
    
saveas(fig_i_behavioraltaxagg_vat_cit,[dropboxpath 'Output/Figure_F5_A2.png'])
saveas(fig_i_behavioraltaxagg_vat_itc,[dropboxpath 'Output/Figure_F5_B2.png'])

%% Change in firm value to Change in tax revenue (the slope is the elasticity of investment rate w.r.t tax revenue)
% close all

xlim1 = -5;
xlim2 = 45;
ylim1 = -5;
ylim2 = 25;

idx1 = (1:2:length(x1))';
idx2 = (1:1:9)';
idx3 = (1:2:length(x3))';
idx4 = (1:2:length(x4))';


%  VAT 
    x1 = [0;-dTAXagg(idx_vat)];
    y1 = [0; dV(idx_vat) ];
    label1 = pol_vat;
    x1_plot = x1(idx1).*100;
    y1_plot = y1(idx1).*100;
    label1_plot = label1(idx1).*100;

    fig_v_taxagg_vat = figure;
    h1 = plot(x1_plot,y1_plot,'r--x','Linewidth',2,'MarkerSize',6,'MarkerEdgeColor','r');
    for i = 1:length(x1_plot)
        text(x1_plot(i),y1_plot(i),strcat({'  '},num2str(label1_plot(i)),{'  '}),'Color','r','Fontsize',13,'Units','data','HorizontalAlignment','right')
    end
    %title('Average Firm Value','FontSize', 13)
    xlabel('Percentage Change in Tax Revenue (%)','FontSize', 14)
    ylabel('Percentage Change in Firm Value (%)','FontSize', 14)
    xlim([xlim1 xlim2]); ylim([ylim1 ylim2])
    hold on
    plot([0,0],[ylim1,ylim2], '--','Color',[0,0,0]+0.6)
    plot([xlim1,xlim2],[0,0], '--','Color',[0,0,0]+0.6)
    plot([xlim1,min(xlim2,ylim2)],[xlim1,min(xlim2,ylim2)],'--','Color',[0,0,0]+0.6)
    hold off
    legend(h1,{'VAT Rate (pp.)'},'FontSize',13,'Location','Southeast','box','off')

    
%  VAT + CIT
    x1 = [0;-dTAXagg(idx_vat)];
    y1 = [0; dV(idx_vat) ];
    label1 = pol_vat;
    x1_plot = x1(idx1).*100;
    y1_plot = y1(idx1).*100;
    label1_plot = label1(idx1).*100;
    
    x2 = -dTAXagg(idx_cit);
    y2 = dV(idx_cit);
    label2 = pol_cit;
    x2_plot = x2(idx2).*100;
    y2_plot = y2(idx2).*100;
    label2_plot = label2(idx2).*100;

    fig_v_taxagg_vat_cit = figure;
    h1 = plot(x1_plot,y1_plot,'r--x','Linewidth',2,'MarkerSize',6,'MarkerEdgeColor','r');
    hold on
    h2 = plot(x2_plot,y2_plot,'b:^','Linewidth',2,'MarkerSize',6,'MarkerEdgeColor','b');
    for i = 1:length(x1_plot)
        text(x1_plot(i),y1_plot(i),strcat({'  '},num2str(label1_plot(i)),{'  '}),'Color','r','Fontsize',13,'Units','data','HorizontalAlignment','right')
    end
    for i = 1:length(x2_plot)
        text(x2_plot(i),y2_plot(i),strcat({'  '},num2str(label2_plot(i)),{'  '}),'Color','b','Fontsize',13,'Units','data','HorizontalAlignment','left')
    end
    %title('Average Firm Value','FontSize', 13)
    xlabel('Percentage Change in Tax Revenue (%)','FontSize', 14)
    ylabel('Percentage Change in Firm Value (%)','FontSize', 14)
    xlim([xlim1 xlim2]); ylim([ylim1 ylim2])
    plot([0,0],[ylim1,ylim2], '--','Color',[0,0,0]+0.6)
    plot([xlim1,xlim2],[0,0], '--','Color',[0,0,0]+0.6)
    plot([xlim1,min(xlim2,ylim2)],[xlim1,min(xlim2,ylim2)],'--','Color',[0,0,0]+0.6)
    hold off
    legend([h1 h2],{'VAT Rate (pp.)','Corporate Income Tax Rate (pp.)'},'FontSize',13,'Location','Southeast','box','off')

%  VAT + ITC
    x1 = [0;-dTAXagg(idx_vat)];
    y1 = [0; dV(idx_vat) ];
    label1 = pol_vat;
    x1_plot = x1(idx1).*100;
    y1_plot = y1(idx1).*100;
    label1_plot = label1(idx1).*100;
    
    x3 = [0;-dTAXagg(idx_itc)];
    y3 = [0; dV(idx_itc) ];
    label3 = pol_itc;
    x3_plot = x3(idx3).*100;
    y3_plot = y3(idx3).*100;
    label3_plot = label3(idx3).*100;

    fig_v_taxagg_vat_itc = figure;
    h1 = plot(x1_plot,y1_plot,'r--x','Linewidth',2,'MarkerSize',6,'MarkerEdgeColor','r');
    hold on
%     h2 = plot(x2_plot,y2_plot,'b:^','Linewidth',2,'MarkerSize',6,'MarkerEdgeColor','b');
    h3 = plot(x3_plot,y3_plot,'k--o','Linewidth',2,'MarkerSize',6,'MarkerEdgeColor','k');
    for i = 1:length(x1_plot)
        text(x1_plot(i),y1_plot(i),strcat({'  '},num2str(label1_plot(i)),{'  '}),'Color','r','Fontsize',13,'Units','data','HorizontalAlignment','right')
    end
%     for i = 1:length(x2_plot)
%         text(x2_plot(i),y2_plot(i),strcat({'  '},num2str(label2_plot(i)),{'  '}),'Color','b','Fontsize',13,'Units','data','HorizontalAlignment','left')
%     end
    for i = 1:length(x3_plot)
        text(x3_plot(i),y3_plot(i),strcat({'  '},num2str(label3_plot(i)),{'  '}),'Color','k','Fontsize',13,'Units','data','HorizontalAlignment','left')
    end
    %title('Average Firm Value','FontSize', 13)
    xlabel('Percentage Change in Tax Revenue (%)','FontSize', 14)
    ylabel('Percentage Change in Firm Value (%)','FontSize', 14)
    xlim([xlim1 xlim2]); ylim([ylim1 ylim2])
    plot([0,0],[ylim1,ylim2], '--','Color',[0,0,0]+0.6)
    plot([xlim1,xlim2],[0,0], '--','Color',[0,0,0]+0.6)
    plot([xlim1,min(xlim2,ylim2)],[xlim1,min(xlim2,ylim2)],'--','Color',[0,0,0]+0.6)
    hold off
%     legend([h1 h2 h3],{'VAT Rate (pp.)','Corporate Income Tax Rate (pp.)','Investment Tax Credit Rate (pp.)'},'FontSize',13,'Location','Southeast','box','off')
    legend([h1 h3],{'VAT Rate (pp.)','Investment Tax Credit Rate (pp.)'},'FontSize',13,'Location','Southeast','box','off')
    
%  VAT + CIT + ITC
    x1 = [0;-dTAXagg(idx_vat)];
    y1 = [0; dV(idx_vat) ];
    label1 = pol_vat;
    x1_plot = x1(idx1).*100;
    y1_plot = y1(idx1).*100;
    label1_plot = label1(idx1).*100;
    
    x2 = -dTAXagg(idx_cit);
    y2 = dV(idx_cit);
    label2 = pol_cit;
    x2_plot = x2(idx2).*100;
    y2_plot = y2(idx2).*100;
    label2_plot = label2(idx2).*100;
    
    x3 = [0;-dTAXagg(idx_itc)];
    y3 = [0; dV(idx_itc) ];
    label3 = pol_itc;
    x3_plot = x3(idx3).*100;
    y3_plot = y3(idx3).*100;
    label3_plot = label3(idx3).*100;

    fig_v_taxagg_vat_cit_itc = figure;
    h1 = plot(x1_plot,y1_plot,'r--x','Linewidth',2,'MarkerSize',6,'MarkerEdgeColor','r');
    hold on
    h2 = plot(x2_plot,y2_plot,'b:^','Linewidth',2,'MarkerSize',6,'MarkerEdgeColor','b');
    h3 = plot(x3_plot,y3_plot,'k--o','Linewidth',2,'MarkerSize',6,'MarkerEdgeColor','k');
    for i = 1:length(x1_plot)
        text(x1_plot(i),y1_plot(i),strcat({'  '},num2str(label1_plot(i)),{'  '}),'Color','r','Fontsize',13,'Units','data','HorizontalAlignment','right')
    end
    for i = 1:length(x2_plot)
        text(x2_plot(i),y2_plot(i),strcat({'  '},num2str(label2_plot(i)),{'  '}),'Color','b','Fontsize',13,'Units','data','HorizontalAlignment','left')
    end
    for i = 1:length(x3_plot)
        text(x3_plot(i),y3_plot(i),strcat({'  '},num2str(label3_plot(i)),{'  '}),'Color','k','Fontsize',13,'Units','data','HorizontalAlignment','left')
    end
    %title('Average Firm Value','FontSize', 13)
    xlabel('Percentage Change in Tax Revenue (%)','FontSize', 14)
    ylabel('Percentage Change in Firm Value (%)','FontSize', 14)
    xlim([xlim1 xlim2]); ylim([ylim1 ylim2])
    plot([0,0],[ylim1,ylim2], '--','Color',[0,0,0]+0.6)
    plot([xlim1,xlim2],[0,0], '--','Color',[0,0,0]+0.6)
    plot([xlim1,min(xlim2,ylim2)],[xlim1,min(xlim2,ylim2)],'--','Color',[0,0,0]+0.6)
    hold off
    legend([h1 h2 h3],{'VAT Rate (pp.)','Corporate Income Tax Rate (pp.)','Investment Tax Credit Rate (pp.)'},'FontSize',13,'Location','Southeast','box','off')
    


saveas(fig_v_taxagg_vat_cit,[dropboxpath,'Output/Figure_F6A.png'])
saveas(fig_v_taxagg_vat_itc,[dropboxpath 'Output/Figure_F6B.png'])


%% Table 9

%% Simulating tax reforms: 10-year window
idx = [18;24;45;length(P);63]';  % 17% vat cut; 5.4% cit cut; 100% bonus depreciation; TCJA

% Reduced-form 
mm_data = readtable('data_mm_b.xls');   
glob.mm_data = [mm_data.AvgI,mm_data.ShareI_0_1,mm_data.ShareI_0_2,mm_data.ShareI_0_3, ...
                mm_data.Corr_i_i___1__,mm_data.SDI,mm_data.DID_Ext,mm_data.DID_Int];
b_ext = glob.mm_data(7);
b_int = glob.mm_data(8);

avg_ext = 0.592;    % fraction of firms investing
avg_int = 0.098;    % average investment rate

rd_ext = b_ext/avg_ext* dUCC(idx);
rd_int = b_int/avg_int* dUCC(idx);


Tab1 = [dI(idx)';...
        dEXT(idx)';...
        dTAXagg(idx)';...
        dV(idx)';...
        -dI(idx)'./dTAXagg(idx)';...
        -dV(idx)'./dTAXagg(idx)'];
        
clear input
clc
input.data = Tab1 ; 
input.tableColLabels = {'Baseline VAT Reduction','CIT 15.4\% to 10\%','Bonus Depreciation','TCJA: BD+CIT','10\% ITC'};
input.tableRowLabels =  {'Aggregate Investment',...
                         'Fraction of Firms Investing',...
                         'Tax Revenue',...
                         'Firm Value',...
                         'Ratio of Investment to Tax Revenue',...
                         'Ratio of Firm Value to Tax Revenue'}; 
input.dataFormat = {'%.3f'}; % three digits precision for first two columns, one digit for the last
input.tableColumnAlignment = 'c';
input.tableBorders = 0;
input.booktabs = 1; 
input.tableCaption = '';
latex = latexTable(input);
T = cell2table(latex) ;
writetable(T,[dropboxpath 'Output/Table_9.txt']) ;
