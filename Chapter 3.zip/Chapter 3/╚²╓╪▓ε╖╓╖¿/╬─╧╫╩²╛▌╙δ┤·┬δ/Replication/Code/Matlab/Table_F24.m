% This file conducts three tasks: 
% 1) simulation robustness using "foreign firms" as the control group 
% 2) feed in an upward-sloping capital supply surve to capture GE effects

DPK = [0,0.06348,0.0376,0.02578,0.0196];

DI_SS     = NaN(size(DPK));   % steady-state aggregate investment
D_EXT_D   = NaN(size(DPK));   % extensive margin response of domestic firms
D_EXT_F   = NaN(size(DPK));   % extensive margin response of foreign firms
D_INT_D   = NaN(size(DPK));   % intensive margin response of domestic firms
D_INT_F   = NaN(size(DPK));   % intensive margin response of foreign firms

for idx_dpk = 1:length(DPK)

    clearvars -except dropboxpath idx_dpk DPK DI_SS D_EXT_D D_EXT_F D_INT_D D_INT_F
    dpk = DPK(1,idx_dpk);
    
    clc
    close all
    warning off all

%     dropboxpath='/Users/xianjiang/Dropbox/Research/Fiscal Incentive and Investment/Replication/'; % revise this directory
%     cepath=[dropboxpath 'Code/Matlab/myfunctions/compecon/']; path([cepath 'cetools;' cepath 'cedemos'],path)
% 
%     addpath([dropboxpath 'Code/Matlab/myfunctions'])
%     addpath([dropboxpath 'Code/Matlab/estimation'])
%     addpath([dropboxpath 'RawData'])

%% SIMULATE CONTROL GROUP
%% SETTINGS
% set parameters
pars.p_s = 1;
pars.beta  = 0.95;  
pars.theta = 0.734;   

% policy relevant parameters
pars.nu = 0.17;
pars.tau = 0.154;
pars.n_dep =10;
pars.r = 1/pars.beta - 1;
pars.pv = (1./pars.n_dep).*(1+pars.r)/pars.r.*(1-(1+pars.r).^(-pars.n_dep));
pars.delta_dep = (1-pars.beta).*pars.pv./(1-pars.beta.*pars.pv);
 
% shock processes
pars.rho_b = 0.009;  
pars.sig_b = 0.010/(1-pars.theta);
pars.rho_e = 0.860;   
pars.sig_e = 0.529/(1-pars.theta); 
pars.sig_u = sqrt(1-pars.rho_e^2)*pars.sig_e;  %standard deviation of shocks
pars.sig_w = 0.854;

% simulation 
pars.T  = 101*2;                     % number of periods
pars.Tn = 15;                        % not using initial 15 periods
pars.Nf = 10000;                     % number of firms

% setting algorithm parameter values
pars.tol = 10^-8; 
pars.maxiter = 5000; 
        
% approximation basis
pars.nb = 5;
pars.ne = 20;
pars.m = 3;   %std for Tauchen's discretization
pars.nk = 31;
pars.nxi = 20;
pars.na = pars.nb*pars.ne;

% approximation grids 
[b_grid,P_b] = tauchen(0,sqrt(1-pars.rho_b^2)*pars.sig_b,pars.rho_b,pars.m,pars.nb); b_grid = exp(b_grid);
[e_grid,P_e] = tauchen(0,sqrt(1-pars.rho_e^2)*pars.sig_e,pars.rho_e,pars.m,pars.ne); e_grid = exp(e_grid);
[a_grid,I]   = sort(kron(b_grid,e_grid),'ascend');
P_a = kron(P_b,P_e);
P_a = P_a(I,I);
 
pars.k_min=1;
pars.k_max=10000;

curv = .4;
k_grid = linspace(pars.k_min.^curv,pars.k_max.^curv,pars.nk).^(1/curv);
k_grid = k_grid';
    
%% 1 SET PARAMETERS 
load Uniform_AB_idtw x
x = [x(1) x(2) 1 1 x(3)];

    % assign parameter values
    gamma       = x(1,1);
    xi_bar      = x(1,2);
    a           = x(1,3); 
    b           = x(1,4); 
    delta       = x(1,5);
    
    p_s         = pars.p_s;
    beta        = pars.beta;
    theta       = pars.theta;
    rho_e       = pars.rho_e;
    sig_u       = pars.sig_u;
    nu          = pars.nu;
    tau         = pars.tau;
    n_dep       = pars.n_dep;
    r           = pars.r;
    pv          = pars.pv;
    delta_dep   = pars.delta_dep;
    
    k_min       = pars.k_min;
    k_max       = pars.k_max;
    na          = pars.na;
    nxi         = pars.nxi;
    
    Tn          = pars.Tn;
    
    tol         = pars.tol;
    maxiter     = pars.maxiter;
    
    fpars = [gamma;xi_bar;p_s;a;b];         % friction parameters
    apars = [beta;delta;theta;rho_e;sig_u];             % asigned parameters
    tpars = [nu;tau;n_dep;pv;delta_dep];    % policy parameters
    options = [tol,maxiter];
    
%% 2 SOLVE THE MODEL

%% Approximation basis
%  For solving the model
fspace = fundef({'spli', k_grid, 0, 3}, ...
                {'spli', a_grid, 0, 1});
s_grid = funnode(fspace);
s = gridmake(s_grid);
ns = length(s);
nk = ns/na;

%%  Before the reform
dpk_before = 0;
tpars_before = [tpars;dpk_before];
pk = (1+tpars_before(6))*(1 - tpars_before(2)*tpars_before(4))*(1+tpars_before(1));
ucc(1,1) = pk/(1-tpars_before(2))*(r+delta);

ce0 = funfitxy(fspace,s,s(:,2).^(1-theta).*s(:,1).^theta);            
[ckprimeb_before,ckprimes_before,ce_before,cvb_before,cvs_before,ve_before] = sol_model_ksupply(s,ce0,fspace,P_a,k_max,k_min,ns,nk,options,apars,fpars,tpars_before);

ckprimeb_0 = ckprimeb_before;
        
%%  After the reform  
nu_after = nu;  % foreign firms do not have VAT cut
tpars_after = [nu_after;tpars(2:end);dpk];
pk = (1+tpars_after(6))*(1 - tpars_after(2)*tpars_after(4))*(1+tpars_after(1));
ucc(1,2) = pk/(1-tpars_after(2))*(r+delta);
ducc = ucc(2)/ucc(1)-1; %  Percentage change in user cost of capital
        
apars_after = apars;
    
ce0 = ce_before;
[ckprimeb_after,ckprimes_after,ce_after,cvb_after,cvs_after,~] = sol_model_ksupply(s,ce0,fspace,P_a,k_max,k_min,ns,nk,options,apars_after,fpars,tpars_after);
        
%% 3 Simulate investment and tax revenues 

%% Simulate investment

%%% Simulate firm-specific shocks
    T  = 200;
    Nf = 10000;
    % Initial draw from stationary dist.
    E_sim=zeros(Nf,T);
    rng('default'); rng(333);
    E_sim(:,1) = normrnd(0, pars.sig_e, Nf,1);
    for t=2:1:T
        E_sim(:,t) = pars.rho_e*E_sim(:,t-1) + normrnd(0, sqrt(1 - pars.rho_e^2)*pars.sig_e, Nf, 1);
        % Truncate idiosyncratic shocks grids
        E_sim(:,t) = min(max(min(log(e_grid)),E_sim(:,t)),max(log(e_grid)));
    end

    B_sim=zeros(1,T);
    rng('default'); rng(666)
    B_sim(1)=normrnd(0, pars.sig_b/(sqrt(1-pars.rho_b^2)));
    for t=2:1:T
        B_sim(t) = pars.rho_b*B_sim(t-1) + normrnd(0, pars.sig_b);
     end
    A_sim = exp(E_sim + repmat(B_sim,Nf,1));

%%% Simulate idiosyncratic fixed cost
    rng('default'); rng(999)
    X_sim = x(2)*betarnd(x(3),x(4),Nf,T);

%%% Simulate investment 
    % Initial capital stock based on frictionless model
    K_sim = zeros(Nf,T);
    K_sim(:,1) = 500;
    V_sim = zeros(Nf,T);
    
    % 0 Start to simulate for pre-period
    for t = 1 : T/2-1
        pk = (1+tpars_before(6))*(1 - tpars_before(2)*tpars_before(4))*(1+tpars_before(1));
        kstar=exp(1/(1-theta)*log((1-tpars_before(2))) - 1/(1-theta)*log((1-beta*(1-delta))*pk/(beta*theta))).*exp(rho_e*(1-theta)*log(A_sim(:,t))+0.5*(rho_e*(1-theta))^2*sig_u^2);
        
        vb = funeval(cvb_before,fspace,[K_sim(:,t),A_sim(:,t)]);
        vs = funeval(cvs_before, fspace,[K_sim(:,t),A_sim(:,t)]);
        vi = beta*funeval(ce_before,fspace,[(1-delta).*K_sim(:,t),A_sim(:,t)]);

        kprimeb = funeval(ckprimeb_before,fspace,[K_sim(:,t),A_sim(:,t)]);
        kprimes = funeval(ckprimes_before,fspace,[K_sim(:,t),A_sim(:,t)]);

        % Find the inaction, buy, or sell
        idx1 = ++(vb>vs);   
        idx2 = ++(max(vb,vs)-X_sim(:,t).*kstar>vi);

        %  update capital
        kprime = dprod(idx2,dprod(idx1,kprimeb)+dprod((1-idx1),kprimes)) + dprod((1-idx2),(1-delta).*K_sim(:,t));
        K_sim(:,t+1) = kprime;
        
        V_sim(:,t) = dprod(idx2,dprod(idx1,vb)+dprod((1-idx1),vs)) + dprod((1-idx2),vi);
    end

    % 1 Simulate for the post-period
    for t = T/2 : T-1
        pk = (1+tpars_after(6))*(1 - tpars_after(2)*tpars_after(4))*(1+tpars_after(1));
        kstar=exp(1/(1-theta)*log((1-tpars_after(2))) - 1/(1-theta)*log((1-apars_after(1)*(1-delta))*pk/(apars_after(1)*theta))).*exp(rho_e*(1-theta)*log(A_sim(:,t))+0.5*(rho_e*(1-theta))^2*sig_u^2);
        
        vb = funeval(cvb_after,fspace,[K_sim(:,t),A_sim(:,t)]);
        vs = funeval(cvs_after, fspace,[K_sim(:,t),A_sim(:,t)]);
        vi = apars_after(1)*funeval(ce_after,fspace,[(1-delta).*K_sim(:,t),A_sim(:,t)]);

        kprimeb = funeval(ckprimeb_after,fspace,[K_sim(:,t),A_sim(:,t)]);
        kprimes = funeval(ckprimes_after,fspace,[K_sim(:,t),A_sim(:,t)]);

        %  find the inaction, buy, or sell
        idx1 = ++(vb>vs);   
        idx2 = ++(max(vb,vs)-X_sim(:,t).*kstar>vi);

        %  update capital
        kprime = dprod(idx2,dprod(idx1,kprimeb)+dprod((1-idx1),kprimes)) + dprod((1-idx2),(1-delta).*K_sim(:,t));
        K_sim(:,t+1) = kprime;
        
        V_sim(:,t) = dprod(idx2,dprod(idx1,vb)+dprod((1-idx1),vs)) + dprod((1-idx2),vi);
    end

    I_sim = (K_sim(:,2:end) - (1-delta).*K_sim(:,1:end-1));

    % 2 Simulate for the post-period counterfactual 
    K_sim_cf = zeros(Nf,T);
    K_sim_cf(:,1:T/2) = K_sim(:,1:T/2);
    V_sim_cf = zeros(Nf,T);
    V_sim_cf(:,1:T/2) = V_sim(:,1:T/2);

    for t = T/2 : T-1
        pk = (1+tpars_before(6))*(1 - tpars_before(2)*tpars_before(4))*(1+tpars_before(1));
        kstar=exp(1/(1-theta)*log((1-tpars_before(2))) - 1/(1-theta)*log((1-beta*(1-delta))*pk/(beta*theta))).*exp(rho_e*(1-theta)*log(A_sim(:,t))+0.5*(rho_e*(1-theta))^2*sig_u^2);

        vb_cf = funeval(cvb_before,fspace,[K_sim_cf(:,t),A_sim(:,t)]);
        vs_cf = funeval(cvs_before, fspace,[K_sim_cf(:,t),A_sim(:,t)]);
        vi_cf = beta*funeval(ce_before,fspace,[(1-delta).*K_sim_cf(:,t),A_sim(:,t)]);

        kprimeb_cf = funeval(ckprimeb_before,fspace,[K_sim_cf(:,t),A_sim(:,t)]);
        kprimes_cf = funeval(ckprimes_before,fspace,[K_sim_cf(:,t),A_sim(:,t)]);

        % find the inaction, buy, or sell
        idx1 = ++(vb_cf>vs_cf);   
        idx2 = ++(max(vb_cf,vs_cf)-X_sim(:,t).*kstar>vi_cf);

        % update capital
        kprime_cf = dprod(idx2,dprod(idx1,kprimeb_cf)+dprod((1-idx1),kprimes_cf)) + dprod((1-idx2),(1-delta).*K_sim_cf(:,t));
        K_sim_cf(:,t+1) = kprime_cf;
        
        V_sim_cf(:,t) = dprod(idx2,dprod(idx1,vb_cf)+dprod((1-idx1),vs_cf)) + dprod((1-idx2),vi_cf);
    end
    I_sim_cf = (K_sim_cf(:,2:end) - (1-delta).*K_sim_cf(:,1:end-1));
    
%% Store results
    disp([nu,x])
    I_sim_f = I_sim;
    k_sim_f = K_sim(:,1:end-1);
    
    ik_sim_f = I_sim./K_sim(:,1:end-1);
    ik_sim_f_cf = I_sim_cf./K_sim_cf(:,1:end-1);
    

 
%% TREATMENT GROUP
    
%% 2 SOLVE THE MODEL
%%% Approximation basis
	fspace = fundef({'spli', k_grid, 0, 3}, ...
                    {'spli', a_grid, 0, 1});
	s_grid = funnode(fspace);
	s = gridmake(s_grid);
	ns = length(s);
	nk = ns/na;
    
% %%% Before the reform
% 	ce0 = funfitxy(fspace,s,s(:,2).^(1-theta).*s(:,1).^theta);            
% 	[ckprimeb_before,ckprimes_before,ce_before,cvb_before,cvs_before,ve_before] = sol_model_ksupply(s,ce0,fspace,P_a,k_max,k_min,ns,nk,options,apars,fpars,tpars_before);
    
%%% After the reform
    nu_after = 0;   % 17% VAT cut
    tpars_after = [nu_after;tpars(2:end);dpk];
    pk = (1+tpars_after(6))*(1 - tpars_after(2)*tpars_after(4))*(1+tpars_after(1));
    ucc(1,2) = pk/(1-tpars_after(2))*(r+delta);
    
    apars_after = apars;
    
	ce0 = ce_before;
	[ckprimeb_after,ckprimes_after,ce_after,cvb_after,cvs_after,ve_after] = sol_model_ksupply(s,ce0,fspace,P_a,k_max,k_min,ns,nk,options,apars_after,fpars,tpars_after);
            
%% Simulate investment

%%% Simulate firm-specific shocks
    T  = 200;
    Nf = 10000;
    % Initial draw from stationary dist.
    E_sim=zeros(Nf,T);
    rng('default'); rng(333);
    E_sim(:,1) = normrnd(0, pars.sig_e, Nf,1);
    for t=2:1:T
        E_sim(:,t) = pars.rho_e*E_sim(:,t-1) + normrnd(0, sqrt(1 - pars.rho_e^2)*pars.sig_e, Nf, 1);
        % Truncate idiosyncratic shocks grids
        E_sim(:,t) = min(max(min(log(e_grid)),E_sim(:,t)),max(log(e_grid)));
    end

    B_sim=zeros(1,T);
    rng('default'); rng(666)
    B_sim(1)=normrnd(0, pars.sig_b/(sqrt(1-pars.rho_b^2)));
    for t=2:1:T
        B_sim(t) = pars.rho_b*B_sim(t-1) + normrnd(0, pars.sig_b);
     end
    A_sim = exp(E_sim + repmat(B_sim,Nf,1));

%%% Simulate idiosyncratic fixed cost
    rng('default'); rng(999)
    X_sim = x(2)*betarnd(x(3),x(4),Nf,T);

%%% Simulate investment 
    % Initial capital stock based on frictionless model
    K_sim = zeros(Nf,T);
    K_sim(:,1) = 500;
    V_sim = zeros(Nf,T);
    
    % 0 Start to simulate for pre-period
    for t = 1 : T/2-1
        pk = (1+tpars_before(6))*(1 - tpars_before(2)*tpars_before(4))*(1+tpars_before(1));
        kstar=exp(1/(1-theta)*log((1-tpars_before(2))) - 1/(1-theta)*log((1-beta*(1-delta))*pk/(beta*theta))).*exp(rho_e*(1-theta)*log(A_sim(:,t))+0.5*(rho_e*(1-theta))^2*sig_u^2);
        
        vb = funeval(cvb_before,fspace,[K_sim(:,t),A_sim(:,t)]);
        vs = funeval(cvs_before, fspace,[K_sim(:,t),A_sim(:,t)]);
        vi = beta*funeval(ce_before,fspace,[(1-delta).*K_sim(:,t),A_sim(:,t)]);

        kprimeb = funeval(ckprimeb_before,fspace,[K_sim(:,t),A_sim(:,t)]);
        kprimes = funeval(ckprimes_before,fspace,[K_sim(:,t),A_sim(:,t)]);

        % Find the inaction, buy, or sell
        idx1 = ++(vb>vs);   
        idx2 = ++(max(vb,vs)-X_sim(:,t).*kstar>vi);

        %  update capital
        kprime = dprod(idx2,dprod(idx1,kprimeb)+dprod((1-idx1),kprimes)) + dprod((1-idx2),(1-delta).*K_sim(:,t));
        K_sim(:,t+1) = kprime;
        
        V_sim(:,t) = dprod(idx2,dprod(idx1,vb)+dprod((1-idx1),vs)) + dprod((1-idx2),vi);
    end

    % 1 Simulate for the post-period
    for t = T/2 : T-1
        pk = (1+tpars_after(6))*(1 - tpars_after(2)*tpars_after(4))*(1+tpars_after(1));
        kstar=exp(1/(1-theta)*log((1-tpars_after(2))) - 1/(1-theta)*log((1-apars_after(1)*(1-delta))*pk/(apars_after(1)*theta))).*exp(rho_e*(1-theta)*log(A_sim(:,t))+0.5*(rho_e*(1-theta))^2*sig_u^2);
        
        vb = funeval(cvb_after,fspace,[K_sim(:,t),A_sim(:,t)]);
        vs = funeval(cvs_after, fspace,[K_sim(:,t),A_sim(:,t)]);
        vi = apars_after(1)*funeval(ce_after,fspace,[(1-delta).*K_sim(:,t),A_sim(:,t)]);

        kprimeb = funeval(ckprimeb_after,fspace,[K_sim(:,t),A_sim(:,t)]);
        kprimes = funeval(ckprimes_after,fspace,[K_sim(:,t),A_sim(:,t)]);

        %  find the inaction, buy, or sell
        idx1 = ++(vb>vs);   
        idx2 = ++(max(vb,vs)-X_sim(:,t).*kstar>vi);

        %  update capital
        kprime = dprod(idx2,dprod(idx1,kprimeb)+dprod((1-idx1),kprimes)) + dprod((1-idx2),(1-delta).*K_sim(:,t));
        K_sim(:,t+1) = kprime;
        
        V_sim(:,t) = dprod(idx2,dprod(idx1,vb)+dprod((1-idx1),vs)) + dprod((1-idx2),vi);
    end

    I_sim = (K_sim(:,2:end) - (1-delta).*K_sim(:,1:end-1));

    % 2 Simulate for the post-period counterfactual 
    K_sim_cf = zeros(Nf,T);
    K_sim_cf(:,1:T/2) = K_sim(:,1:T/2);
    V_sim_cf = zeros(Nf,T);
    V_sim_cf(:,1:T/2) = V_sim(:,1:T/2);

    for t = T/2 : T-1
        pk = (1+tpars_before(6))*(1 - tpars_before(2)*tpars_before(4))*(1+tpars_before(1));
        kstar=exp(1/(1-theta)*log((1-tpars_before(2))) - 1/(1-theta)*log((1-beta*(1-delta))*pk/(beta*theta))).*exp(rho_e*(1-theta)*log(A_sim(:,t))+0.5*(rho_e*(1-theta))^2*sig_u^2);

        vb_cf = funeval(cvb_before,fspace,[K_sim_cf(:,t),A_sim(:,t)]);
        vs_cf = funeval(cvs_before, fspace,[K_sim_cf(:,t),A_sim(:,t)]);
        vi_cf = beta*funeval(ce_before,fspace,[(1-delta).*K_sim_cf(:,t),A_sim(:,t)]);

        kprimeb_cf = funeval(ckprimeb_before,fspace,[K_sim_cf(:,t),A_sim(:,t)]);
        kprimes_cf = funeval(ckprimes_before,fspace,[K_sim_cf(:,t),A_sim(:,t)]);

        % find the inaction, buy, or sell
        idx1 = ++(vb_cf>vs_cf);   
        idx2 = ++(max(vb_cf,vs_cf)-X_sim(:,t).*kstar>vi_cf);

        % update capital
        kprime_cf = dprod(idx2,dprod(idx1,kprimeb_cf)+dprod((1-idx1),kprimes_cf)) + dprod((1-idx2),(1-delta).*K_sim_cf(:,t));
        K_sim_cf(:,t+1) = kprime_cf;
        
        V_sim_cf(:,t) = dprod(idx2,dprod(idx1,vb_cf)+dprod((1-idx1),vs_cf)) + dprod((1-idx2),vi_cf);
    end
    I_sim_cf = (K_sim_cf(:,2:end) - (1-delta).*K_sim_cf(:,1:end-1));

%% Store results
    disp([nu,x])
    ik_sim_d = I_sim./K_sim(:,1:end-1);
    ik_sim_d_cf = I_sim_cf./K_sim_cf(:,1:end-1);
     
    I_sim_d = I_sim;
    k_sim_d = K_sim(:,1:end-1);

    
%% AGGREGATE INVESTMENT: DOMESTIC FIRMS + FOREIGN FIRMS
shr_f = 0.22;   % share of capital of foreign firms (measured by fixed assets in data)
I_sim = shr_f.*I_sim_f + (1-shr_f).*I_sim_d;
k_sim = shr_f.*k_sim_f + (1-shr_f).*k_sim_d;

%%% Change in aggregate investment in the new steady state
    dI_ss_f = mean(sum(I_sim_f(:,end-20+1:end),1))./mean(sum(I_sim_cf(:,end-20+1:end),1))-1;
    dI_ss_d = mean(sum(I_sim_d(:,end-20+1:end),1))./mean(sum(I_sim_cf(:,end-20+1:end),1))-1;
    dI_ss   = mean(sum(I_sim(:,end-20+1:end),1))./mean(sum(I_sim_cf(:,end-20+1:end),1))-1;
   
%% DIFF-IN-DIFF COEFFICIENTSS
np = 3;
t = T/2;

D_EXT_F(1,idx_dpk) = mean(sum(ik_sim_f(:,t:t+np-1)>0,1)./Nf)-mean(sum(ik_sim_f_cf(:,t:t+np-1)>0,1)./Nf);
D_EXT_D(1,idx_dpk) = mean(sum(ik_sim_d(:,t:t+np-1)>0,1)./Nf)-mean(sum(ik_sim_d_cf(:,t:t+np-1)>0,1)./Nf);

D_INT_F(1,idx_dpk) = mean(mean(ik_sim_f(:,t:t+np-1)))-mean(mean(ik_sim_f_cf(:,t:t+np-1)));
D_INT_D(1,idx_dpk) = mean(mean(ik_sim_d(:,t:t+np-1)))-mean(mean(ik_sim_d_cf(:,t:t+np-1)));

DI_SS(1,idx_dpk) = dI_ss;

end

ELS = DI_SS./DPK;               % elasticity of capital supply
DID_EXT = D_EXT_D - D_EXT_F;    % diff-in-diff extensive margin response
DID_INT = D_INT_D - D_INT_F;    % diff-in-diff intensive margin response
