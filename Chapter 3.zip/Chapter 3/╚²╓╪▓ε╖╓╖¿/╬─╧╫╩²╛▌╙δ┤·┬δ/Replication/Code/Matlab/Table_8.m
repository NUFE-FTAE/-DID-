%%% This file generates Table 8

clearvars -except dropboxpath
clc
close all

%% Load Files
% Average fixed cost
run([dropboxpath 'Code/Matlab/main.m'])
clearvars -except dropboxpath mean_xi

% Data
T = readtable([dropboxpath 'RawData/data_mm_b.xls']);
mm_data = [T.AvgI,T.ShareI_0_1,T.ShareI_0_2,T.ShareI_0_3,T.Corr_i_i___1__,T.SDI,T.DID_Ext,T.DID_Int];
T = readtable([dropboxpath 'RawData/data_mm_V.xls']);
sd_data = sqrt([T.AvgI(1),T.ShareI_0_1(2),T.ShareI_0_2(3),T.ShareI_0_3(4),T.Corr_i_i___1__(5),T.SDI(6),T.DID_Ext(7),T.DID_Int(8)]);

% Fixed A
load([dropboxpath 'Code/Matlab/estimation/Fixed_A_idtw.mat'],'x','mm_sim');
load([dropboxpath 'Code/Matlab/standard_error/se_Fixed_A.mat'],'se');
mm_fixed_A = mm_sim;
x_fixed_A = x;
se_fixed_A = se;

% Uniform A
load([dropboxpath 'Code/Matlab/estimation/Uniform_A_idtw.mat'],'x','mm_sim');
load([dropboxpath 'Code/Matlab/standard_error/se_Uniform_A.mat'],'se');
mm_uniform_A = mm_sim;                                
x_uniform_A = x;
se_uniform_A = se;

% Uniform AB
load([dropboxpath 'Code/Matlab/estimation/Uniform_AB_idtw.mat'],'x','mm_sim');
load([dropboxpath 'Code/Matlab/standard_error/se_Uniform_AB.mat'],'se');
mm_uniform_AB = mm_sim;
x_uniform_AB = x;
se_uniform_AB = se;

%% Generate Table
input.data = [NaN(1,3),mm_data;             NaN(1,3),sd_data;...
              x_fixed_A,mm_fixed_A;         se_fixed_A,NaN(1,8);...
              x_uniform_A,mm_uniform_A;     se_uniform_A,NaN(1,8);...
              x_uniform_AB,mm_uniform_AB;   se_uniform_AB,NaN(1,8);...
              mean_xi,NaN(1,10)];
% Set column and row labels (use empty string for no label)
input.tableColLabels = {'$\gamma$','$\bar\xi$','$\delta$','Avg i','Share i$<$0.1','Share i$<$0.2','Share i$<$0.3','corr(i,i$_{-1}$)','SD i','DID. Ext','DID. Int'};

input.tableRowLabels =  {'Data',...
                         '',...
                         'Fixed',...
                         '(A)',...
                         'Uniform',...
                         '(A)',...
                         'Uniform',...
                         '(A$+$B)',...
                         'Avg. Fixed Cost'}; 
                     
% Determine whether input.dataFormat is applied column or row based:
% input.dataFormatMode = 'column'; % use 'column' or 'row'. if not set 'column' is used
input.dataFormat = {'%.3f'}; % uses three digit precision floating point for all data values
% Define how NaN values in input.tableData should be printed in the LaTex table:
input.dataNanString = '';
% Column alignment in Latexrobustness table with heterogeneous epsilons table ('l'=left-justified, 'c'=centered,'r'=right-justified):
input.tableColumnAlignment = 'c';
% Switch table borders on/off:
input.tableBorders = 1;
% Switch table booktabs on/off:
input.booktabs = 1;
% LaTex table caption:
input.tableCaption = 'Structual Estimation and Moments';
% LaTex table label:
input.tableLabel = 'MyTableLabel';
% Switch to generate a complete LaTex document or just a table:
input.makeCompleteLatexDocument = 0;

% % Now call the function to generate LaTex code:
latex = latexTable(input);
% Save as text file
T = cell2table(latex) ;
writetable(T,[dropboxpath '/Output/Table_8.txt']);