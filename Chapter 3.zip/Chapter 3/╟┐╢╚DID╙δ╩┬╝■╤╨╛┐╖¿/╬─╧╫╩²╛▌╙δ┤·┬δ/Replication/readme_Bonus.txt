readme for replication files assocaited with "Tax Policy and Local Labor Market Behavior"

This zip file contains all of the programs used to generate the figures and tables in this paper.
Please cite the paper if using this code or data in other papers. 
	Contents:
		Programs:
			-Master_replication_file.do
			-figure1a.do		(Includes Table E1)
			-figure1b.do		(Includes Figure E2)
			-figure2a-c.do		(Includes Tables E4-E6)
			-figure2d.do		(Includes Tables E7-E9)
			-figure3.do
			-figureC1.do
			-figureD1.do
			-figureE1.do
			-figureE3-5.do
			-figureE6-7.do
			-Table1.do
			-TableE2.do
			-TableE3.do
			-ES_graph_data_lr.ado	(program for graphing estimates)

		Data:
			-fig1a.dta
			-fig1b_figE2.dta
			-fig2a-c.dta
			-fig2d.dta
			-fig3.dta
			-figC1.dta
			-figD1.dta
			-figE1.dta
			-figE6-7.dta
			-tableE2.dta
			-tableE3.dta

	Running Replication:
		In order to run the replication, open "Master_replication_file.do" in Stata and update the top global directory to the relevant folder.
		The other files run in order of appearance in the paper and each create the names figure or table.
		Please Note: Some files require regression results included in earlier files so they must be run in order


Data Sources and Variable Definitions:
	-fig1a.dta
	   Source: QCEW merged with Zwick and Mahon (2017) duration estimates and BEA estimates of capital stock
		-naic2: 2-Digit NAICS identifier
		-Industry: Industry Name
		-zn_avg_w: Average duration within industry weighted by employment (4-digit NAICS aggregated to 2-digit level)
		-zn_sd_w: Standard deviation of duration within 2-digit NAICS industry
		-zn_coefvar_w: Coefficient of Variation of duration within 2-digit NAICS industry
		-tot_emp: Share of total private sector employment in 2001
		-Capital: Share of private sector capital stock in 2001
		-coef_var_norm: Coefficient of Variation weighted by employment, scaled to manufacturing = 1

	-fig1b_figE2.dta
	   Source: QCEW merged with Zwick and Mahon (2017)
		-County: PID identifier
		-top_link: Share of employment in long duration industries (4-digit) in 2001
		-std_w_res_top_link: Share of county employment in long duratrion industries normalized to standard deviations from state means

	-fig2a-c.dta
	   Source: 3-digit NAICS QCEW merged with Zwick and Mahon (2017) and other sources
	   Sample: Balanced panel of county-industries with positive employment when Bonus begins
		-fips_state: State FIPS identifier
		-top_link: Share of county employment in long duration industries (4-digit) in 2001
		-top_DPAD_link: Share of county employment in highest DPAD use industries (4-digit) in 2001 (DPAD use as QPAI in 2005)
		-wgt: County-industry employment in 2001 divided by total employment in 2001
		-wgt_w: Winsorized weights
		-emp_growth: Percent change in employment from 2001 to year t		
		-comp_growth: Percent change in earnings from 2001 to year t		
		-wage_growth: Percent change in earnings divided by employment from 2001 to year t		
		-std_trade_4: Standardized county-level exposure to trade related to NAFTA from Hakobyan and McLaren (2016)
		-std_china_4: Standardized county-level exposure to trade from China from Autor et al. (2016)
		-std_routine_4: Standardized county-level share of routine labor from Autor and Dorn (2013)
		-std_capital_4: Total capital stock, including structures, equipment, and intellectual property products, in 2001 from Bureau of Economic Analysis (2017) allocated to counties using employment shares at the 3-digit NAICS level
		-std_ip_4: Intellectual property stock in 2001 from Bureau of Economic Analysis (2017) allocated to counties using employment shares at the 3-digit NAICS level
		-demographics (std_college_4 std_less_HS_4 std_white_4 std_black_4): Standardized county shares of college educated or more, high school educated or less, white, and black, respectively

	-fig2d.dta
	   Source: 3-digit NAICS QCEW merged with Zwick and Mahon (2017) and other sources
	   Sample: Balanced panel of county-industries with positive employment when Bonus begins
		-fips_state: State FIPS identifier
		-fake_link: Share of county employment in long duration industries with more than 5x more structures and IP than equipment (4-digit) in 2001
		-top_DPAD_link: Share of county employment in highest DPAD use industries (4-digit) in 2001 (DPAD use as QPAI in 2005)
		-wgt: County-industry employment in 2001 divided by total employment in 2001
		-wgt_w: Winsorized weights
		-emp_growth: Percent change in employment from 2001 to year t		
		-comp_growth: Percent change in earnings from 2001 to year t		
		-wage_growth: Percent change in earnings divided by employment from 2001 to year t		
		-std_nafta_4: Standardized county-level exposure to trade related to NAFTA from Hakobyan and McLaren (2016)
		-std_trade_4: Standardized county-level exposure to trade from China from Autor et al. (2016)
		-std_routine_4: Standardized county-level share of routine labor from Autor and Dorn (2013)
		-std_stock_4: Total capital stock, including structures, equipment, and intellectual property products, in 2001 from Bureau of Economic Analysis (2017) allocated to counties using employment shares at the 3-digit NAICS level
		-std_IP_4: Intellectual property stock in 2001 from Bureau of Economic Analysis (2017) allocated to counties using employment shares at the 3-digit NAICS level
		-demographics (std_college_4 std_less_HS_4 std_white_4 std_black_4): Standardized county shares of college educated or more, high school educated or less, white, and black, respectively

	-fig3.dta
	   Source: 3-digit NAICS QCEW merged with Zwick and Mahon (2017) and other sources
	   Sample: Balanced panel of county-industries with positive employment when Bonus begins
		-fips_state: State FIPS identifier
		-top_link: Share of county employment in long duration industries (4-digit) in 2001
		-top_DPAD_link: Share of county employment in highest DPAD use industries (4-digit) in 2001 (DPAD use as QPAI in 2005)
		-wgt: County-industry employment in 2001 divided by total employment in 2001
		-wgt_w: Winsorized weights
		-emp_growth: Percent change in employment from 2001 to year t		
		-comp_growth: Percent change in earnings from 2001 to year t		
		-wage_growth: Percent change in earnings divided by employment from 2001 to year t		
		-std_nafta_4: Standardized county-level exposure to trade related to NAFTA from Hakobyan and McLaren (2016)
		-std_trade_4: Standardized county-level exposure to trade from China from Autor et al. (2016)
		-std_routine_4: Standardized county-level share of routine labor from Autor and Dorn (2013)
		-std_stock_4: Total capital stock, including structures, equipment, and intellectual property products, in 2001 from Bureau of Economic Analysis (2017) allocated to counties using employment shares at the 3-digit NAICS level
		-std_IP_4: Intellectual property stock in 2001 from Bureau of Economic Analysis (2017) allocated to counties using employment shares at the 3-digit NAICS level
		-demographics (std_college_4 std_less_HS_4 std_white_4 std_black_4): Standardized county shares of college educated or more, high school educated or less, white, and black, respectively
		-auto_exp: Scalar defining automation likelihood--1, least likely to automate, to 3, most likely

	-figC1.dta
	   Source: IRS SOI and Kitchen and Knittel (2016)
		-gains_rev: Share of revenue in firms with positive taxable income (IRS SOI)
		-gains_assets: Share of assets in firms with positive taxable income (IRS SOI)
		-bonus: Bonus treatment in each year
		-p_s179: Share of eligible investment claimed for Section 179 each year 
		-adj1: Share of investment treated by bonus (based on assets in taxable firms)
		-adj2: Share of investment treated by bonus (based on revenue in taxable firms) 
		-cu_adj1_norm: Cumulative adjustment measure based on assets normalized to have mean 1
		-cu_adj2_norm: Cumulative adjustment measure based on revenues normalized to have mean 1

	-figD1.dta
	   Source: 3-digit NAICS QCEW merged with Zwick and Mahon (2017) and other sources
	   Sample: Balanced panel of county-industries with positive employment when Bonus begins
		-fips_state: State FIPS identifier
		-top_link: Share of county employment in long duration industries (4-digit) in 2001
		-top_DPAD_link: Share of county employment in highest DPAD use industries (4-digit) in 2001 (DPAD use as QPAI in 2005)
		-wgt: County-industry employment in 2001 divided by total employment in 2001
		-wgt_w: Winsorized weights
		-d3_pop_growth: Change in employment-population ratio from 2001 to year t, adjusted according to Freyaldenhoven, Hansen, and Shapiro (2019) as described in NBER draft 		
		-std_nafta_4: Standardized county-level exposure to trade related to NAFTA from Hakobyan and McLaren (2016)
		-std_trade_4: Standardized county-level exposure to trade from China from Autor et al. (2016)
		-std_routine_4: Standardized county-level share of routine labor from Autor and Dorn (2013)
		-std_stock_4: Total capital stock, including structures, equipment, and intellectual property products, in 2001 from Bureau of Economic Analysis (2017) allocated to counties using employment shares at the 3-digit NAICS level
		-std_IP_4: Intellectual property stock in 2001 from Bureau of Economic Analysis (2017) allocated to counties using employment shares at the 3-digit NAICS level
		-demographics (std_college_4 std_less_HS_4 std_white_4 std_black_4): Standardized county shares of college educated or more, high school educated or less, white, and black, respectively

	-figE1.dta
	   Source: QCEW merged with Zwick and Mahon (2017) 
		-naic2: 2-digit NAICS
		-pct_Long: Percent of long duration (top 30%) employment originating in each 2-digit NAICS industry
		-Industry: Name of 2-digit NAICS industry

	-figE6-7.dta
	   Source: 3-digit NAICS QCEW merged with Zwick and Mahon (2017) and other sources
	   Sample: Balanced panel of county-industries with positive employment in first and last years
		-fips_state: State FIPS identifier
		-top_link_25: Share of county employment in 25% longest duration industries (4-digit) in 2001
		-top_link_40: Share of county employment in 40% longest duration industries (4-digit) in 2001
		-top_DPAD_link: Share of county employment in highest DPAD use industries (4-digit) in 2001 (DPAD use as QPAI in 2005)
		-wgt: County-industry employment in 2001 divided by total employment in 2001
		-wgt_w: Winsorized weights
		-emp_growth: Percent change in employment from 2001 to year t		
		-comp_growth: Percent change in earnings from 2001 to year t		
		-wage_growth: Percent change in earnings divided by employment from 2001 to year t		
		-std_nafta_4: Standardized county-level exposure to trade related to NAFTA from Hakobyan and McLaren (2016)
		-std_trade_4: Standardized county-level exposure to trade from China from Autor et al. (2016)
		-std_routine_4: Standardized county-level share of routine labor from Autor and Dorn (2013)
		-std_stock_4: Total capital stock, including structures, equipment, and intellectual property products, in 2001 from Bureau of Economic Analysis (2017) allocated to counties using employment shares at the 3-digit NAICS level
		-std_IP_4: Intellectual property stock in 2001 from Bureau of Economic Analysis (2017) allocated to counties using employment shares at the 3-digit NAICS level
		-demographics (std_college_4 std_less_HS_4 std_white_4 std_black_4): Standardized county shares of college educated or more, high school educated or less, white, and black, respectively

	-tableE2.dta
	   Source: 3-digit NAICS QCEW merged with Zwick and Mahon (2017) 
	   Sample: 480 counties with population greater than 100,000 in 2001. 
		-QName: County Name
		-top_link: Share of county employment in long duration industries (4-digit) in 2001
		-id: rank

	-tableE3.dta
	   Source: QCEW merged with Zwick and Mahon (2017) and other sources
		-tot_emp: Total county population in 2001 (Census estimate)
		-tot_emp: Total county private-sector employment in 2001 (QCEW)
		-top_link: Share of county employment in 30% longest duration industries (4-digit) in 2001
		-top_link_25: Share of county employment in 25% longest duration industries (4-digit) in 2001
		-top_link_40: Share of county employment in 40% longest duration industries (4-digit) in 2001
		-fake_link: Share of county employment in long duration industries with more than 5x more structures and IP than equipment (4-digit) in 2001
		-top_DPAD_link: Share of county employment in highest DPAD use industries (4-digit) in 2001 (DPAD use as QPAI in 2005)
		-empg7: Percent change in employment from 2001 to 2007		
		-empg12: Percent change in employment from 2001 to 2012	
		-stk_EQUIPMENT: Total equipment stock in 2001 from Bureau of Economic Analysis (2017) allocated to counties using employment shares at the 3-digit NAICS level
		-stk_IPP: Intellectual property products stock in 2001 from Bureau of Economic Analysis (2017) allocated to counties using employment shares at the 3-digit NAICS level
		-in_count3: Count of 3-digit industries in each county with positive employment in 2001 	

Contact:
For questions or comments, please contact Dan Garrett at daniel.garrett@duke.edu
